/* SPDX-License-Identifier: MIT */
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>

static const struct device *const bus = DEVICE_DT_GET(DT_NODELABEL(i2c0));
static const struct device *const usb = DEVICE_DT_GET(DT_CHOSEN(zephyr_console));

static int read_reg(uint8_t address, uint8_t reg, uint8_t *value)
{
    int result = i2c_burst_read(bus, address, reg, value, 1);
    if (result) printk("READ addr=0x%02x reg=0x%02x error=%d\n", address, reg, result);
    else printk("READ addr=0x%02x reg=0x%02x value=0x%02x OK\n", address, reg, *value);
    return result;
}

static int write_reg(uint8_t address, uint8_t reg, uint8_t value)
{
    int result = i2c_burst_write(bus, address, reg, &value, 1);
    printk("WRITE addr=0x%02x reg=0x%02x value=0x%02x result=%d\n", address, reg, value, result);
    return result;
}

static void settle(unsigned ms)
{
    printk("WAIT %u ms\n", ms);
    k_msleep(ms);
}

static int startup(uint8_t address)
{
    uint8_t value;
    int result = read_reg(address, 0x3d, &value);
    if (result) return result;
    result = write_reg(address, 0x3d, 0x00);
    if (result) return result;
    settle(20);
    result = write_reg(address, 0x3f, 0x20);
    /* Reset may terminate its own write; require a recovered chip ID below. */
    if (result) printk("Reset write error tolerated pending chip recovery check\n");
    settle(700);
    result = read_reg(address, 0x00, &value);
    if (result) return result;
    if (value != 0xa0) { printk("Unexpected chip ID after reset\n"); return -1; }
    if ((result = write_reg(address, 0x3e, 0x00))) return result;
    if ((result = write_reg(address, 0x07, 0x00))) return result;
    if ((result = write_reg(address, 0x3f, 0x80))) return result;
    settle(500);
    if ((result = read_reg(address, 0x3d, &value))) return result;
    if ((result = write_reg(address, 0x3d, 0x00))) return result;
    settle(20);
    if ((result = write_reg(address, 0x3d, 0x0c))) return result;
    settle(10);
    settle(1000);
    const uint8_t registers[] = {0x00, 0x07, 0x3d, 0x3f, 0x39, 0x3a, 0x35};
    for (unsigned i = 0; i < sizeof(registers); ++i) {
        result = read_reg(address, registers[i], &value);
        if (result) return result;
    }
    return 0;
}

int main(void)
{
    if (!device_is_ready(usb)) return 0;
    uint32_t dtr = 0;
    while (uart_line_ctrl_get(usb, UART_LINE_CTRL_DTR, &dtr) || !dtr) k_msleep(100);
    printk("BNO055 PROBE: SDA=P0.17 SCL=P0.20, 400kHz, no radio, no NVS\n");
    printk("Registers: 00=chip ID 07=page ID 39=system status 3a=system error\n");
    if (!device_is_ready(bus)) {
        printk("FAIL: i2c0 device not ready\n");
    } else {
        uint8_t selected = 0;
        for (uint8_t address = 0x28; address <= 0x29; ++address) {
            uint8_t chip = 0, page = 0;
            int result = read_reg(address, 0x00, &chip);
            (void)read_reg(address, 0x07, &page);
            if (!result && chip == 0xa0 && !selected) selected = address;
        }
        if (!selected) {
            printk("FAIL: no confirmed BNO055 at 0x28 or 0x29; no configuration writes attempted\n");
        } else {
            printk("STARTUP selected address=0x%02x external crystal requested\n", selected);
            int result = startup(selected);
            printk("STARTUP result=%d (0 means register transactions completed, not full calibration)\n", result);
        }
    }
    printk("PROBE COMPLETE: halted; reset board to repeat\n");
    for (;;) k_msleep(1000);
}
