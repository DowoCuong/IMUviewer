/* SPDX-License-Identifier: MIT */
#include "imu_sensor.h"
#include "imu_calibration.h"
#include <errno.h>
#include <limits.h>
#include <string.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/atomic.h>

#ifndef CONFIG_IMU_BNO055_ADDRESS
#define CONFIG_IMU_BNO055_ADDRESS 41
#endif
#ifndef CONFIG_IMU_BYPASS_SAVED_CALIBRATION
#define CONFIG_IMU_BYPASS_SAVED_CALIBRATION 0
#endif

#if defined(CONFIG_IMU_SDA_PIN) && defined(CONFIG_IMU_SCL_PIN) && \
    CONFIG_IMU_SDA_PIN >= 0 && CONFIG_IMU_SCL_PIN >= 0
#define SENSOR_IO_ENABLED 1
#include <zephyr/drivers/i2c.h>
#include "bno055.h"
#else
#define SENSOR_IO_ENABLED 0
#endif

#define SAMPLE_PERIOD_US 10000ULL
#define CALIB_PERIOD_US 500000ULL
static struct k_spinlock cache_lock;
static struct imu_sample cache = { .state = IMU_INITIALIZING };
static struct imu_sensor_metrics stats;
static atomic_t pause_requested;
static atomic_t started;
static struct k_thread sensor_thread;
K_THREAD_STACK_DEFINE(sensor_stack, 2048);
static uint8_t io_reg;
static uint8_t io_phase;

#if SENSOR_IO_ENABLED
static uint32_t bounded_us(uint64_t value)
{
    return value > UINT32_MAX ? UINT32_MAX : (uint32_t)value;
}
#endif

void imu_sensor_snapshot(struct imu_sample *sample, struct imu_sensor_metrics *metrics)
{
    k_spinlock_key_t key = k_spin_lock(&cache_lock);
    if (sample) { *sample = cache; }
    if (metrics) { *metrics = stats; }
    k_spin_unlock(&cache_lock, key);
}

int imu_sensor_command(char command)
{
    switch (command) {
    case 'Q': return 0;
    case 'P': atomic_set(&pause_requested, 1); return 0;
    case 'R': atomic_clear(&pause_requested); return 0;
    default: return -EINVAL;
    }
}

static void sensor_fault(int error)
{
    k_spinlock_key_t key = k_spin_lock(&cache_lock);
    cache.state = IMU_SENSOR_FAULT;
    stats.diagnostic_valid = false;
    stats.errors++;
    stats.runtime_errors++;
    stats.consecutive_errors++;
    stats.last_error = error;
    stats.diagnostic_error = error;
    stats.last_error_reg = io_reg;
    stats.last_error_phase = io_phase;
    stats.last_error_us = (uint32_t)imu_clock_us();
    /* Preserve last successful quaternion, timestamp, sequence and validity. */
    k_spin_unlock(&cache_lock, key);
}

#if SENSOR_IO_ENABLED
/* One bounded mailbox, never a caller-owned pointer. The sensor thread is the
 * only Bosch/I2C owner. Concurrent callers fail with EBUSY rather than queuing
 * behind an unbounded I/O operation. All mailbox fields and completion signals
 * are protected by calib_lock; no lock is held over I/O or a blocking wait. */
enum calib_operation { CALIB_READ, CALIB_WRITE, CALIB_SAVE };
enum calib_state { CALIB_IDLE, CALIB_PENDING, CALIB_RUNNING, CALIB_ABANDONED, CALIB_DONE };
static struct k_spinlock calib_lock;
static K_SEM_DEFINE(calib_done, 0, 1);
static struct {
    enum calib_state state;
    enum calib_operation operation;
    uint8_t payload[22];
    int result;
} calib;

static int calib_transfer(enum calib_operation operation, const uint8_t *input,
                          uint8_t *output)
{
    if ((operation == CALIB_READ && !output) ||
        (operation == CALIB_WRITE && !input)) { return -EINVAL; }
    if (!atomic_get(&started)) { return -EAGAIN; }
    /* This synchronous API must not block its own worker or an ISR. */
    if (k_is_in_isr()) { return -EWOULDBLOCK; }
    if (k_current_get() == &sensor_thread) { return -EDEADLK; }

    k_spinlock_key_t key = k_spin_lock(&calib_lock);
    if (calib.state != CALIB_IDLE) {
        k_spin_unlock(&calib_lock, key);
        return -EBUSY;
    }
    k_sem_reset(&calib_done);
    calib.operation = operation;
    if (operation == CALIB_WRITE) { memcpy(calib.payload, input, sizeof(calib.payload)); }
    calib.state = CALIB_PENDING;
    k_spin_unlock(&calib_lock, key);

    (void)k_sem_take(&calib_done, K_SECONDS(2));
    key = k_spin_lock(&calib_lock);
    int result = -ETIMEDOUT;
    if (calib.state == CALIB_DONE) {
        /* Completion winning the timeout race is still a valid result. */
        result = calib.result;
        if (!result && operation == CALIB_READ) {
            memcpy(output, calib.payload, sizeof(calib.payload));
        }
        calib.state = CALIB_IDLE;
    } else if (calib.state == CALIB_PENDING) {
        calib.state = CALIB_IDLE; /* Cancel before any sensor side effect. */
    } else {
        /* In-flight I2C cannot be cancelled. Retain ownership until the worker
         * finishes, discard its response, and reject new requests meanwhile.
         * A timed-out write may still reach hardware, but no caller buffer or
         * later request can be touched by that abandoned transaction. */
        calib.state = CALIB_ABANDONED;
    }
    k_spin_unlock(&calib_lock, key);
    return result;
}
#endif /* SENSOR_IO_ENABLED */

int imu_sensor_calib_read(uint8_t payload[22])
{
#if SENSOR_IO_ENABLED
    return calib_transfer(CALIB_READ, NULL, payload);
#else
    ARG_UNUSED(payload);
    return -ENOTSUP;
#endif
}

int imu_sensor_calib_write(const uint8_t payload[22])
{
#if SENSOR_IO_ENABLED
    return calib_transfer(CALIB_WRITE, payload, NULL);
#else
    ARG_UNUSED(payload);
    return -ENOTSUP;
#endif
}

int imu_sensor_save(void)
{
#if SENSOR_IO_ENABLED
    /* Read + persistence are one worker operation: acquisition stays idle
     * through NVS programming, independently of the user's P/R state. */
    return calib_transfer(CALIB_SAVE, NULL, NULL);
#else
    return -ENOTSUP;
#endif
}

int imu_sensor_load(void)
{
#if SENSOR_IO_ENABLED
    uint8_t payload[22];
    int result = imu_calibration_fetch(payload);
    if (result) { return result; }
    result = imu_sensor_calib_write(payload);
    /* Applying valid saved calibration does not require the status byte to
     * read 3 immediately afterwards; the periodic status read decides state. */
    return result;
#else
    return -ENOTSUP;
#endif
}

#if SENSOR_IO_ENABLED
static const struct device *const sensor_bus = DEVICE_DT_GET(DT_NODELABEL(i2c0));
static struct bno055_t bosch;
/* Only the dedicated sensor thread accesses Bosch's global instance or I2C. */
static int io_error;

static s8 bus_read(u8 address, u8 reg, u8 *data, u8 length)
{
    if (io_error) { return -1; }
    int result = i2c_burst_read(sensor_bus, address, reg, data, length);
    if (result) { io_reg = reg; io_error = result; return -1; }
    return 0;
}

static s8 bus_write(u8 address, u8 reg, u8 *data, u8 length)
{
    if (io_error) { return -1; }
    int result = i2c_burst_write(sensor_bus, address, reg, data, length);
    if (result) { io_reg = reg; io_error = result; return -1; }
    return 0;
}

static void delay_ms(u32 ms) { k_msleep(ms); }

static int api_result(s8 result)
{
    return io_error ? io_error : (result ? -EIO : 0);
}

static int write_reg(uint8_t reg, uint8_t value)
{
    io_reg = reg; io_phase = 2;
    io_error = 0;
    return api_result(bno055_write_register(reg, &value, 1));
}

static int read_reg(uint8_t reg, uint8_t *value)
{
    io_reg = reg; io_phase = 1;
    io_error = 0;
    return api_result(bno055_read_register(reg, value, 1));
}

/* BNO055 offsets/radii are page ZERO, 0x55..0x6a. Both reads and writes
 * require CONFIG mode. The caller establishes page/mode and settling time. */
static int calib_registers(enum calib_operation operation, uint8_t payload[22])
{
    for (unsigned i = 0; i < 22; ++i) {
        int result = operation == CALIB_READ ? read_reg(0x55 + i, &payload[i]) :
                                              write_reg(0x55 + i, payload[i]);
        if (result) { return result; }
    }
    return 0;
}

static int calib_transaction(enum calib_operation operation, uint8_t payload[22])
{
    int result = write_reg(0x07, 0x00);
    if (!result) { result = write_reg(0x3d, 0x00); }
    /* NDOF -> CONFIG needs 19 ms; even a failed write may have taken effect. */
    k_msleep(20);
    if (!result) { result = calib_registers(operation, payload); }
    if (!result && operation == CALIB_WRITE) {
        uint8_t verify[22];
        result = calib_registers(CALIB_READ, verify);
        if (!result && memcmp(payload, verify, sizeof(verify)) != 0) { result = -EIO; }
    }

    /* Try cleanup even on a partial transfer/failed CONFIG transition. Never
     * let a cleanup success hide the original failure. If page selection fails,
     * do not write a mode register on an unknown page; the loop reinitializes. */
    int restore = write_reg(0x07, 0x00);
    if (!restore) {
        bosch.page_id = 0;
        restore = write_reg(0x3d, 0x0c);
        k_msleep(20); /* CONFIG -> NDOF needs 7 ms; preserve startup settling. */
    }
    return result ? result : restore;
}

/* Called even when acquisition is paused. Claim/copy and publish happen under
 * the same lock as cancellation. No request can replace an in-flight one. */
static bool calib_serve(int unavailable, int *error, bool *transitioned)
{
    uint8_t payload[22];
    *error = 0;
    *transitioned = false;
    k_spinlock_key_t key = k_spin_lock(&calib_lock);
    if (calib.state != CALIB_PENDING) {
        k_spin_unlock(&calib_lock, key);
        return false;
    }
    enum calib_operation operation = calib.operation;
    if (operation == CALIB_WRITE) { memcpy(payload, calib.payload, sizeof(payload)); }
    calib.state = CALIB_RUNNING;
    k_spin_unlock(&calib_lock, key);

    int result = unavailable;
    if (!result && operation == CALIB_SAVE) {
        uint8_t fresh = 0;
        *error = read_reg(0x35, &fresh);
        result = *error ? *error : (fresh == 0xff ? 0 : -EAGAIN);
    }
    if (!result) {
        *transitioned = true;
        *error = calib_transaction(operation == CALIB_SAVE ? CALIB_READ : operation, payload);
        result = *error;
    }
    if (!result && operation == CALIB_SAVE) {
        /* S remains on the sensor worker until synchronous NVS programming
         * completes. Do not turn a storage failure into a sensor reset. */
        result = imu_calibration_store(payload);
    }
    key = k_spin_lock(&calib_lock);
    if (calib.state == CALIB_ABANDONED) {
        calib.state = CALIB_IDLE;
    } else {
        calib.result = result;
        if (!result && operation == CALIB_READ) {
            memcpy(calib.payload, payload, sizeof(payload));
        }
        calib.state = CALIB_DONE;
        /* Signal before unlocking: a late give must never wake a new caller. */
        k_sem_give(&calib_done);
    }
    k_spin_unlock(&calib_lock, key);
    return true;
}

static int initialize_sensor(void)
{
    if (!device_is_ready(sensor_bus)) { return -ENODEV; }
    bosch.dev_addr = (uint8_t)CONFIG_IMU_BNO055_ADDRESS;
    bosch.bus_read = bus_read;
    bosch.bus_write = bus_write;
    bosch.delay_msec = delay_ms;
    io_error = 0;
    k_spinlock_key_t key = k_spin_lock(&cache_lock);
    if (stats.init_count) { stats.recovery_count++; }
    stats.init_count++;
    stats.diagnostic_valid = false;
    stats.address = bosch.dev_addr;
    stats.nvs_state = CONFIG_IMU_BYPASS_SAVED_CALIBRATION ? 4 : 0;
    k_spin_unlock(&cache_lock, key);
    io_phase = 1;
    int result = api_result(bno055_init(&bosch));
    if (result) { return result; }
    if (bosch.chip_id != 0xa0) { return -ENODEV; }
    key = k_spin_lock(&cache_lock);
    stats.chip_id = bosch.chip_id;
    stats.sw_revision = (uint8_t)bosch.sw_rev_id;
    stats.page = bosch.page_id;
    k_spin_unlock(&cache_lock, key);

    /* Mirror the authoritative Adafruit 5.4.22 reset and initialization.
     * Do not use Bosch's 600ms operation-mode helper for these transitions. */
    result = write_reg(0x3d, 0x00);
    if (result) { return result; }
    k_msleep(20);
    result = write_reg(0x3f, 0x20);
    /* A reset may terminate its own I2C transaction. Record that error, then
     * verify chip recovery rather than treating a NACK as a successful read. */
    if (result) {
        key = k_spin_lock(&cache_lock);
        stats.errors++;
        stats.reset_errors++;
        stats.last_error = result;
        stats.diagnostic_error = result;
        stats.last_error_reg = 0x3f;
        stats.last_error_phase = 2;
        stats.last_error_us = (uint32_t)imu_clock_us();
        k_spin_unlock(&cache_lock, key);
    }
    k_msleep(700);
    uint8_t chip;
    result = read_reg(0x00, &chip);
    if (result) { return result; }
    if (chip != 0xa0) { return -ENODEV; }

    const uint8_t setup[][2] = {
        {0x3e, 0x00}, /* Normal power. */
        {0x07, 0x00}, /* Page zero. */
        {0x3f, 0x00}, /* Internal oscillator, no external crystal. */
        {0x07, 0x01}, /* Sensor configuration page. */
    };
    for (size_t i = 0; i < sizeof(setup) / sizeof(setup[0]); ++i) {
        result = write_reg(setup[i][0], setup[i][1]);
        if (result) { return result; }
    }
    /* Preserve reset bandwidth/power bits as the Python properties do. */
    const uint8_t config[][3] = {
        {0x08, 0xfc, 0x01}, /* Accelerometer 4g. */
        {0x0a, 0x38, 0x00}, /* Gyroscope 2000 dps. */
        {0x09, 0x78, 0x05}, /* Magnetometer 20Hz. */
    };
    for (size_t i = 0; i < sizeof(config) / sizeof(config[0]); ++i) {
        uint8_t value;
        result = read_reg(config[i][0], &value);
        if (result) { return result; }
        result = write_reg(config[i][0], (value & config[i][1]) | config[i][2]);
        if (result) { return result; }
    }
    result = write_reg(0x07, 0x00);
    if (result) { return result; }
    bosch.page_id = 0;
    /* Unit selection and axis mapping are intentionally left at reset defaults. */
    k_msleep(10);
    result = write_reg(0x3d, 0x00);
    if (result) { return result; }
    k_msleep(20);
    /* Persistence is mounted by imu_main before this thread starts. Apply a
     * validated record while still in page-0 CONFIG, before the first NDOF.
     * Missing/invalid/unavailable storage must not prevent uncalibrated use.
     * A sensor write failure, however, requires reset/retry rather than running
     * with a partially applied record. Repeat this after recovery resets too. */
    uint8_t saved[22];
    int saved_result = CONFIG_IMU_BYPASS_SAVED_CALIBRATION ? -EACCES : imu_calibration_fetch(saved);
    key = k_spin_lock(&cache_lock);
    if (saved_result == 0) { stats.nvs_state = 3; } /* Not applied until verified. */
    else if (saved_result == -ENOENT) { stats.nvs_state = 1; }
    else if (saved_result == -EACCES) { stats.nvs_state = 4; }
    else { stats.nvs_state = 3; }
    k_spin_unlock(&cache_lock, key);
    if (saved_result == 0) {
        result = calib_registers(CALIB_WRITE, saved);
        if (result) { return result; }
        uint8_t verify[22];
        result = calib_registers(CALIB_READ, verify);
        if (result || memcmp(saved, verify, sizeof(verify)) != 0) {
            return result ? result : -EIO;
        }
        key = k_spin_lock(&cache_lock);
        stats.nvs_state = 2;
        k_spin_unlock(&cache_lock, key);
    }
    result = write_reg(0x3d, 0x0c); /* NDOF. */
    if (result) { return result; }
    k_msleep(10);
    k_msleep(10);
    key = k_spin_lock(&cache_lock);
    stats.opr_mode = 0x0c;
    stats.pwr_mode = 0;
    stats.page = 0;
    k_spin_unlock(&cache_lock, key);
    return 0;
}

/* Read page-zero observables without changing mode or triggering self-test.
 * Failure is diagnostic only: calibration/read scheduling must not reset the
 * sensor merely because a low-rate telemetry read was transiently lost. */
static void diagnostic_poll(uint8_t calibration)
{
    uint8_t status[9] = {0};
    uint8_t accel[6] = {0};
    int status_error, accel_error;
    io_phase = 3; io_reg = 0x36; io_error = 0;
    status_error = api_result(bno055_read_register(0x36, status, sizeof(status)));
    io_phase = 3; io_reg = 0x08; io_error = 0;
    accel_error = api_result(bno055_read_register(0x08, accel, sizeof(accel)));
    k_spinlock_key_t key = k_spin_lock(&cache_lock);
    stats.calib_raw = calibration;
    stats.diagnostic_valid = !status_error && !accel_error;
    stats.diagnostic_us = imu_clock_us();
    if (!status_error) {
        stats.st_result = status[0];  /* 0x36 */
        stats.sys_status = status[3]; /* 0x39 */
        stats.sys_error = status[4];  /* 0x3a */
        stats.unit_sel = status[5];   /* 0x3b */
        stats.opr_mode = status[7];   /* 0x3d */
        stats.pwr_mode = status[8];   /* 0x3e */
    }
    if (!accel_error) {
        for (unsigned i = 0; i < 3; ++i) {
            stats.accel[i] = (int16_t)((uint16_t)accel[2*i] | ((uint16_t)accel[2*i+1] << 8));
        }
    }
    if (status_error || accel_error) {
        stats.errors++;
        stats.runtime_errors++;
        stats.diagnostic_error = status_error ? status_error : accel_error;
        stats.last_error_reg = status_error ? 0x36 : 0x08;
        stats.last_error_phase = 3;
        stats.last_error_us = (uint32_t)imu_clock_us();
    }
    k_spin_unlock(&cache_lock, key);
}

/* Retry transient bus failures in the sensor thread; persistent failure enters
 * recovery. Radio callbacks and timer ISRs never call these helpers. */
static void record_retry_failure(int error)
{
    k_spinlock_key_t key = k_spin_lock(&cache_lock);
    stats.errors++;
    stats.runtime_errors++;
    stats.consecutive_errors++;
    stats.diagnostic_error = error;
    stats.last_error_reg = io_reg;
    stats.last_error_phase = io_phase;
    stats.last_error_us = (uint32_t)imu_clock_us();
    k_spin_unlock(&cache_lock, key);
}

static int read_calibration_status(uint8_t *value)
{
    int error = -EIO;
    for (unsigned attempt = 0; attempt < 3; ++attempt) {
        error = read_reg(0x35, value);
        if (!error) { return 0; }
        if (attempt != 2) { record_retry_failure(error); k_msleep(1); }
    }
    return error;
}

static int read_quaternion_retry(struct bno055_quaternion_t *quaternion)
{
    int error = -EIO;
    for (unsigned attempt = 0; attempt < 3; ++attempt) {
        io_error = 0; io_reg = 0x20; io_phase = 4;
        error = api_result(bno055_read_quaternion_wxyz(quaternion));
        if (!error) { return 0; }
        if (attempt != 2) { record_retry_failure(error); k_busy_wait(100); }
    }
    return error;
}
#endif

static void sensor_run(void *a, void *b, void *c)
{
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
#if SENSOR_IO_ENABLED
    bool initialized = false;
    uint64_t due = 0, calib_due = 0;
    uint8_t calibration = 0;
    bool calibrated = false;
#endif
    for (;;) {
        bool paused = atomic_get(&pause_requested) != 0;
        k_spinlock_key_t key = k_spin_lock(&cache_lock);
        stats.paused = paused;
        k_spin_unlock(&cache_lock, key);
#if SENSOR_IO_ENABLED
        if (!initialized && !paused) {
            int result = initialize_sensor();
            if (result) {
                sensor_fault(result);
                int request_error;
                bool transitioned;
                (void)calib_serve(result, &request_error, &transitioned);
                k_msleep(1000);
                continue;
            }
            initialized = true;
            calibrated = false;
            calibration = 0;
            due = imu_clock_us();
            calib_due = due;
            key = k_spin_lock(&cache_lock);
            cache.state = IMU_CALIBRATING;
            cache.calibration = 0;
            stats.last_error = 0;
            k_spin_unlock(&cache_lock, key);
            continue; /* Honor a pause received during initialization. */
        }
        int request_error;
        bool transitioned;
        if (calib_serve(initialized ? 0 : -EAGAIN, &request_error, &transitioned)) {
            if (request_error && initialized) {
                /* Includes failed cleanup: do not acquire from an unknown mode. */
                sensor_fault(request_error);
                initialized = false;
                k_msleep(1000);
            } else if (initialized && transitioned) {
                /* A mode transition invalidates the old calibration status, not
                 * the last successful quaternion/timestamp/sequence. Re-query
                 * periodically after resume; never require status 3 for load. */
                calibration = 0;
                calibrated = false;
                key = k_spin_lock(&cache_lock);
                cache.calibration = 0;
                cache.state = IMU_CALIBRATING;
                k_spin_unlock(&cache_lock, key);
                due = imu_clock_us();
                calib_due = due;
            }
            continue; /* Recheck pause/resume before taking another sample. */
        }
#endif
        if (paused) {
            k_msleep(10);
#if SENSOR_IO_ENABLED
            due = imu_clock_us(); /* Pause time is not acquisition overrun. */
#endif
            continue;
        }
#if SENSOR_IO_ENABLED
        uint64_t now = imu_clock_us();
        if (!calibrated) {
            if (now < calib_due) { k_msleep(10); continue; }
            int error = read_calibration_status(&calibration);
            if (error) {
                sensor_fault(error);
                initialized = false;
                k_msleep(1000);
                continue;
            }
            diagnostic_poll(calibration);
            calib_due = imu_clock_us() + CALIB_PERIOD_US;
            key = k_spin_lock(&cache_lock);
            cache.calibration = calibration;
            cache.state = calibration == 0xff ? IMU_READY : IMU_CALIBRATING;
            k_spin_unlock(&cache_lock, key);
            if (calibration != 0xff) { k_msleep(10); continue; }
            calibrated = true;
            due = imu_clock_us(); /* Calibration wait is not missed acquisition. */
        }
        if (now < due) { k_usleep((int32_t)(due - now)); continue; }
        uint64_t skipped = (now - due) / SAMPLE_PERIOD_US;
        due += skipped * SAMPLE_PERIOD_US;
        uint32_t lateness = bounded_us(now - due);
        key = k_spin_lock(&cache_lock);
        stats.missed += (uint32_t)skipped;
        k_spin_unlock(&cache_lock, key);

        struct bno055_quaternion_t quaternion;
        uint64_t begin = imu_clock_us();
        int result = read_quaternion_retry(&quaternion);
        uint64_t completed = imu_clock_us(); /* Before any status query or lock. */
        int error = result;
        if (error) {
            sensor_fault(error);
            initialized = false;
            k_msleep(1000);
            continue;
        }
        key = k_spin_lock(&cache_lock);
        stats.interval_us = cache.valid ? bounded_us(completed - cache.completed_us) : 0;
        stats.duration_us = bounded_us(completed - begin);
        stats.lateness_us = lateness;
        stats.reads++;
        stats.last_error = 0;
        stats.consecutive_errors = 0;
        cache.q[0] = quaternion.w; cache.q[1] = quaternion.x;
        cache.q[2] = quaternion.y; cache.q[3] = quaternion.z;
        cache.completed_us = completed;
        cache.seq++;
        cache.valid = true;
        cache.calibration = calibration;
        cache.state = calibration == 0xff ? IMU_READY : IMU_CALIBRATING;
        k_spin_unlock(&cache_lock, key);
        due += SAMPLE_PERIOD_US;

        if (completed >= calib_due) {
            error = read_calibration_status(&calibration);
            if (error) {
                sensor_fault(error);
                initialized = false;
                k_msleep(1000);
                continue;
            }
            diagnostic_poll(calibration);
            calib_due = imu_clock_us() + CALIB_PERIOD_US;
            key = k_spin_lock(&cache_lock);
            cache.calibration = calibration;
            cache.state = calibration == 0xff ? IMU_READY : IMU_CALIBRATING;
            k_spin_unlock(&cache_lock, key);
        }
        /* Never run an overdue slot immediately after a long transaction. */
        now = imu_clock_us();
        if (now >= due) {
            skipped = (now - due) / SAMPLE_PERIOD_US + 1;
            due += skipped * SAMPLE_PERIOD_US;
            key = k_spin_lock(&cache_lock);
            stats.missed += (uint32_t)skipped;
            k_spin_unlock(&cache_lock, key);
        }
#else
        /* No inferred GPIOs: this build cannot touch a sensor or emit fake data. */
        sensor_fault(-ENODEV);
        k_msleep(1000);
#endif
    }
}

void imu_sensor_start(void)
{
    if (!atomic_cas(&started, 0, 1)) { return; }
    k_thread_create(&sensor_thread, sensor_stack, K_THREAD_STACK_SIZEOF(sensor_stack),
                    sensor_run, NULL, NULL, NULL, 5, 0, K_NO_WAIT);
    k_thread_name_set(&sensor_thread, "imu_sensor");
}
