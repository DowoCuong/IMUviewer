/* SPDX-License-Identifier: MIT */
#ifndef IMU_CALIBRATION_H
#define IMU_CALIBRATION_H
#include <stdint.h>

/* 22-byte BNO055 calibration register payload: page-0 0x55..0x6A in CONFIG mode,
 * little-endian s16 accel xyz, mag xyz, gyro xyz, accel radius, mag radius.
 * Persistence lives in the fixed storage partition (NVS), keyed by node ID;
 * versioned + CRC-validated records. Application/bootloader regions untouched. */
int imu_calibration_store(const uint8_t payload[22]);
int imu_calibration_fetch(uint8_t payload[22]);
int imu_calibration_erase(void);
#endif
