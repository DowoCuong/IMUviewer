/* SPDX-License-Identifier: MIT */
#ifndef IMU_PROTOCOL_H
#define IMU_PROTOCOL_H
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#define IMU_VERSION 1
#define IMU_DATA 1
#define IMU_STATUS 2
#define IMU_BEACON 3
#define IMU_FOLLOWUP 4
#define IMU_DIAG 5
#define IMU_STATS 6
#define IMU_SENSOR_DIAG 7
#define IMU_COMMAND_ACK 8
#define IMU_TIMED_DATA 9
#define IMU_VALID 1
#define IMU_SYNCED 2
#define IMU_STALE 4
#define IMU_PAUSED 8
#define IMU_DATA_LEN 40
#define IMU_CONTROL_LEN 32
#define IMU_DIAG_LEN 40
#define IMU_STATS_LEN 64
#define IMU_SENSOR_DIAG_LEN 64
#define IMU_COMMAND_ACK_LEN 24
#define IMU_TIMED_DATA_LEN 64
#define IMU_MAX_LEN 64
#define IMU_INITIALIZING 0
#define IMU_CALIBRATING 1
#define IMU_READY 2
#define IMU_SENSOR_FAULT 3
static inline void imu_put16(uint8_t *p, uint16_t v) { p[0]=v; p[1]=v>>8; }
static inline void imu_put32(uint8_t *p, uint32_t v) { for(int i=0;i<4;i++) p[i]=v>>(8*i); }
static inline void imu_put64(uint8_t *p, uint64_t v) { for(int i=0;i<8;i++) p[i]=v>>(8*i); }
static inline uint16_t imu_get16(const uint8_t *p) { return p[0] | (uint16_t)p[1]<<8; }
static inline uint32_t imu_get32(const uint8_t *p) { uint32_t v=0; for(int i=3;i>=0;i--) v=(v<<8)|p[i]; return v; }
static inline uint64_t imu_get64(const uint8_t *p) { uint64_t v=0; for(int i=7;i>=0;i--) v=(v<<8)|p[i]; return v; }
struct imu_sample {
    uint32_t seq;
    uint64_t completed_us;
    int16_t q[4];
    uint8_t calibration, state;
    bool valid;
};
static inline void imu_header(uint8_t *p, uint8_t type, uint8_t node, uint8_t flags,
                              uint32_t session, uint32_t tx, uint32_t read) {
    memset(p,0,IMU_MAX_LEN); p[0]=IMU_VERSION; p[1]=type; p[2]=node; p[3]=flags;
    imu_put32(p+4,session); imu_put32(p+8,tx); imu_put32(p+12,read);
}
static inline void imu_encode_sample(uint8_t *p, uint8_t node, uint32_t session,
                                     uint32_t tx, const struct imu_sample *s,
                                     uint8_t flags, uint32_t age) {
    imu_header(p,s->valid?IMU_DATA:IMU_STATUS,node,flags | (s->valid?IMU_VALID:0),session,tx,s->seq);
    imu_put64(p+16,s->completed_us);
    for(int i=0;i<4;i++) imu_put16(p+24+2*i,(uint16_t)s->q[i]);
    p[32]=s->calibration; p[33]=s->state; imu_put32(p+36,age);
}
static inline bool imu_validate(const uint8_t *p, size_t n, unsigned nodes) {
    if(n<4 || p[0]!=IMU_VERSION || nodes<1 || nodes>4 || (p[3]&0xf0)) return false;
    switch(p[1]) {
    case IMU_DATA: case IMU_STATUS:
        return n==IMU_DATA_LEN && p[2]>=1 && p[2]<=nodes && p[33]<=IMU_SENSOR_FAULT &&
               !p[34] && !p[35] && ((p[1]==IMU_DATA)==!!(p[3]&IMU_VALID));
    case IMU_TIMED_DATA:
        return n==IMU_TIMED_DATA_LEN && p[2]>=1 && p[2]<=nodes &&
               (p[3] & (IMU_VALID|IMU_SYNCED))==(IMU_VALID|IMU_SYNCED) &&
               p[33]<=IMU_SENSOR_FAULT && !p[34] && !p[35] &&
               (int32_t)imu_get32(p+48)>=-200 && (int32_t)imu_get32(p+48)<=200 &&
               imu_get32(p+52)<=50 && imu_get32(p+60)<=30000;
    case IMU_BEACON: case IMU_FOLLOWUP:
        return n==IMU_CONTROL_LEN && p[2]==0 && p[3]==0;
    case IMU_DIAG: return n==IMU_DIAG_LEN && p[2]>=1 && p[2]<=nodes;
    case IMU_STATS: return n==IMU_STATS_LEN && p[2]<=nodes;
    case IMU_SENSOR_DIAG:
        return n==IMU_SENSOR_DIAG_LEN && p[2]>=1 && p[2]<=nodes && !(p[3]&IMU_SYNCED) &&
               (!p[46] || p[46]==0x28 || p[46]==0x29) &&
               (!p[47] || p[47]==100) && p[55]<=4;
    case IMU_COMMAND_ACK:
        return n==IMU_COMMAND_ACK_LEN && p[2]<=nodes && !p[3] && !p[19] &&
               p[17]<=4 && p[18]<=IMU_SENSOR_FAULT && p[16] && strchr("QSLCPR", p[16]);
    default: return false;
    }
}
/* Modular comparisons require intervals shorter than 2^31 microseconds. */
static inline int32_t imu_delta(uint32_t a,uint32_t b) { return (int32_t)(a-b); }
static inline uint32_t imu_skip(uint32_t now,uint32_t *due,uint32_t period) {
    int32_t late=imu_delta(now,*due);
    if(late<=0) return 0;
    uint32_t n=((uint32_t)late-1)/period+1; *due+=n*period; return n;
}
#endif
