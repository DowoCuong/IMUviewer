/* SPDX-License-Identifier: MIT */
#ifndef IMU_SYNC_H
#define IMU_SYNC_H
#include "imu_protocol.h"

#define IMU_FRAME_US 40000U
#define IMU_PAIR_TIMEOUT_US 3000U
#define IMU_SYNC_TIMEOUT_US 120000U
#define IMU_SYNC_TOLERANCE_US 50U
#define IMU_SLOT_US 1000U
/* Nominal average rates: deliberately no sensor packets during sync gap.
 * 400 Hz: 16 pairs at 5,7,...35 ms. 100 Hz: four at 5,15,25,35 ms.
 * One-node mode retains the same 1 ms slot, leaving the second slot empty.
 */
static inline unsigned imu_slot_count(unsigned hz) { return hz == 400 ? 16 : 4; }
static inline uint32_t imu_slot_offset(unsigned hz, unsigned index, unsigned node)
{
    return 5000U + index * (hz == 400 ? 2000U : 10000U) + (node - 1U) * IMU_SLOT_US;
}
static inline bool imu_slot_open(uint32_t now, uint32_t start)
{
    int32_t late = imu_delta(now, start);
    return late >= 0 && late <= 100 && imu_delta(start + IMU_SLOT_US, now) >= 800;
}
struct imu_sync {
    bool session_valid, pending, observed, locked;
    uint32_t session, seq, frame, beacon_rx;
    uint32_t pending_seq, pending_frame, pending_rx;
    uint32_t hub_anchor, local_anchor, last_pair;
    int32_t ppm;
    uint32_t uncertainty_us;
    unsigned pairs;
};
static inline void imu_sync_reset(struct imu_sync *s) { memset(s, 0, sizeof(*s)); }
static inline uint32_t imu_sync_local(const struct imu_sync *s, uint32_t hub)
{
    int32_t d = imu_delta(hub, s->hub_anchor);
    return s->local_anchor + d + (int32_t)((int64_t)d * s->ppm / 1000000);
}
static inline bool imu_sync_expire(struct imu_sync *s, uint32_t now)
{
    bool lost = s->locked;
    if (s->pending && imu_delta(now, s->pending_rx) > (int32_t)IMU_PAIR_TIMEOUT_US) s->pending = false;
    if (s->observed && imu_delta(now, s->last_pair) >= (int32_t)IMU_SYNC_TIMEOUT_US) {
        imu_sync_reset(s);
        return lost;
    }
    return false;
}
/* Call only with accepted ESB data and its associated hardware RX END.
 * Return -1 invalid/unmatched, 0 beacon/duplicate, 1 new matched observation.
 * Software fit and 50 us gate are conservative estimates, NOT hardware proof.
 */
static inline int imu_sync_receive(struct imu_sync *s, const uint8_t *p, size_t n,
                                   uint32_t rx, unsigned nodes, unsigned hz)
{
    if (!imu_validate(p, n, nodes) || (p[1] != IMU_BEACON && p[1] != IMU_FOLLOWUP) ||
        imu_get32(p + 24) != IMU_FRAME_US || p[28] != nodes ||
        p[29] != (hz == 400 ? 1 : 0) || p[30] || p[31] || imu_get32(p + 12)) return -1;
    uint32_t session = imu_get32(p + 4), seq = imu_get32(p + 8), frame = imu_get32(p + 20);
    if (p[1] == IMU_BEACON) {
        if (imu_get32(p + 16) != frame) return -1;
        if (!s->session_valid || s->session != session) {
            imu_sync_reset(s); s->session_valid = true; s->session = session;
        }
        if (s->observed && imu_delta(seq, s->seq) <= 0) return 0;
        if (s->pending && seq == s->pending_seq) return 0;
        s->pending = true; s->pending_seq = seq; s->pending_frame = frame; s->pending_rx = rx;
        return 0;
    }
    if (s->observed && session == s->session && seq == s->seq) return 0;
    if (!s->pending || session != s->session || seq != s->pending_seq ||
        frame != s->pending_frame || imu_delta(rx, s->pending_rx) <= 0 ||
        imu_delta(rx, s->pending_rx) > (int32_t)IMU_PAIR_TIMEOUT_US) return -1;
    uint32_t hub = imu_get32(p + 16), local = s->pending_rx;
    s->pending = false;
    /* Beacon must actually finish inside its reserved first millisecond. */
    if (imu_delta(hub, frame) < 0 || imu_delta(hub, frame) > 1000) return -1;
    bool good = false;
    int32_t residual = 0, ppm = 0;
    if (s->observed) {
        int32_t dh = imu_delta(hub, s->hub_anchor), dl = imu_delta(local, s->local_anchor);
        uint32_t steps = seq - s->seq;
        if (dh > 0 && dh < (int32_t)IMU_SYNC_TIMEOUT_US && dl > 0 &&
            steps <= 3 && frame - s->frame == steps * IMU_FRAME_US) {
            ppm = (int32_t)((int64_t)(dl - dh) * 1000000 / dh);
            residual = imu_delta(local, imu_sync_local(s, hub));
            good = ppm >= -200 && ppm <= 200 && residual >= -34 && residual <= 34;
            if (!good && s->locked && residual >= -(int32_t)IMU_SYNC_TOLERANCE_US &&
                residual <= (int32_t)IMU_SYNC_TOLERANCE_US) {
                /* Keep a previously valid fit for one noisy observation only
                 * when its accumulated bound covers the END of this frame.
                 * Never move the fit anchors or last GOOD pair on rejection. */
                uint32_t horizon = (uint32_t)dh + IMU_FRAME_US - (hub - frame);
                uint32_t drift = (horizon * 400U + 999999U) / 1000000U;
                uint32_t observed = (uint32_t)(((int64_t)(residual < 0 ? -residual : residual) *
                                               horizon + dh - 1) / dh);
                uint32_t uncertainty = s->uncertainty_us + (drift > observed ? drift : observed);
                if (uncertainty <= IMU_SYNC_TOLERANCE_US) {
                    s->uncertainty_us = uncertainty;
                    s->seq = seq; s->frame = frame; s->beacon_rx = local;
                    return 1;
                }
            }
        }
    }
    if (!good) { s->pairs = 1; s->ppm = 0; s->locked = false; s->uncertainty_us = 50; }
    else {
        s->ppm = s->pairs == 1 ? ppm : (3 * s->ppm + ppm) / 4;
        if (s->pairs < 3) ++s->pairs;
        /* Up to 400 ppm relative error between bounded fit and actual drift
         * costs <16 us across the remaining frame, plus measured residual. */
        s->uncertainty_us = (uint32_t)(residual < 0 ? -residual : residual) + 16;
        s->locked = s->pairs >= 3 && s->uncertainty_us <= IMU_SYNC_TOLERANCE_US;
    }
    s->observed = true; s->seq = seq; s->frame = frame; s->beacon_rx = local;
    s->hub_anchor = hub; s->local_anchor = local; s->last_pair = rx;
    return 1;
}
static inline bool imu_sync_current(const struct imu_sync *s, uint32_t now)
{
    int32_t age = imu_delta(now, imu_sync_local(s, s->frame));
    return s->locked && s->uncertainty_us <= IMU_SYNC_TOLERANCE_US && age >= 0 &&
           age < (int32_t)IMU_FRAME_US && imu_delta(now, s->last_pair) < (int32_t)IMU_SYNC_TIMEOUT_US;
}

/* Portable focused tests: cc -x c -DIMU_SYNC_TEST imu_sync.h -o sync-test */
#ifdef IMU_SYNC_TEST
#include <assert.h>
static void imu_test_control(uint8_t *p, unsigned type, uint32_t session, uint32_t seq, uint32_t frame)
{
    imu_header(p, type, 0, 0, session, seq, 0);
    imu_put32(p + 16, frame + (type == IMU_FOLLOWUP ? 240 : 0));
    imu_put32(p + 20, frame); imu_put32(p + 24, IMU_FRAME_US); p[28] = 2; p[29] = 1;
}
int main(void)
{
    struct imu_sync s = {0}; uint8_t p[IMU_MAX_LEN];
    uint32_t frame = 0xffff0000U, local = 0xfffe0000U;
    for (unsigned i = 0; i < 6; ++i) {
        uint32_t f = frame + i * IMU_FRAME_US, r = local + i * 40004U;
        imu_test_control(p, IMU_BEACON, 10, i, f);
        assert(imu_sync_receive(&s, p, 32, r, 2, 400) == 0);
        assert(imu_sync_receive(&s, p, 32, r + 1, 2, 400) == 0);
        imu_test_control(p, IMU_FOLLOWUP, 10, i, f);
        assert(imu_sync_receive(&s, p, 32, r + 1200, 2, 400) == 1);
        assert(s.locked == (i >= 2));
        assert(imu_sync_receive(&s, p, 32, r + 1201, 2, 400) == 0);
        if (i >= 2) {
            assert(s.ppm == 100); assert(imu_sync_current(&s, r + 5000));
            assert(!imu_sync_current(&s, r + 41000)); /* missing next beacon => silent */
        }
    }
    assert(imu_sync_expire(&s, s.last_pair + IMU_SYNC_TIMEOUT_US)); assert(!s.locked);
    imu_test_control(p, IMU_BEACON, 11, 0, 1000);
    assert(imu_sync_receive(&s, p, 32, 2000, 2, 400) == 0);
    imu_test_control(p, IMU_FOLLOWUP, 11, 1, 1000);
    assert(imu_sync_receive(&s, p, 32, 3200, 2, 400) == -1);
    imu_test_control(p, IMU_FOLLOWUP, 11, 0, 1000);
    assert(imu_sync_receive(&s, p, 32, 5001, 2, 400) == -1);
    p[28] = 1; assert(imu_sync_receive(&s, p, 32, 3000, 2, 400) == -1);
    imu_test_control(p, IMU_BEACON, 12, 0, 1000);
    assert(imu_sync_receive(&s, p, 32, 2000, 2, 400) == 0); assert(s.pairs == 0);
    for (int drift = -8; drift <= 8; drift += 16) {
        imu_sync_reset(&s);
        for (unsigned i = 0; i < 4; ++i) {
            uint32_t f = 10000U + i * IMU_FRAME_US;
            uint32_t r = 900000U + i * (uint32_t)(40000 + drift);
            imu_test_control(p, IMU_BEACON, 20, i, f);
            assert(imu_sync_receive(&s, p, 32, r, 2, 400) == 0);
            imu_test_control(p, IMU_FOLLOWUP, 20, i, f);
            assert(imu_sync_receive(&s, p, 32, r + 1200, 2, 400) == 1);
        }
        assert(s.locked && s.ppm == drift * 25);
        /* Abrupt offset jump must discard lock rather than clamp drift. */
        imu_test_control(p, IMU_BEACON, 20, 4, 170000);
        assert(imu_sync_receive(&s, p, 32, 1060100, 2, 400) == 0);
        imu_test_control(p, IMU_FOLLOWUP, 20, 4, 170000);
        assert(imu_sync_receive(&s, p, 32, 1061300, 2, 400) == 1);
        assert(!s.locked && s.pairs == 1);
    }
    assert(imu_slot_count(100) == 4 && imu_slot_count(400) == 16);
    assert(imu_slot_offset(400, 15, 2) + IMU_SLOT_US == 37000);
    assert(imu_slot_offset(100, 3, 1) == 35000);
    assert(!imu_slot_open(99, 100)); assert(imu_slot_open(100, 100));
    assert(imu_slot_open(200, 100)); assert(!imu_slot_open(201, 100));
    assert(imu_slot_open(0, UINT32_MAX - 49));
    return 0;
}
#endif
#endif
