/* SPDX-License-Identifier: MIT */
/* Hub-side stubs: the hub owns no BNO055, so the sensor module is not
 * linked. These stubs keep the shared core honest: no valid sample is ever
 * invented, and calibration commands report ENOTSUP instead of pretending. */
#include <errno.h>
#include <zephyr/kernel.h>
#include "imu_sensor.h"

void imu_sensor_start(void) { /* No sensor on the hub. */ }

void imu_sensor_snapshot(struct imu_sample *sample, struct imu_sensor_metrics *metrics)
{
    if (sample) {
        sample->seq = 0;
        sample->completed_us = 0;
        sample->q[0] = sample->q[1] = sample->q[2] = sample->q[3] = 0;
        sample->calibration = 0;
        sample->state = IMU_SENSOR_FAULT;
        sample->valid = false;
    }
    if (metrics) {
        memset(metrics, 0, sizeof(*metrics));
        metrics->reads = 0; metrics->errors = 0; metrics->missed = 0;
        metrics->interval_us = 0; metrics->duration_us = 0; metrics->lateness_us = 0;
        metrics->last_error = 0; metrics->paused = false;
        metrics->init_count = metrics->recovery_count = 0;
        metrics->reset_errors = metrics->runtime_errors = 0;
        metrics->consecutive_errors = metrics->last_error_us = 0;
        metrics->last_error_reg = metrics->last_error_phase = 0;
        metrics->address = metrics->calib_raw = metrics->sys_status = 0;
        metrics->sys_error = metrics->unit_sel = metrics->opr_mode = metrics->pwr_mode = metrics->page = 0;
        metrics->nvs_state = metrics->chip_id = metrics->sw_revision = metrics->st_result = 0;
        metrics->accel[0] = metrics->accel[1] = metrics->accel[2] = 0;
    }
}

int imu_sensor_command(char command)
{
    return command == 'Q' ? 0 : -ENOTSUP;
}

int imu_sensor_calib_read(uint8_t payload[22]) { ARG_UNUSED(payload); return -ENOTSUP; }
int imu_sensor_calib_write(const uint8_t payload[22]) { ARG_UNUSED(payload); return -ENOTSUP; }
int imu_sensor_save(void) { return -ENOTSUP; }
int imu_sensor_load(void) { return -ENOTSUP; }
