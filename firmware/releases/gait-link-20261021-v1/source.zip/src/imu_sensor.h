/* SPDX-License-Identifier: MIT */
#ifndef IMU_SENSOR_H
#define IMU_SENSOR_H
#include "imu_protocol.h"

struct imu_sensor_metrics {
    uint32_t reads, errors, missed;
    uint32_t interval_us, duration_us, lateness_us;
    int32_t last_error;
    int32_t diagnostic_error;
    uint64_t diagnostic_us;
    bool diagnostic_valid;
    bool paused;
    uint32_t init_count, recovery_count, reset_errors, runtime_errors;
    uint32_t consecutive_errors, last_error_us;
    uint8_t last_error_reg, last_error_phase;
    uint8_t address, calib_raw, sys_status, sys_error, unit_sel, opr_mode, pwr_mode, page;
    uint8_t nvs_state, chip_id, sw_revision, st_result;
    int16_t accel[3];
};

/* Supplied by the application; monotonic microseconds. */
uint64_t imu_clock_us(void);
void imu_sensor_start(void);
void imu_sensor_snapshot(struct imu_sample *sample, struct imu_sensor_metrics *metrics);
/* P/R request pause/resume; Q is observational. */
int imu_sensor_command(char command);
/* Calibration register payload (22 bytes, page 0 in CONFIG mode,
 * 0x55..0x6A, LE s16:
 * accel xyz, mag xyz, gyro xyz, accel radius, mag radius).
 * Executed on the dedicated sensor thread; bounded wait. Save needs the
     * sensor live. Save requires a fresh CALIB_STAT of 0xff. */
int imu_sensor_calib_read(uint8_t payload[22]);
int imu_sensor_calib_write(const uint8_t payload[22]);
/* High-level workflow: S reads registers and stores to NVS;
 * L fetches from NVS and writes registers. */
int imu_sensor_save(void);
int imu_sensor_load(void);
#endif
