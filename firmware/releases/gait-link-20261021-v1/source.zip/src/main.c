/*
 * ESB initialization adapted from Nordic Semiconductor's NCS ESB samples.
 * Copyright (c) 2018 Nordic Semiconductor ASA
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */
#include <esb.h>
#include <string.h>
#include <stdlib.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/counter.h>
#include <zephyr/random/random.h>
#include <zephyr/sys/atomic.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/sys/printk.h>
#include <zephyr/sys/crc.h>

#define MESSAGE "Hello"
#define PACKET_LEN (8 + sizeof(MESSAGE) - 1)
static const struct gpio_dt_spec led = GPIO_DT_SPEC_GET(DT_ALIAS(led0), gpios);
static const struct device *const console = DEVICE_DT_GET(DT_CHOSEN(zephyr_console));
BUILD_ASSERT(DT_NODE_HAS_COMPAT(DT_CHOSEN(zephyr_console), zephyr_cdc_acm_uart));

static bool monitor_open(void)
{
    uint32_t dtr = 0;
    return device_is_ready(console) &&
           uart_line_ctrl_get(console, UART_LINE_CTRL_DTR, &dtr) == 0 && dtr;
}

static void fatal(int err)
{
    while (true) {
        if (monitor_open()) { printk("ERROR %d: reset board after correcting configuration\n", err); }
        k_sleep(K_SECONDS(1));
    }
}

#if ESB_TEST_TRANSMITTER
K_SEM_DEFINE(tx_done, 0, 1);
static bool acknowledged;
static uint32_t attempts;
static const struct device *const latency_timer = DEVICE_DT_GET(DT_NODELABEL(timer3));
static uint32_t tx_start_us, tx_end_us;
static int timer_read_error;
static void event_handler(const struct esb_evt *event)
{
    if (event->evt_id == ESB_EVENT_TX_SUCCESS || event->evt_id == ESB_EVENT_TX_FAILED) {
        timer_read_error = counter_get_value(latency_timer, &tx_end_us);
        acknowledged = event->evt_id == ESB_EVENT_TX_SUCCESS;
        attempts = event->tx_attempts;
        k_sem_give(&tx_done);
    }
}
#else
struct reception { uint32_t session; uint32_t seq; int rssi; };
K_MSGQ_DEFINE(received, sizeof(struct reception), 32, 4);
static atomic_t queue_drops;
static atomic_t invalid_packets;
static void event_handler(const struct esb_evt *event)
{
    static struct esb_payload payload;
    if (event->evt_id != ESB_EVENT_RX_RECEIVED) { return; }
    while (esb_read_rx_payload(&payload) == 0) {
        if (payload.length != PACKET_LEN || memcmp(payload.data + 8, MESSAGE, sizeof(MESSAGE) - 1)) {
            atomic_inc(&invalid_packets);
            continue;
        }
        struct reception packet = {
            .session = sys_get_le32(payload.data),
            .seq = sys_get_le32(payload.data + 4),
            /* NCS 3.4 ESB supplies the positive RSSISAMPLE magnitude. */
            .rssi = -(int)payload.rssi,
        };
        if (k_msgq_put(&received, &packet, K_NO_WAIT)) { atomic_inc(&queue_drops); }
    }
}
#endif

static int radio_init(void)
{
    uint8_t base0[4] = {0xE7, 0xE7, 0xE7, 0xE7};
    uint8_t base1[4] = {0xC2, 0xC2, 0xC2, 0xC2};
    uint8_t prefixes[8] = {0xE7, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8};
    struct esb_config config = ESB_DEFAULT_CONFIG;
    config.protocol = ESB_PROTOCOL_ESB_DPL;
    config.bitrate = ESB_BITRATE_2MBPS;
    config.mode = ESB_TEST_TRANSMITTER ? ESB_MODE_PTX : ESB_MODE_PRX;
    config.event_handler = event_handler;
    config.selective_auto_ack = true;
    config.retransmit_delay = 600;
    config.retransmit_count = 3;
    config.tx_output_power = 0;
    int err = esb_init(&config);
    if (err) { return err; }
    if ((err = esb_set_base_address_0(base0))) { return err; }
    if ((err = esb_set_base_address_1(base1))) { return err; }
    if ((err = esb_set_prefixes(prefixes, ARRAY_SIZE(prefixes)))) { return err; }
    return esb_set_rf_channel(40);
}

#if defined(CONFIG_ESB_TEST_BENCHMARK)
#define BENCH_CAPACITY 48000
BUILD_ASSERT(CONFIG_ESB_TEST_PERIOD_US == 2500);
/* Little-endian word: bit31 ACK, bits24..27 attempts, bits0..23 time in us.
 * 192 KB retains every transaction for a 120-second run at 400 Hz. */
static uint32_t bench_records[BENCH_CAPACITY];
K_MSGQ_DEFINE(bench_commands, sizeof(unsigned char), 64, 1);
static atomic_t bench_command_overflow;

static void benchmark_uart_rx(const struct device *dev, void *unused)
{
    ARG_UNUSED(unused);
    if (!uart_irq_update(dev) || !uart_irq_rx_ready(dev)) { return; }
    unsigned char c;
    while (uart_fifo_read(dev, &c, 1) == 1) {
        if (k_msgq_put(&bench_commands, &c, K_NO_WAIT)) {
            atomic_set(&bench_command_overflow, 1);
        }
    }
}

static void benchmark_main(void)
{
    /* CDC ACM requires RX to be enabled to enqueue its USB OUT transfer.
     * poll_in alone does not arm that endpoint in this SDK. */
    int setup_err = uart_irq_callback_user_data_set(console, benchmark_uart_rx, NULL);
    if (setup_err) { fatal(setup_err); }
    uart_irq_rx_enable(console);
    char command[24];
    unsigned int command_len = 0;
    bool overflow = false;
    int64_t announce = 0;
    while (true) {
        unsigned char c;
        if (!monitor_open()) { k_msleep(20); continue; }
        if (k_uptime_get() >= announce) {
            printk("BENCH READY max_seconds=120 period_us=2500\n");
            announce = k_uptime_get() + 1000;
        }
        if (atomic_set(&bench_command_overflow, 0)) {
            k_msgq_purge(&bench_commands);
            command_len = 0;
            overflow = false;
            printk("BENCH ERROR command_overflow\n");
            continue;
        }
        if (k_msgq_get(&bench_commands, &c, K_NO_WAIT)) { k_msleep(5); continue; }
        if (c == '\r') { continue; }
        if (c != '\n') {
            if (command_len + 1 < sizeof(command)) { command[command_len++] = c; }
            else { overflow = true; }
            continue;
        }
        command[command_len] = 0;
        char *end = NULL;
        unsigned long seconds = command_len >= 3 && command[0] == 'S' && command[1] == ' '
                              ? strtoul(command + 2, &end, 10) : 0;
        command_len = 0;
        if (overflow || !end || *end || seconds < 1 || seconds > 120) {
            overflow = false;
            printk("BENCH ERROR expected_S_seconds_1_to_120\n");
            continue;
        }
        uint32_t session = sys_rand32_get();
        uint32_t count = 0, successes = 0, write_errors = 0, skipped = 0;
        struct esb_payload payload = {.length = PACKET_LEN, .pipe = 0, .noack = false};
        sys_put_le32(session, payload.data);
        memcpy(payload.data + 8, MESSAGE, sizeof(MESSAGE) - 1);
        printk("BENCH START session=%08x seconds=%u period_us=2500\n", session, (unsigned int)seconds);
        /* Let startup text drain before timing the run. */
        k_msleep(100);
        uint32_t window_start, window_end;
        int err = counter_get_value(latency_timer, &window_start);
        if (err) { fatal(err); }
        int64_t next_us = k_ticks_to_us_floor64(k_uptime_ticks());
        const int64_t deadline_us = next_us + (int64_t)seconds * 1000000;
        while (next_us < deadline_us) {
            if (k_ticks_to_us_floor64(k_uptime_ticks()) >= deadline_us) {
                skipped += (uint32_t)((deadline_us - next_us) / CONFIG_ESB_TEST_PERIOD_US);
                break;
            }
            if (count >= BENCH_CAPACITY) { fatal(-ENOMEM); }
            sys_put_le32(count, payload.data + 4);
            if ((err = counter_get_value(latency_timer, &tx_start_us))) { fatal(err); }
            err = esb_write_payload(&payload);
            if (err) { write_errors++; }
            else {
                if (k_sem_take(&tx_done, K_SECONDS(1))) { fatal(-ETIMEDOUT); }
                if (timer_read_error) { fatal(timer_read_error); }
                uint32_t elapsed = tx_end_us - tx_start_us;
                if (elapsed > 0xFFFFFF || attempts < 1 || attempts > 4) { fatal(-ERANGE); }
                bench_records[count++] = sys_cpu_to_le32(elapsed | (attempts << 24) |
                                                        (acknowledged ? BIT(31) : 0));
                if (acknowledged) { successes++; }
                else if ((err = esb_flush_tx())) { fatal(err); }
            }
            /* No per-packet USB output, GPIO updates, or statistics formatting. */
            next_us += CONFIG_ESB_TEST_PERIOD_US;
            int64_t now_us = k_ticks_to_us_floor64(k_uptime_ticks());
            if (now_us > next_us) {
                uint32_t missed = (uint32_t)((now_us - next_us - 1) / CONFIG_ESB_TEST_PERIOD_US + 1);
                uint32_t available = next_us < deadline_us
                                   ? (uint32_t)((deadline_us - next_us) / CONFIG_ESB_TEST_PERIOD_US) : 0;
                skipped += MIN(missed, available);
                next_us += (int64_t)missed * CONFIG_ESB_TEST_PERIOD_US;
            }
            if (next_us < deadline_us) { k_sleep(K_TIMEOUT_ABS_US(next_us)); }
        }
        k_sleep(K_TIMEOUT_ABS_US(deadline_us));
        if ((err = counter_get_value(latency_timer, &window_end))) { fatal(err); }
        gpio_pin_set_dt(&led, 1);
        uint32_t checksum = crc32_ieee((const uint8_t *)bench_records, count * 4);
        printk("BENCH DATA session=%08x records=%u sent=%u acked=%u failed=%u write_errors=%u skipped_slots=%u duration_us=%u period_us=2500 crc32=%08x\n",
               session, count, count, successes, count - successes, write_errors, skipped,
               window_end - window_start, checksum);
        const uint8_t *bytes = (const uint8_t *)bench_records;
        for (uint32_t i = 0; i < count * 4; i++) { uart_poll_out(console, bytes[i]); }
        printk("\nBENCH END records=%u\n", count);
        gpio_pin_set_dt(&led, 0);
        announce = k_uptime_get() + 1000;
    }
}
#endif

int main(void)
{
    int err;
    if (!gpio_is_ready_dt(&led)) { fatal(-ENODEV); }
    if ((err = gpio_pin_configure_dt(&led, GPIO_OUTPUT_INACTIVE))) { fatal(err); }
    if ((err = radio_init())) { fatal(err); }
    int64_t summary_due = k_uptime_get() + 5000;
#if ESB_TEST_TRANSMITTER
    if (!device_is_ready(latency_timer) || counter_get_frequency(latency_timer) != 1000000) {
        fatal(-ENODEV);
    }
    if ((err = counter_start(latency_timer))) { fatal(err); }
#if defined(CONFIG_ESB_TEST_BENCHMARK)
    benchmark_main();
    return 0;
#endif
    uint32_t session = sys_rand32_get();
    uint32_t seq = 0, sent = 0, acked = 0, failed = 0, write_errors = 0;
    uint32_t ack_min_us = UINT32_MAX, ack_max_us = 0;
    uint64_t ack_total_us = 0;
    uint32_t skipped_slots = 0, last_sent = 0;
    int64_t last_summary_ms = k_uptime_get();
    int64_t next_send_us = k_ticks_to_us_floor64(k_uptime_ticks());
    struct esb_payload payload = {.length = PACKET_LEN, .pipe = 0, .noack = false};
    sys_put_le32(session, payload.data);
    memcpy(payload.data + 8, MESSAGE, sizeof(MESSAGE) - 1);
    while (true) {
        next_send_us += CONFIG_ESB_TEST_PERIOD_US;
        sys_put_le32(seq, payload.data + 4);
        /* TIMER3 runs during CPU sleep; ESB uses TIMER2. Unsigned subtraction
         * handles the 32-bit timer wrap for these short transactions. */
        if ((err = counter_get_value(latency_timer, &tx_start_us))) { fatal(err); }
        err = esb_write_payload(&payload);
        if (err) {
            write_errors++;
            if (monitor_open()) { printk("TX write_error=%d seq=%u\n", err, seq); }
        } else {
            sent++;
            /* One packet at a time; callback publishes result through the semaphore. */
            if (k_sem_take(&tx_done, K_SECONDS(1))) { fatal(-ETIMEDOUT); }
            if (timer_read_error) { fatal(timer_read_error); }
            uint32_t transaction_us = tx_end_us - tx_start_us;
            if (acknowledged) {
                acked++;
                ack_total_us += transaction_us;
                ack_min_us = MIN(ack_min_us, transaction_us);
                ack_max_us = MAX(ack_max_us, transaction_us);
            } else {
                failed++;
                if ((err = esb_flush_tx())) { fatal(err); }
            }
            gpio_pin_set_dt(&led, acknowledged ? (k_uptime_get() / 500) % 2 : 0);
            if (IS_ENABLED(CONFIG_ESB_TEST_PACKET_LOG) && monitor_open()) {
                printk("TX session=%08x seq=%u message=Hello ACK=%s attempts=%u transaction_us=%u\n",
                       session, seq, acknowledged ? "yes" : "NO", attempts, transaction_us);
            }
            seq++;
        }
        if (k_uptime_get() >= summary_due) {
            int64_t now_ms = k_uptime_get();
            uint32_t rate_tenths = (uint32_t)((uint64_t)(sent - last_sent) * 10000 /
                                            (now_ms - last_summary_ms));
            if (monitor_open()) {
                uint32_t tenths = sent ? (uint32_t)((uint64_t)acked * 1000 / sent) : 0;
                printk("TX SUMMARY sent=%u acked=%u failed=%u ack_rate=%u.%u%% write_errors=%u\n",
                       sent, acked, failed, tenths / 10, tenths % 10, write_errors);
                printk("TX RATE target_hz=%u actual_hz=%u.%u skipped_slots=%u\n",
                       1000000 / CONFIG_ESB_TEST_PERIOD_US,
                       rate_tenths / 10, rate_tenths % 10, skipped_slots);
                if (acked) {
                    printk("TX LATENCY ack_samples=%u min_us=%u mean_us=%u max_us=%u timer_hz=1000000\n",
                           acked, ack_min_us, (uint32_t)(ack_total_us / acked), ack_max_us);
                }
            }
            last_sent = sent;
            last_summary_ms = now_ms;
            summary_due = k_uptime_get() + 5000;
        }
        int64_t now_us = k_ticks_to_us_floor64(k_uptime_ticks());
        if (now_us > next_send_us) {
            /* Skip expired slots rather than sending a catch-up burst. */
            uint32_t missed = (uint32_t)((now_us - next_send_us - 1) /
                                        CONFIG_ESB_TEST_PERIOD_US + 1);
            skipped_slots += missed;
            next_send_us += (int64_t)missed * CONFIG_ESB_TEST_PERIOD_US;
        }
        k_sleep(K_TIMEOUT_ABS_US(next_send_us));
    }
#else
    uint32_t count = 0, gaps = 0, duplicates = 0, sessions = 0;
    uint32_t session = 0, last_seq = 0;
    bool have_session = false;
    uint32_t last_count = 0;
    int64_t last_summary_ms = k_uptime_get();
    if ((err = esb_start_rx())) { fatal(err); }
    while (true) {
        struct reception packet;
        if (k_msgq_get(&received, &packet, K_MSEC(100)) == 0) {
            if (!have_session || session != packet.session) {
                have_session = true;
                session = packet.session;
                last_seq = packet.seq;
                sessions++;
            } else {
                uint32_t delta = packet.seq - last_seq;
                if (delta == 0) { duplicates++; }
                else if (delta < 0x80000000U) { gaps += delta - 1; last_seq = packet.seq; }
            }
            count++;
            gpio_pin_set_dt(&led, (k_uptime_get() / 500) % 2);
            if (IS_ENABLED(CONFIG_ESB_TEST_PACKET_LOG) && monitor_open()) {
                printk("RX session=%08x seq=%u message=Hello rssi=%d dBm\n",
                       packet.session, packet.seq, packet.rssi);
            }
        }
        if (k_uptime_get() >= summary_due) {
            int64_t now_ms = k_uptime_get();
            uint32_t rate_tenths = (uint32_t)((uint64_t)(count - last_count) * 10000 /
                                            (now_ms - last_summary_ms));
            if (monitor_open()) {
                printk("RX SUMMARY received=%u gaps=%u duplicates=%u sessions=%u queue_drops=%u invalid=%u\n",
                       count, gaps, duplicates, sessions,
                       (uint32_t)atomic_get(&queue_drops), (uint32_t)atomic_get(&invalid_packets));
                printk("RX RATE actual_hz=%u.%u\n", rate_tenths / 10, rate_tenths % 10);
            }
            last_count = count;
            last_summary_ms = now_ms;
            summary_due = k_uptime_get() + 5000;
        }
    }
#endif
}
