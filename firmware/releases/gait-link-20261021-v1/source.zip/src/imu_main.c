/* SPDX-License-Identifier: MIT */
/* IMU application core: 1 MHz wall clock (TIMER3), USB framing, calibration
 * persistence (NVS, storage partition), command handling, periodic stats.
 * Radio (imu_radio.c) and sensor (imu_sensor.c) run in their own threads;
 * all USB formatting happens here or in the writer thread, never in radio
 * callbacks or the sensor loop's timed section.
 */
#include <errno.h>
#include <string.h>
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/counter.h>
#include <zephyr/drivers/clock_control/nrf_clock_control.h>
#include <zephyr/sys/onoff.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/kvss/nvs.h>
#include <zephyr/storage/flash_map.h>
#include <zephyr/random/random.h>
#include <zephyr/sys/atomic.h>
#include <zephyr/sys/crc.h>
#include "imu_calibration.h"
#include "imu_protocol.h"
#include "imu_radio.h"
#include "imu_sensor.h"


static const struct device *const usb = DEVICE_DT_GET(DT_CHOSEN(zephyr_console));
static const struct device *const wall_timer = DEVICE_DT_GET(DT_NODELABEL(timer3));
static const struct gpio_dt_spec led = GPIO_DT_SPEC_GET(DT_ALIAS(led0), gpios);

/* Application wall clock: free-running 32-bit 1 MHz TIMER3 plus a software
 * high word. Single lock; radio/sensor/USB all share this clock domain. */
static struct k_spinlock clock_lock;
static uint32_t clock_previous;
static uint64_t clock_high;

static int start_wall_clock(void)
{
    if (!device_is_ready(wall_timer) || counter_get_frequency(wall_timer) != 1000000)
        return -ENODEV;
    /* Hold HFXO independently of USB and ESB's per-role clock references.
     * Switching between HFRC and HFXO would invalidate the affine clock fit. */
    struct onoff_manager *manager = z_nrf_clock_control_get_onoff(CLOCK_CONTROL_NRF_SUBSYS_HF);
    static struct onoff_client client;
    if (!manager) return -ENODEV;
    sys_notify_init_spinwait(&client.notify);
    int err = onoff_request(manager, &client), result;
    if (err < 0) return err;
    int64_t deadline = k_uptime_get() + 1000;
    while ((err = sys_notify_fetch_result(&client.notify, &result)) == -EAGAIN) {
        if (k_uptime_get() >= deadline) { err = -ETIMEDOUT; break; }
        k_msleep(1);
    }
    if (!err) err = result;
    if (!err) err = counter_start(wall_timer);
    if (err) (void)onoff_cancel_or_release(manager, &client);
    return err; /* Keep a successful reference for the application lifetime. */
}

uint64_t imu_clock_us(void)
{
    k_spinlock_key_t key = k_spin_lock(&clock_lock);
    uint32_t low = 0;
    counter_get_value(wall_timer, &low);
    if (low < clock_previous) { clock_high += 1ULL << 32; }
    clock_previous = low;
    uint64_t value = clock_high | low;
    k_spin_unlock(&clock_lock, key);
    return value;
}

struct record {
    uint8_t data[IMU_MAX_LEN];
    uint32_t event;
    uint16_t len;
};
K_MSGQ_DEFINE(output, sizeof(struct record), 64, 4);
K_MSGQ_DEFINE(commands, 1, 64, 1);
static atomic_t usb_drops, queue_drops, command_drops, command_resync;
static uint32_t session, query_session, query_seq, command_seq;
static struct k_spinlock tx_lock;
static uint8_t tx_frame[IMU_MAX_LEN + 14];
static uint16_t tx_len, tx_offset;
static bool tx_active, tx_retry_needed;
K_SEM_DEFINE(tx_complete, 0, 1);

void imu_publish(const uint8_t *payload, uint16_t length, uint32_t event)
{
    if (!payload || length > IMU_MAX_LEN) { atomic_inc(&queue_drops); return; }
    struct record r = {.event = event, .len = length};
    memcpy(r.data, payload, length);
    if (k_msgq_put(&output, &r, K_NO_WAIT)) { atomic_inc(&queue_drops); }
}

static bool usb_open(void)
{
    uint32_t dtr = 0;
    return device_is_ready(usb) &&
           uart_line_ctrl_get(usb, UART_LINE_CTRL_DTR, &dtr) == 0 && dtr;
}

static void usb_send_record(const struct record *r)
{
    if (!usb_open()) { atomic_inc(&usb_drops); return; }
    /* Prepare CRC outside the IRQ lock; hold it only while publishing bytes. */
    uint8_t frame[IMU_MAX_LEN + 14];
    memcpy(frame, "IMU1", 4);
    imu_put16(frame + 4, r->len);
    imu_put32(frame + 6, r->event);
    memcpy(frame + 10, r->data, r->len);
    imu_put32(frame + 10 + r->len, crc32_ieee(frame + 4, r->len + 6));
    k_sem_reset(&tx_complete);
    k_spinlock_key_t key = k_spin_lock(&tx_lock);
    memcpy(tx_frame, frame, r->len + 14);
    tx_len = r->len + 14; tx_offset = 0;
    tx_active = true; tx_retry_needed = false;
    k_spin_unlock(&tx_lock, key);
    uint32_t progress_at = k_uptime_get_32();
    uint16_t previous = 0;
    uart_irq_tx_enable(usb);
    for (;;) {
        if (k_sem_take(&tx_complete, K_MSEC(10)) == 0) return;
        uint32_t now = k_uptime_get_32();
        bool open = usb_open();
        key = k_spin_lock(&tx_lock);
        if (tx_offset != previous) { previous = tx_offset; progress_at = now; }
        if (!open || now - progress_at >= 100) {
            bool interrupted = tx_active;
            tx_active = false; tx_retry_needed = false;
            uart_irq_tx_disable(usb);
            k_spin_unlock(&tx_lock, key);
            if (interrupted) atomic_inc(&usb_drops);
            return;
        }
        bool retry = tx_active && tx_retry_needed;
        tx_retry_needed = false;
        k_spin_unlock(&tx_lock, key);
        if (retry) uart_irq_tx_enable(usb);
    }
}

static void writer_thread(void *a, void *b, void *c)
{
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
    struct record r;
    for (;;) {
        k_msgq_get(&output, &r, K_FOREVER);
        usb_send_record(&r);
    }
}
K_THREAD_DEFINE(writer_id, 2048, writer_thread, NULL, NULL, NULL, 10, 0, 0);

/* CDC RX: the callback arms the USB OUT endpoint; without it poll_in never
 * receives in NCS 3.4.0. Bytes are queued for the main thread. */
static void uart_io(const struct device *dev, void *unused)
{
    ARG_UNUSED(unused);
    if (!uart_irq_update(dev)) return;
    if (uart_irq_rx_ready(dev)) {
        uint8_t c;
        while (uart_fifo_read(dev, &c, 1) == 1) {
            if (k_msgq_put(&commands, &c, K_NO_WAIT)) {
                atomic_inc(&command_drops);
                atomic_set(&command_resync, 1);
            }
        }
    }
    if (uart_irq_tx_ready(dev)) {
        k_spinlock_key_t key = k_spin_lock(&tx_lock);
        if (tx_active) {
            int count = uart_fifo_fill(dev, tx_frame + tx_offset, tx_len - tx_offset);
            if (count > 0) tx_offset += count;
            if (count <= 0) { tx_retry_needed = true; uart_irq_tx_disable(dev); }
            if (tx_offset == tx_len) {
                tx_active = false; uart_irq_tx_disable(dev); k_sem_give(&tx_complete);
            }
        } else uart_irq_tx_disable(dev);
        k_spin_unlock(&tx_lock, key);
    }
}

struct command_parser { unsigned len; char value; bool discard; };
static bool command_parse(struct command_parser *p, uint8_t c, char *command)
{
    if (c == '\r') return false;
    if (c == '\n') {
        bool valid = !p->discard && p->len == 1;
        if (valid) *command = p->value;
        else atomic_inc(&command_drops);
        *p = (struct command_parser){0};
        return valid;
    }
    if (p->discard) return false;
    if (p->len || c < 32 || c > 126) { p->discard = true; return false; }
    p->value = (char)c; p->len = 1;
    return false;
}

/* Calibration persistence: NVS in the fixed 32 KB storage partition
 * [0xEC000, 0xF4000), never the application or bootloader regions. */
#define CALIB_SIZE 36
static struct nvs_fs calib_fs;
static atomic_t calib_ready;
K_MUTEX_DEFINE(calib_lock);

static int calib_mount(void)
{
    const struct flash_area *area = NULL;
    int err = flash_area_open(FIXED_PARTITION_ID(storage_partition), &area);
    if (err) { return err; }
    calib_fs.offset = area->fa_off;
    calib_fs.flash_device = area->fa_dev;
    calib_fs.sector_size = 4096;
    calib_fs.sector_count = area->fa_size / 4096;
    err = nvs_mount(&calib_fs);
    flash_area_close(area);
    if (!err) { atomic_set(&calib_ready, 1); }
    return err;
}

int imu_calibration_store(const uint8_t payload[22])
{
    if (!atomic_get(&calib_ready)) { return -ENODEV; }
    uint8_t record[36];
    memset(record, 0, sizeof(record));
    memcpy(record, "BNO1", 4);
    record[4] = 1; /* Format version. */
    record[5] = CONFIG_IMU_NODE_ID;
    memcpy(record + 8, payload, 22);
    imu_put32(record + 32, crc32_ieee(record, 32));
    k_mutex_lock(&calib_lock, K_FOREVER);
    ssize_t written = nvs_write(&calib_fs, CONFIG_IMU_NODE_ID, record, sizeof(record));
    k_mutex_unlock(&calib_lock);
    return written == 0 || written == (ssize_t)sizeof(record) ? 0 :
           (written < 0 ? (int)written : -EIO);
}

int imu_calibration_fetch(uint8_t payload[22])
{
    if (!atomic_get(&calib_ready)) { return -ENODEV; }
    uint8_t record[36];
    k_mutex_lock(&calib_lock, K_FOREVER);
    ssize_t got = nvs_read(&calib_fs, CONFIG_IMU_NODE_ID, record, sizeof(record));
    k_mutex_unlock(&calib_lock);
    if (got < 0) { return (int)got; }
    if (got != (ssize_t)sizeof(record)) { return -EBADMSG; }
    if (memcmp(record, "BNO1", 4) || record[4] != 1 ||
        record[5] != CONFIG_IMU_NODE_ID ||
        crc32_ieee(record, 32) != imu_get32(record + 32)) { return -EBADMSG; }
    memcpy(payload, record + 8, 22);
    return 0;
}

int imu_calibration_erase(void)
{
    if (!atomic_get(&calib_ready)) { return -ENODEV; }
    k_mutex_lock(&calib_lock, K_FOREVER);
    int err = nvs_delete(&calib_fs, CONFIG_IMU_NODE_ID);
    k_mutex_unlock(&calib_lock);
    return err == 0 || err == -ENOENT ? 0 : -EIO;
}

static void publish_stats(uint32_t event)
{
    struct imu_sample sample;
    struct imu_sensor_metrics sensor;
    imu_sensor_snapshot(&sample, &sensor);
    struct imu_radio_metrics radio = {0};
#if !defined(CONFIG_IMU_USB_ONLY)
    imu_radio_metrics(&radio);
#endif
    uint8_t p[IMU_MAX_LEN];
    imu_header(p, IMU_STATS, CONFIG_IMU_NODE_ID, 0, session, 0, 0);
    imu_put32(p + 16, sensor.reads);
    imu_put32(p + 20, sensor.errors);
    imu_put32(p + 24, sensor.missed);
    imu_put32(p + 28, radio.radio_sent);
    imu_put32(p + 32, radio.radio_missed);
    imu_put32(p + 36, radio.write_errors);
    imu_put32(p + 40, atomic_get(&queue_drops));
    imu_put32(p + 44, atomic_get(&usb_drops));
    imu_put32(p + 48, radio.sync_losses);
    imu_put32(p + 52, radio.invalid_packets);
    imu_put32(p + 56, atomic_get(&command_drops));
    imu_put32(p + 60, k_uptime_get_32());
    imu_publish(p, IMU_STATS_LEN, event);
}

static void publish_sensor_diagnostic(uint32_t event)
{
    if (!CONFIG_IMU_NODE_ID) { return; }
    struct imu_sample sample;
    struct imu_sensor_metrics m;
    imu_sensor_snapshot(&sample, &m);
    uint8_t p[IMU_MAX_LEN];
    uint8_t flags = m.diagnostic_valid ? IMU_VALID : 0;
    if (imu_clock_us() - m.diagnostic_us > 1500000) { flags |= IMU_STALE; }
    if (m.paused) { flags |= IMU_PAUSED; }
    /* Header tx_seq is the low 32-bit sensor diagnostic timestamp for type 7. */
    imu_header(p, IMU_SENSOR_DIAG, CONFIG_IMU_NODE_ID, flags, session,
               (uint32_t)m.diagnostic_us, sample.seq);
    imu_put32(p + 16, k_uptime_get_32());
    imu_put32(p + 20, m.init_count);
    imu_put32(p + 24, m.recovery_count);
    imu_put32(p + 28, m.reset_errors);
    imu_put32(p + 32, m.runtime_errors);
    imu_put32(p + 36, m.consecutive_errors);
    imu_put32(p + 40, (uint32_t)m.diagnostic_error);
    p[44] = m.last_error_reg; p[45] = m.last_error_phase;
    p[46] = m.address;
    /* 100 means 100 kHz; 0 encodes 400 kHz (does not fit in a byte). */
    p[47] = DT_PROP_OR(DT_NODELABEL(i2c0), clock_frequency, 100000) == 400000 ? 0 : 100;
    p[48] = m.calib_raw; p[49] = m.sys_status; p[50] = m.sys_error; p[51] = m.unit_sel;
    p[52] = m.opr_mode; p[53] = m.pwr_mode; p[54] = m.page; p[55] = m.nvs_state;
    imu_put16(p + 56, (uint16_t)m.accel[0]);
    imu_put16(p + 58, (uint16_t)m.accel[1]);
    imu_put16(p + 60, (uint16_t)m.accel[2]);
    p[62] = m.chip_id; p[63] = m.st_result;
    imu_publish(p, IMU_SENSOR_DIAG_LEN, event);
}

static void publish_command_ack(uint32_t event, char command, int result)
{
    struct imu_sample sample;
    struct imu_sensor_metrics m;
    imu_sensor_snapshot(&sample, &m);
    uint8_t p[IMU_MAX_LEN];
    imu_header(p, IMU_COMMAND_ACK, CONFIG_IMU_NODE_ID, 0, session, command_seq++, sample.seq);
    p[16] = (uint8_t)command;
    p[17] = m.nvs_state;
    p[18] = sample.state;
    p[19] = 0;
    imu_put32(p + 20, (uint32_t)result);
    imu_publish(p, IMU_COMMAND_ACK_LEN, event);
}

static void publish_status(uint32_t event)
{
    if (!CONFIG_IMU_NODE_ID) { publish_stats(event); return; }
    struct imu_sample sample;
    struct imu_sensor_metrics sensor;
    imu_sensor_snapshot(&sample, &sensor);
    uint8_t p[IMU_MAX_LEN];
    uint8_t flags = 0;
    if (sensor.paused) { flags |= IMU_PAUSED; }
    if (sample.valid && imu_clock_us() - sample.completed_us > 30000) { flags |= IMU_STALE; }
    /* Local command snapshots must not reuse an over-air packet identity. */
    imu_encode_sample(p, CONFIG_IMU_NODE_ID, query_session, query_seq++, &sample, flags, UINT32_MAX);
    imu_publish(p, IMU_DATA_LEN, event);
}

static void fatal(int err)
{
    gpio_pin_set_dt(&led, 1);
    while (true) {
        uint32_t dtr = 0;
        if (device_is_ready(usb) &&
            uart_line_ctrl_get(usb, UART_LINE_CTRL_DTR, &dtr) == 0 && dtr) {
            printk("IMU ERROR %d: reset board after correcting configuration\n", err);
        }
        k_sleep(K_SECONDS(1));
    }
}

#if defined(CONFIG_IMU_PIN_SCAN)
/* GPIO scan diagnostic: sweep every SCL/SDA pair on P0/P1 with a bit-banged
 * I2C START + BNO055 address probe and report every ACKing pair. Human
 * readable output; no sensor or radio activity. Resolve wiring with this
 * build, then set CONFIG_IMU_SDA_PIN / CONFIG_IMU_SCL_PIN for real builds. */
#include <zephyr/drivers/gpio.h>
#include <zephyr/sys/printk.h>
#define SCAN_PINS 32
static const struct device *const gpio0 = DEVICE_DT_GET(DT_NODELABEL(gpio0));
static const struct device *const gpio1 = DEVICE_DT_GET(DT_NODELABEL(gpio1));
static const struct device *scan_port(unsigned pin) { return pin < 32 ? gpio0 : gpio1; }
static void scan_write(unsigned pin, int value) { gpio_pin_set_raw(scan_port(pin), pin % 32, value); }
static void scan_cfg(unsigned pin, int output)
{
    gpio_pin_configure(scan_port(pin), pin % 32,
                       output ? GPIO_OUTPUT_ACTIVE : GPIO_INPUT | GPIO_PULL_UP);
}
static int scan_read(unsigned pin) { return gpio_pin_get_raw(scan_port(pin), pin % 32); }
static bool scan_probe(unsigned scl, unsigned sda)
{
    scan_cfg(scl, 1); scan_cfg(sda, 1);
    scan_write(scl, 1); scan_write(sda, 1);
    k_busy_wait(20);
    /* START: SDA falls while SCL high. */
    scan_write(sda, 0); k_busy_wait(5); scan_write(scl, 0);
    /* Address 0x28<<1|1 (read), MSB first. */
    for (int bit = 7; bit >= 0; --bit) {
        scan_write(sda, (0x51 >> bit) & 1);
        k_busy_wait(4);
        scan_write(scl, 1); k_busy_wait(4); scan_write(scl, 0);
    }
    /* ACK: release SDA, clock, read slave pull-down. */
    scan_cfg(sda, 0);
    k_busy_wait(4);
    scan_write(scl, 1); k_busy_wait(4);
    bool acked = scan_read(sda) == 0;
    scan_write(scl, 0);
    /* STOP: SDA rises while SCL high. */
    scan_write(sda, 0); k_busy_wait(5);
    scan_cfg(sda, 1); scan_write(sda, 1); k_busy_wait(5);
    scan_cfg(scl, 0); scan_cfg(sda, 0);
    return acked;
}
static void scan_pins(void)
{
    uint8_t hits = 0;
    for (unsigned scl = 0; scl < 48; ++scl) {
        for (unsigned sda = 0; sda < 48; ++sda) {
            if (scl == sda) { continue; }
            if (scan_probe(scl, sda)) {
                printk("SCAN HIT address=0x28 scl=%u sda=%u (Kconfig SDA=%u SCL=%u)\n",
                       scl, sda, sda, scl);
                ++hits;
            }
        }
    }
    printk("SCAN COMPLETE hits=%u (use the reported numbers as IMU_SDA_PIN/IMU_SCL_PIN)\n", hits);
}
#endif /* CONFIG_IMU_PIN_SCAN */

int main(void)
{
    int err;
    if (!gpio_is_ready_dt(&led)) { fatal(-ENODEV); }
    if ((err = gpio_pin_configure_dt(&led, GPIO_OUTPUT_INACTIVE))) { fatal(err); }
    if ((err = start_wall_clock())) { fatal(err); }
    if (!device_is_ready(usb)) { fatal(-ENODEV); }
    /* Preserved CDC RX enable/command fix (see benchmark README). */
    if ((err = uart_irq_callback_user_data_set(usb, uart_io, NULL))) { fatal(err); }
    uart_irq_rx_enable(usb);
    if ((err = calib_mount())) {
        /* Missing/erased persistence is not fatal; commands report it. */
        atomic_inc(&command_drops);
    }
#if defined(CONFIG_IMU_PIN_SCAN)
    while (true) {
        uint32_t dtr = 0;
        if (device_is_ready(usb) &&
            uart_line_ctrl_get(usb, UART_LINE_CTRL_DTR, &dtr) == 0 && dtr) {
            printk("IMU PIN SCAN: probing all SCL/SDA pairs, 30 s...\n");
            scan_pins();
            printk("IMU PIN SCAN: waiting for reset; rerun to probe again.\n");
            k_sleep(K_SECONDS(30));
        } else {
            k_msleep(200);
        }
    }
#else
    if (CONFIG_IMU_NODE_ID) { imu_sensor_start(); }
#endif
#if !defined(CONFIG_IMU_PIN_SCAN)
    session = sys_rand32_get();
    query_session = session ^ 0x80000000U;
    if (!CONFIG_IMU_NODE_ID) { imu_radio_start(session); }
#endif
    bool measurement_started = !CONFIG_IMU_NODE_ID;
    uint64_t next_stats = imu_clock_us() + 1000000;
    uint64_t next_sensor_diag = imu_clock_us() + 2000000;
    struct command_parser parser = {0};
    while (true) {
        uint8_t c;
        while (!k_msgq_get(&commands, &c, K_NO_WAIT)) {
            if (atomic_cas(&command_resync, 1, 0)) {
                k_msgq_purge(&commands);
                parser = (struct command_parser){.discard = true};
                break; /* Wait for a new delimiter after an RX overrun. */
            }
            char command;
            if (!command_parse(&parser, c, &command)) continue;
            int result = 0;
            switch (command) {
            case 'Q':
                publish_status((uint32_t)imu_clock_us());
                break;
            case 'P':
            case 'R':
                result = imu_sensor_command(command);
                break;
            case 'S':
                /* Controlled pause: no outstanding radio transaction and the
                 * sensor loop is idle before NVMC programming. */
                imu_radio_pause(true);
                result = imu_sensor_save();
                if (result != -ETIMEDOUT) { imu_radio_pause(false); }
                publish_status((uint32_t)imu_clock_us());
                break;
            case 'L':
                imu_radio_pause(true);
                result = imu_sensor_load();
                if (result != -ETIMEDOUT) { imu_radio_pause(false); }
                publish_status((uint32_t)imu_clock_us());
                break;
            case 'C':
                imu_radio_pause(true);
                result = imu_calibration_erase();
                imu_radio_pause(false);
                publish_status((uint32_t)imu_clock_us());
                break;
            default:
                atomic_inc(&command_drops);
                result = -EINVAL;
                break;
            }
            if (strchr("SLCPR", command)) { publish_command_ack((uint32_t)imu_clock_us(), command, result); }
        }
        uint64_t now = imu_clock_us();
        if (!measurement_started && !IS_ENABLED(CONFIG_IMU_PIN_SCAN)) {
            struct imu_sample sample;
            struct imu_sensor_metrics sensor;
            imu_sensor_snapshot(&sample, &sensor);
            if (sample.valid && sample.state == IMU_READY && sample.calibration == 0xff &&
                !sensor.paused && !sensor.last_error && now - sample.completed_us <= 30000) {
                /* Release the radio thread only after a calibrated measurement. */
                imu_radio_start(session);
                measurement_started = true;
            }
        }
        if (!IS_ENABLED(CONFIG_IMU_PIN_SCAN) &&
            (int32_t)(now - next_stats) >= 0) {
            publish_stats((uint32_t)now);
            if (!measurement_started) { publish_status((uint32_t)now); }
            next_stats += 1000000;
            if ((int32_t)(now - next_stats) > 0) { next_stats = now + 1000000; }
        }
        if (!IS_ENABLED(CONFIG_IMU_PIN_SCAN) && CONFIG_IMU_NODE_ID &&
            (int32_t)(now - next_sensor_diag) >= 0) {
            publish_sensor_diagnostic((uint32_t)now);
            next_sensor_diag = now + 2000000;
        }
        gpio_pin_set_dt(&led, (k_uptime_get_32() / 500) & 1);
        k_msleep(5);
    }
}
