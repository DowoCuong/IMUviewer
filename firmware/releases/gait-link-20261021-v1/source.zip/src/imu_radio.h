/* SPDX-License-Identifier: MIT */
#ifndef IMU_RADIO_H
#define IMU_RADIO_H
#include <stdbool.h>
#include <stdint.h>

struct imu_radio_metrics {
    uint32_t radio_sent, radio_missed, write_errors, sync_losses, invalid_packets;
};

/* TIMER3/imu_clock_us must be running before start; call start exactly once. */
void imu_radio_start(uint32_t session);
void imu_radio_metrics(struct imu_radio_metrics *snapshot);
/* Thread context, serialized callers. true waits for PTX quiescence and PRX.
 * Keeps receiving synchronization. This is NOT a radio-IRQ/flash exclusion
 * primitive: erase/program needs a separate fully-disabled radio handshake.
 */
void imu_radio_pause(bool paused);
uint64_t imu_clock_us(void);
/* Nonblocking enqueue supplied by main; never USB formatting in radio context. */
void imu_publish(const uint8_t *payload, uint16_t length, uint32_t event);
#endif
