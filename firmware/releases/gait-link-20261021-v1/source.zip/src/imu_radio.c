/* SPDX-License-Identifier: MIT */
#include <zephyr/kernel.h>
#include <zephyr/sys/atomic.h>
#include "imu_radio.h"
#include "imu_sensor.h"
#include "imu_sync.h"
#if !defined(CONFIG_IMU_USB_ONLY)
#include <esb.h>
#endif

BUILD_ASSERT(CONFIG_IMU_NODES >= 1 && CONFIG_IMU_NODES <= 4);
/* Four 1 ms slots fit a 10 ms group. The 400 Hz schedule has 2 ms groups. */
BUILD_ASSERT(CONFIG_IMU_RADIO_HZ == 100 || CONFIG_IMU_NODES <= 2);
BUILD_ASSERT(CONFIG_IMU_NODE_ID >= 0 && CONFIG_IMU_NODE_ID <= CONFIG_IMU_NODES);
BUILD_ASSERT(CONFIG_IMU_RADIO_HZ == 100 || CONFIG_IMU_RADIO_HZ == 400);
static atomic_t sent, missed, errors, losses, invalid;
static atomic_t pause_requested, pause_acknowledged, started;
K_SEM_DEFINE(start_gate, 0, 1);
K_SEM_DEFINE(pause_gate, 0, 1);
static uint32_t boot_session, tx_seq;
static uint32_t hub_sequence;

void imu_radio_metrics(struct imu_radio_metrics *s)
{
    if (!s) return;
    *s = (struct imu_radio_metrics) {
        .radio_sent = atomic_get(&sent), .radio_missed = atomic_get(&missed),
        .write_errors = atomic_get(&errors), .sync_losses = atomic_get(&losses),
        .invalid_packets = atomic_get(&invalid),
    };
}
void imu_radio_start(uint32_t session)
{
    if (!atomic_cas(&started, 0, 1)) return;
    boot_session = session;
    k_sem_give(&start_gate);
}
void imu_radio_pause(bool paused)
{
    atomic_set(&pause_requested, paused);
    if (!paused) { atomic_clear(&pause_acknowledged); return; }
    if (!atomic_get(&started)) return;
    while (!atomic_get(&pause_acknowledged)) k_sem_take(&pause_gate, K_FOREVER);
}
static void acknowledge_pause(void)
{
    if (atomic_get(&pause_requested) && atomic_cas(&pause_acknowledged, 0, 1)) k_sem_give(&pause_gate);
}
static uint32_t clock32(void) { return (uint32_t)imu_clock_us(); }
/* Sleep only far from deadlines, busy wait in the last 300 us. Oversleep is
 * always handled by skipping, never by a catch-up transmission. */
static void wait_until_margin(uint32_t deadline, uint32_t busy_us)
{
    int32_t left;
    while ((left = imu_delta(deadline, clock32())) > 0) {
        if (left > (int32_t)busy_us) k_usleep(MIN(left - busy_us, 1000));
        else k_busy_wait(MIN(left, 50));
    }
}
static void wait_until(uint32_t deadline) { wait_until_margin(deadline, 300); }
static void sample_payload(uint8_t *p, struct imu_sample *s, struct imu_sensor_metrics *m,
                           bool synced, uint32_t beacon_age, uint32_t seq)
{
    imu_sensor_snapshot(s, m);
    uint8_t flags = synced ? IMU_SYNCED : 0;
    if (m->paused || atomic_get(&pause_requested)) flags |= IMU_PAUSED;
    if (s->valid && (imu_clock_us() - s->completed_us > 30000 || m->duration_us > 30000 || m->last_error ||
                     s->state == IMU_SENSOR_FAULT)) flags |= IMU_STALE;
    imu_encode_sample(p, CONFIG_IMU_NODE_ID, boot_session, seq, s, flags, beacon_age);
}

#if !defined(CONFIG_IMU_USB_ONLY)
BUILD_ASSERT(CONFIG_ESB_MAX_PAYLOAD_LENGTH == IMU_MAX_LEN);
struct reception { uint8_t data[IMU_MAX_LEN]; uint32_t end; uint16_t len; };
K_MSGQ_DEFINE(received, sizeof(struct reception), 32, 4);
K_SEM_DEFINE(tx_done, 0, 1);
static atomic_t tx_outstanding;
static uint32_t tx_start, tx_elapsed, tx_callback_end, tx_attempts;
static bool tx_success, tx_attempted, configured, prx, fatal_error;

static void radio_event(const struct esb_evt *event)
{
    if (event->evt_id == ESB_EVENT_TX_SUCCESS || event->evt_id == ESB_EVENT_TX_FAILED) {
        /* Capture immediately, before semaphore or publishing. Not over-air duration. */
        uint32_t now = clock32();
        if (!atomic_get(&tx_outstanding)) return;
        tx_callback_end = now; tx_elapsed = now - tx_start;
        tx_success = event->evt_id == ESB_EVENT_TX_SUCCESS;
        tx_attempts = event->tx_attempts;
        k_sem_give(&tx_done);
    } else if (event->evt_id == ESB_EVENT_RX_RECEIVED) {
        struct esb_payload p;
        while (!esb_read_rx_payload(&p)) {
            if (!imu_validate(p.data, p.length, CONFIG_IMU_NODES)) { atomic_inc(&invalid); continue; }
            struct reception r = {.end = p.rx_end_us, .len = p.length};
            memcpy(r.data, p.data, p.length);
            if (k_msgq_put(&received, &r, K_NO_WAIT)) atomic_inc(&invalid);
        }
    }
}
static void radio_disable(void)
{
    /* esb_disable aborts hardware and flushes both vendor FIFOs. Clear the
     * outstanding marker only afterwards, then discard any callback token. */
    if (configured) esb_disable();
    configured = false; atomic_clear(&tx_outstanding); k_sem_reset(&tx_done);
}
static bool radio_mode(bool receive)
{
    if (fatal_error) return false;
    if (configured && prx == receive) return true;
    radio_disable();
    /* Separate this gait network from the Sleepify/ESB8 default addresses. */
    const uint8_t base0[4] = {0xa7, 0x6d, 0x32, 0x91};
    const uint8_t base1[4] = {0x5b, 0x84, 0xd3, 0x26};
    const uint8_t prefixes[8] = {0x39, 0x52, 0x74, 0x96, 0xb8, 0xda, 0xec, 0x4f};
    struct esb_config c = ESB_DEFAULT_CONFIG;
    c.protocol = ESB_PROTOCOL_ESB_DPL; c.bitrate = ESB_BITRATE_2MBPS;
    c.mode = receive ? ESB_MODE_PRX : ESB_MODE_PTX;
    c.tx_mode = ESB_TXMODE_AUTO; c.event_handler = radio_event;
    c.selective_auto_ack = true; c.retransmit_count = 0; c.retransmit_delay = 600;
    c.payload_length = IMU_MAX_LEN; c.tx_output_power = 8;
    if (esb_init(&c)) goto fail;
    configured = true; prx = receive;
    if (esb_set_base_address_0(base0) || esb_set_base_address_1(base1) ||
        esb_set_prefixes(prefixes, 8) || esb_set_rf_channel(CONFIG_IMU_RF_CHANNEL)) goto fail;
    /* Nodes listen ONLY to the control pipe; they must not ACK other nodes.
     * Hub listens to node-specific data pipes and never ACKs sync controls. */
    uint8_t pipes = !receive ? 0xff : CONFIG_IMU_NODE_ID ? 1 : ((1U << (CONFIG_IMU_NODES + 1)) - 2);
    if (esb_enable_pipes(pipes) || (receive && esb_start_rx())) goto fail;
    return true;
fail:
    atomic_inc(&errors); radio_disable(); fatal_error = true; return false;
}
/* One outstanding packet, zero retries. 64-byte timed DATA adds 96 us at
 * 2 Mbps over the previous 40-byte payload. The unchanged 700 us deadline
 * remains a hard stop; actual DATA/ACK timing requires bench validation.
 * Polling avoids kernel tick rounding on the 700 us timeout. ISR preemption,
 * role-change and disable latency still require bench timing validation.
 */
static bool transmit(const uint8_t *p, uint16_t len, uint8_t pipe, bool noack,
                     uint32_t slot_start, bool bounded_slot)
{
    tx_attempted = false;
    if (!configured || prx || atomic_get(&pause_requested)) return false;
    struct esb_payload packet = {.length = len, .pipe = pipe, .noack = noack};
    memcpy(packet.data, p, len);
    k_sem_reset(&tx_done); tx_success = false; tx_attempts = 0; tx_elapsed = UINT32_MAX;
    tx_start = clock32(); tx_callback_end = tx_start;
    /* The caller counts a skipped opportunity exactly once. */
    if (bounded_slot && !imu_slot_open(tx_start, slot_start)) return false;
    tx_attempted = true;
    atomic_set(&tx_outstanding, 1);
    if (esb_write_payload(&packet)) {
        atomic_inc(&errors); radio_disable(); return false;
    }
    atomic_inc(&sent);
    while (k_sem_take(&tx_done, K_NO_WAIT)) {
        if (clock32() - tx_start >= 700) {
            atomic_inc(&errors); radio_disable();
            tx_callback_end = clock32(); tx_elapsed = UINT32_MAX; tx_success = false;
            return false;
        }
        k_busy_wait(2);
    }
    atomic_clear(&tx_outstanding);
    if (tx_elapsed >= 700) {
        /* A delayed ISR/scheduler can hide a deadline overrun. Do not treat
         * that observation as permission to continue this frame. */
        atomic_inc(&errors); radio_disable(); return false;
    }
    if (!tx_success) {
        if (esb_flush_tx()) { atomic_inc(&errors); radio_disable(); }
        return false;
    }
    return true;
}
static void control(uint8_t *p, unsigned type, uint32_t seq, uint32_t frame, uint32_t event)
{
    imu_header(p, type, 0, 0, boot_session, seq, 0);
    imu_put32(p + 16, event); imu_put32(p + 20, frame); imu_put32(p + 24, IMU_FRAME_US);
    p[28] = CONFIG_IMU_NODES; p[29] = CONFIG_IMU_RADIO_HZ == 400 ? 1 : 0;
}
static void hub_receive(void)
{
    struct reception r;
    while (!k_msgq_get(&received, &r, K_NO_WAIT)) {
        if (r.data[1] == IMU_DATA || r.data[1] == IMU_STATUS || r.data[1] == IMU_TIMED_DATA)
            imu_publish(r.data, r.len, r.end);
        else atomic_inc(&invalid);
    }
}
static void hub_loop(void)
{
    uint32_t frame = clock32() + 5000;
    while (!fatal_error) {
        hub_receive();
        if (atomic_get(&pause_requested)) {
            if (!radio_mode(true)) break;
            acknowledge_pause(); k_msleep(1); frame = clock32() + 5000; continue;
        }
        if (imu_delta(frame, clock32()) > 700) {
            if (!radio_mode(true)) break;
            k_usleep(200); continue;
        }
        uint8_t p[IMU_MAX_LEN];
        if (!radio_mode(false)) break;
        control(p, IMU_BEACON, hub_sequence, frame, frame);
        wait_until(frame);
        if (imu_slot_open(clock32(), frame) && transmit(p, IMU_CONTROL_LEN, 0, true, frame, true)) {
            uint32_t beacon_end = esb_data_tx_end_us();
            control(p, IMU_FOLLOWUP, hub_sequence, frame, beacon_end);
            wait_until(frame + 1200);
            if (imu_slot_open(clock32(), frame + 1200)) {
                (void)transmit(p, IMU_CONTROL_LEN, 0, true, frame + 1200, true);
                if (!tx_attempted) atomic_inc(&missed);
            } else atomic_inc(&missed);
        } else atomic_inc(&missed);
        if (!radio_mode(true)) break;
        ++hub_sequence; frame += IMU_FRAME_US;
        while (imu_delta(clock32(), frame - 700) > 0) { frame += IMU_FRAME_US; ++hub_sequence; atomic_inc(&missed); }
    }
}
static void diagnostic(const struct imu_sample *s, const struct imu_sensor_metrics *m, uint32_t sequence)
{
    uint8_t p[IMU_MAX_LEN];
    imu_header(p, IMU_DIAG, CONFIG_IMU_NODE_ID, 0, boot_session, sequence, s->seq);
    imu_put32(p + 16, tx_elapsed); imu_put32(p + 20, tx_start);
    imu_put32(p + 24, m->interval_us); imu_put32(p + 28, m->duration_us); imu_put32(p + 32, m->lateness_us);
    p[36] = MIN(tx_attempts, 255); p[37] = tx_success ? 1 : 0;
    imu_publish(p, IMU_DIAG_LEN, tx_callback_end);
}
static void node_frame(struct imu_sync *sync)
{
    /* Configure PTX once, well before the first slot. Return to PRX before
     * the next beacon; reinitializing for every 1 ms slot wastes its guard. */
    if (atomic_get(&pause_requested) || !imu_sync_current(sync, clock32()) || !radio_mode(false)) return;
    for (unsigned i = 0; i < imu_slot_count(CONFIG_IMU_RADIO_HZ); ++i) {
        uint32_t start = imu_sync_local(sync, sync->frame + imu_slot_offset(CONFIG_IMU_RADIO_HZ, i, CONFIG_IMU_NODE_ID));
        wait_until_margin(start, 500);
        if (atomic_get(&pause_requested) || !imu_sync_current(sync, clock32())) break;
        if (!radio_mode(false)) break;
        if (!imu_slot_open(clock32(), start)) { atomic_inc(&missed); continue; }
        uint8_t p[IMU_MAX_LEN]; struct imu_sample sample; struct imu_sensor_metrics metrics;
        uint32_t sequence = tx_seq;
        sample_payload(p, &sample, &metrics, true, clock32() - sync->beacon_rx, sequence);
        uint16_t length = IMU_DATA_LEN;
        if (sample.valid && metrics.duration_us <= 30000 &&
            imu_clock_us() - sample.completed_us <= IMU_SYNC_TIMEOUT_US) {
            /* Export the fit used by the radio scheduler. completed_us remains
             * the local I2C-read completion, NOT the BNO internal sample epoch.
             * Host mapping: hub_anchor + signed(local-local_anchor)/(1+ppm/1e6).
             */
            p[1] = IMU_TIMED_DATA;
            imu_put32(p+40, sync->local_anchor); imu_put32(p+44, sync->hub_anchor);
            imu_put32(p+48, (uint32_t)sync->ppm); imu_put32(p+52, sync->uncertainty_us);
            imu_put32(p+56, sync->session); imu_put32(p+60, metrics.duration_us);
            length = IMU_TIMED_DATA_LEN;
        }
        /* Expired/slow snapshots retain the legacy DATA diagnostic record.
         * An old sample cannot use the current affine fit; a >30 ms read also
         * exceeds the TIMED_DATA validator. Neither may become a usable angle.
         */
        /* Snapshot and serialization may consume time: transmit rechecks gate. */
        bool ok = transmit(p, length, CONFIG_IMU_NODE_ID, false, start, true);
        if (tx_attempted) {
            /* Submission attempts consume an identity even on write failure.
             * A skipped gate consumes none and publishes no stale DIAG. */
            ++tx_seq;
            imu_publish(p, length, tx_start);
            diagnostic(&sample, &metrics, sequence);
        } else atomic_inc(&missed);
        if (!ok && !configured && i + 1 < imu_slot_count(CONFIG_IMU_RADIO_HZ)) {
            /* An ACK/completion failure does not invalidate the clock fit.
             * Reinitialize inside the gap; keep all original slot/expiry gates. */
            if (!radio_mode(false)) break;
        }
    }
    (void)radio_mode(true);
}
static void node_loop(void)
{
    struct imu_sync sync = {0}; struct reception r;
    if (!radio_mode(true)) return;
    while (!fatal_error) {
        acknowledge_pause();
        if (imu_sync_expire(&sync, clock32())) atomic_inc(&losses);
        if (k_msgq_get(&received, &r, K_USEC(500))) continue;
        bool was_locked = sync.locked;
        int result = imu_sync_receive(&sync, r.data, r.len, r.end, CONFIG_IMU_NODES, CONFIG_IMU_RADIO_HZ);
        if (was_locked && !sync.locked) atomic_inc(&losses);
        if (result < 0) atomic_inc(&invalid);
        if (result == 1 && !atomic_get(&pause_requested) && imu_sync_current(&sync, clock32())) node_frame(&sync);
    }
}
#endif

static void radio_thread(void *a, void *b, void *c)
{
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
    k_sem_take(&start_gate, K_FOREVER);
#if defined(CONFIG_IMU_USB_ONLY)
    uint32_t next = clock32();
    while (true) {
        acknowledge_pause();
        if (!atomic_get(&pause_requested) && CONFIG_IMU_NODE_ID) {
            uint8_t p[IMU_MAX_LEN]; struct imu_sample s; struct imu_sensor_metrics m;
            sample_payload(p, &s, &m, false, UINT32_MAX, tx_seq++);
            imu_publish(p, IMU_DATA_LEN, clock32());
        }
        next += 1000000U / CONFIG_IMU_RADIO_HZ;
        (void)imu_skip(clock32(), &next, 1000000U / CONFIG_IMU_RADIO_HZ);
        wait_until(next);
    }
#else
    for (;;) {
        fatal_error = false;
        k_msgq_purge(&received);
        if (CONFIG_IMU_NODE_ID == 0) hub_loop(); else node_loop();
        radio_disable();
        /* Recover configuration failures without rebooting USB or changing
         * the boot/session identity. Pause acknowledgements remain serviced. */
        uint32_t retry_at = clock32() + 100000;
        do { acknowledge_pause(); k_msleep(1); }
        while (imu_delta(retry_at, clock32()) > 0);
    }
#endif
}
K_THREAD_DEFINE(imu_radio_id, 3072, radio_thread, NULL, NULL, NULL, 2, 0, 0);
