"""End-to-end protocol test without hardware, including fragmented USB reads."""
import contextlib
import csv
import io
import json
import struct
import sys
import tempfile
import types
import zlib
from pathlib import Path

import capture_latency as capture

RAW = struct.pack('<400I', *([0x81000000 | 445] * 399 + [0x04000000 | 2243]))
HEADER = ('BENCH DATA session=1234abcd records=400 sent=400 acked=399 failed=1 '
          'write_errors=0 skipped_slots=0 duration_us=1000010 period_us=2500 '
          f'crc32={zlib.crc32(RAW):08x}\n').encode()


class Port:
    def __init__(self, *args, **kwargs):
        assert kwargs.get('write_timeout') == 3
        self.buffer = bytearray(b'BENCH READY max_seconds=120 period_us=2500\n')

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def reset_input_buffer(self):
        pass

    def flush(self):
        raise AssertionError('Do not call the unbounded Windows serial flush')

    def write(self, data):
        assert data == b'S 1\n'
        self.buffer.extend(b'BENCH START session=1234abcd seconds=1 period_us=2500\n')
        self.buffer.extend(HEADER + RAW + b'\nBENCH END records=400\n')

    def read_until(self, delimiter, size):
        end = self.buffer.find(delimiter)
        return self.read(min(size, end + 1 if end >= 0 else len(self.buffer)))

    def read(self, size):
        size = min(size, 7, len(self.buffer))
        result = bytes(self.buffer[:size])
        del self.buffer[:size]
        return result


def main():
    original_serial = sys.modules.get('serial')
    sys.modules['serial'] = types.SimpleNamespace(Serial=Port)
    try:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'run.csv'
            args = types.SimpleNamespace(port='TEST', seconds=1, out=output)
            log = io.StringIO()
            with contextlib.redirect_stdout(log):
                capture.capture_benchmark(args)
            with output.open() as file:
                rows = list(csv.DictReader(file))
            metadata = json.loads(output.with_suffix('.metadata.json').read_text())
            assert len(rows) == 400 and rows[-1]['ack'] == 'False'
            assert metadata['successful_latency']['p96_us'] == 445
            assert metadata['successful_latency']['p99_us'] == 445
            assert metadata['success_rate_percent'] == 99.75
            assert metadata['failed_completion_time']['max_us'] == 2243
            assert 'CRC32 verified' in log.getvalue()
            try:
                capture.capture_benchmark(args)
            except FileExistsError:
                pass
            else:
                raise AssertionError('Existing output must not be overwritten')
    finally:
        if original_serial is None:
            sys.modules.pop('serial', None)
        else:
            sys.modules['serial'] = original_serial
    print('Benchmark command, fragmented export, CSV, JSON, statistics and overwrite protection passed.')


if __name__ == '__main__':
    main()
