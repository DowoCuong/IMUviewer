"""Production C calibration/diagnostic regressions; mocked bus, no hardware."""
from pathlib import Path
import struct
import tempfile
import unittest

from test_imu_startup import SENSOR_KERNEL, I2C
from test_imu_radio import ATOMIC, ROOT, compile_run
from imu_capture import decode_payload

HARNESS = r'''
#define CONFIG_IMU_SDA_PIN 17
#define CONFIG_IMU_SCL_PIN 20
#include "imu_sensor.c"
#include <assert.h>
static uint64_t now;
static uint8_t regs[2][256], page;
static int fail_reg = -1, reset_nack, mismatch, stores, fetches;
static unsigned transient;
static struct bno055_t *driver;
uint64_t imu_clock_us(void) { return now; }
void k_msleep(uint32_t ms) { now += (uint64_t)ms * 1000; }
void k_usleep(uint32_t us) { now += us; }
void k_busy_wait(uint32_t us) { now += us; }
int imu_calibration_fetch(uint8_t p[22]) { ++fetches; memset(p, 7, 22); return 0; }
int imu_calibration_store(const uint8_t p[22]) { ++stores; assert(p[0] == 7); return 0; }
int i2c_burst_read(const struct device *d, uint16_t a, uint8_t r, uint8_t *p, uint32_t n) {
    assert(d == sensor_bus && a == CONFIG_IMU_BNO055_ADDRESS);
    if (r == 0x35 && transient) { --transient; return -EIO; }
    if (r == fail_reg) return -EIO;
    memcpy(p, &regs[page][r], n);
    if (!page && r == 0x55 && mismatch) p[0] ^= 1;
    return 0;
}
int i2c_burst_write(const struct device *d, uint16_t a, uint8_t r, const uint8_t *p, uint32_t n) {
    assert(d == sensor_bus && a == CONFIG_IMU_BNO055_ADDRESS);
    if (r == 7) page = p[0];
    memcpy(&regs[page][r], p, n);
    if (r == 0x3f && p[0] == 0x20 && reset_nack) return -EIO;
    return 0;
}
s8 bno055_init(struct bno055_t *b) { driver = b; b->chip_id = 0xa0; return 0; }
s8 bno055_read_register(u8 r, u8 *p, u8 n) { return driver->bus_read(driver->dev_addr,r,p,n); }
s8 bno055_write_register(u8 r, u8 *p, u8 n) { return driver->bus_write(driver->dev_addr,r,p,n); }
s8 bno055_read_quaternion_wxyz(struct bno055_quaternion_t *q) { (void)q; return 0; }
int main(void) {
    regs[0][0] = 0xa0;
    reset_nack = 1;
    assert(initialize_sensor() == 0);
    assert(stats.reset_errors == 1 && stats.recovery_count == 0);
    assert(stats.diagnostic_error == -EIO);
    assert(regs[0][0x3d] == 0x0c && page == 0);
    assert(fetches == (CONFIG_IMU_BYPASS_SAVED_CALIBRATION ? 0 : 1));
    assert(stats.nvs_state == (CONFIG_IMU_BYPASS_SAVED_CALIBRATION ? 4 : 2));
    assert(stores == 0); /* Bypass/load never overwrites stored calibration. */
    int error = 123;
    bool changed = true;
    cache.valid = true; cache.state = IMU_READY; cache.calibration = 255;
    regs[0][0x35] = 0;
    calib.operation = CALIB_SAVE; calib.state = CALIB_PENDING;
    assert(calib_serve(0, &error, &changed));
    assert(calib.result == -EAGAIN && error == 0 && !changed && !stores);
    assert(regs[0][0x3d] == 0x0c); /* Cached READY cannot authorize a save. */
    regs[0][0x35] = 255;
    memset(&regs[0][0x55], 7, 22);
    calib.state = CALIB_PENDING;
    assert(calib_serve(0, &error, &changed));
    assert(!calib.result && !error && changed && stores == 1 && calib_done == 1);
    uint8_t p[22]; memset(p, 9, 22);
    mismatch = 1;
    assert(calib_transaction(CALIB_WRITE, p) == -EIO);
    assert(page == 0 && regs[0][0x3d] == 0x0c); /* Cleanup despite mismatch. */
    mismatch = 0;
    assert(calib_transaction(CALIB_WRITE, p) == 0);
    regs[0][8] = 0x18; regs[0][9] = 0xfc; /* -1000 signed raw ACC */
    diagnostic_poll(0xfc);
    assert(stats.diagnostic_valid && stats.accel[0] == -1000 && stats.calib_raw == 0xfc);
    fail_reg = 8;
    diagnostic_poll(0xfc);
    assert(!stats.diagnostic_valid && stats.accel[0] == -1000);
    assert(stats.runtime_errors == 1 && stats.last_error_reg == 8);
    fail_reg = -1;
    diagnostic_poll(0xff);
    assert(stats.diagnostic_valid && stats.diagnostic_error == -EIO);
    assert(stats.runtime_errors == 1 && stats.reset_errors == 1);
    transient = 2;
    uint8_t calibration = 0;
    assert(read_calibration_status(&calibration) == 0 && calibration == 255);
    assert(stats.runtime_errors == 3 && stats.init_count == 1);
    if (!CONFIG_IMU_BYPASS_SAVED_CALIBRATION) {
        mismatch = 1;
        assert(initialize_sensor() == -EIO);
        assert(stats.nvs_state == 3); /* Failed readback must not report applied. */
    }
    uint8_t packet[IMU_MAX_LEN];
    imu_header(packet, IMU_COMMAND_ACK, 0, 0, 1, 0, 0);
    packet[16] = 'S';
    assert(imu_validate(packet, IMU_COMMAND_ACK_LEN, 1));
    packet[19] = 1;
    assert(!imu_validate(packet, IMU_COMMAND_ACK_LEN, 1));
    return 0;
}
'''


class SensorDiagnosticsTests(unittest.TestCase):
    def run_native(self, bypass):
        with tempfile.TemporaryDirectory() as directory:
            tmp = Path(directory)
            (tmp / 'zephyr/sys').mkdir(parents=True)
            (tmp / 'zephyr/drivers').mkdir()
            (tmp / 'zephyr/kernel.h').write_text(SENSOR_KERNEL)
            (tmp / 'zephyr/sys/atomic.h').write_text(ATOMIC)
            (tmp / 'zephyr/drivers/i2c.h').write_text(I2C)
            bosch = (ROOT / 'third_party/bno055/bno055.h').as_posix()
            (tmp / 'bno055.h').write_text(f'#include "{bosch}"\n')
            compile_run(f'#define CONFIG_IMU_BYPASS_SAVED_CALIBRATION {bypass}\n' + HARNESS, tmp)

    def test_saved_offsets_and_fresh_save_admission(self):
        self.run_native(0)

    def test_bypass_does_not_fetch_or_store_at_boot(self):
        self.run_native(1)

    def test_signed_diag_and_bus_speed(self):
        p = bytearray(64)
        struct.pack_into('<BBBBIII', p, 0, 1, 7, 1, 1, 42, 123, 0)
        struct.pack_into('<i', p, 40, -5)
        p[46] = 0x29
        struct.pack_into('<3h', p, 56, -1000, 0, 981)
        row = decode_payload(p)
        self.assertEqual((row['last_error'], row['accel_x_raw'], row['i2c_khz']), (-5, -1000, 400))
        for bad in (p[:63], bytes([2]) + p[1:]):
            with self.assertRaises(ValueError):
                decode_payload(bad)
        for offset, value in ((2, 0), (3, 2), (46, 0x30), (47, 144), (55, 5)):
            bad = p.copy(); bad[offset] = value
            with self.assertRaises(ValueError):
                decode_payload(bad)

    def test_ack_negative_result_and_invalid_reserved(self):
        p = bytearray(24)
        struct.pack_into('<BBBBIII', p, 0, 1, 8, 0, 0, 42, 0, 0)
        p[16] = ord('S')
        struct.pack_into('<i', p, 20, -11)
        self.assertEqual(decode_payload(p)['command_result'], -11)
        for offset, value in ((19, 1), (18, 4), (17, 5), (16, ord('X')), (3, 1)):
            bad = p.copy(); bad[offset] = value
            with self.assertRaises(ValueError):
                decode_payload(bad)


if __name__ == '__main__':
    unittest.main()
