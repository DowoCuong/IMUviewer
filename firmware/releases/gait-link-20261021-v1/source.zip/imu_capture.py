"""Capture IMU1 binary USB frames; no legacy/text stream support.

Examples (use the NCS toolchain Python with pyserial):
  python imu_capture.py --port COM9 --source node --seconds 120 --out node.csv
  python imu_capture.py --port COM6 --source hub --out hub.csv
  python imu_capture.py --port COM9 --command query
  python imu_capture.py --port COM9 --command save

Commands are LOCAL node USB only: query/save/reload/clear/pause/resume map to
Q/S/L/C/P/R plus newline. Capture never sends a command or resets input buffers.
Opening the serial port asserts DTR. Capture waits indefinitely for the first
DATA with state=2, calibration=255, valid=1, stale=0 and paused=0 before starting
--seconds. --startup-timeout only bounds waiting for any valid binary frame;
STATS/STATUS/beacons satisfy it. CSV keeps waiting records, labeled by phase.
A submitted command is not confirmation that calibration was saved/reloaded/cleared;
new firmware emits command ACK records; older firmware may not. Observation is bounded.
"""
import argparse
from collections import Counter, defaultdict
from contextlib import contextmanager
import csv
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import statistics
import struct
import time
import zlib

MAGIC = b'IMU1'
MASK32 = 0xffffffff
HALF32 = 0x80000000
TYPES = {1: 'data', 2: 'status', 3: 'beacon', 4: 'followup', 5: 'diag', 6: 'stats', 7: 'sensor_diag', 8: 'command_ack', 9: 'timed_data'}
LENGTHS = {1: 40, 2: 40, 3: 32, 4: 32, 5: 40, 6: 64, 7: 64, 8: 24, 9: 64}
COUNTERS = ('reads', 'i2c_errors', 'acq_missed', 'radio_sent', 'radio_missed',
            'write_errors', 'queue_drops', 'usb_drops', 'sync_losses',
            'invalid_packets', 'command_drops', 'uptime_ms')
COMMANDS = dict(query='Q', save='S', reload='L', clear='C', pause='P', resume='R')
FIELDS = (
    'pc_elapsed_s', 'capture_phase', 'measurement_elapsed_s', 'source',
    'event_us_low32', 'record', 'version', 'type',
    'node', 'flags', 'valid', 'synced', 'stale', 'paused', 'session', 'tx_seq',
    'read_seq', 'completed_us', 'qw', 'qx', 'qy', 'qz', 'calibration', 'state',
    'beacon_age_us', 'beacon_event_us_low32', 'hub_frame', 'period_us', 'nodes',
    'rate_code', 'rate_hz', 'transaction_us', 'tx_start_us_low32',
    'read_interval_us', 'i2c_duration_us', 'lateness_us', 'attempts', 'ack',
    'sensor_uptime_ms', 'init_count', 'recovery_count', 'reset_errors',
    'runtime_errors', 'consecutive_errors', 'last_error', 'last_error_reg',
    'last_error_phase', 'i2c_address', 'i2c_khz', 'calib_raw', 'sys_status',
    'sys_error', 'unit_sel', 'opr_mode', 'pwr_mode', 'page', 'nvs_state',
    'accel_x_raw', 'accel_y_raw', 'accel_z_raw', 'chip_id', 'st_result',
    'command', 'command_result', 'command_nvs_state', 'command_sensor_state',
) + ('local_anchor_us', 'hub_anchor_us', 'clock_ppm', 'clock_uncertainty_us',
     'hub_session', 'sample_i2c_duration_us') + COUNTERS
LIMITATIONS = [
    'Exact distributions describe accepted captured records only, not unseen transactions.',
    'Full per-transaction diagnostics are local transmitter USB only, from a bounded live '
    'stream; the hub USB data stream cannot supply ACK failures, retries or transaction latency.',
    'Sequence gaps are absent identities between observed endpoints, not proven RF losses. '
    'Initial/final losses are invisible; USB, queues, write errors and missed slots may contribute.',
    'CRC errors, malformed frames, partial tails and device drop counters indicate incomplete '
    'coverage. Zero observed gaps does not establish lossless capture.',
    'Distinct read_seq identifies distinct sensor reads, not fresh internal fusion updates. '
    'Equal quaternions can belong to different reads; cached retransmissions retain read_seq.',
    'transaction_us is submission-to-radio-completion time, including retries, not one-way '
    'latency. Failed completion times are separate from successful ACK timing.',
    'PC arrival times and hub/local event low32 clocks are not interchangeable with node '
    'completed_us. No one-way or IMU-to-PC latency is inferred, even with the synced flag.',
    '32-bit sequence/counter/timer comparisons assume consecutive observations less than '
    '2^31 units apart. Session changes separate reboots; a reused session or long gap is ambiguous.',
    'Stats snapshots are cumulative since device boot. Counter deltas/rates cover only '
    'accepted consecutive snapshot intervals; they are not exact whole-capture totals.',
    'tx_seq advances on application submission attempts, not skipped slots; skips emit no DIAG. '
    'attempts=0 may be a write error or timeout with no completion callback, not a counted RF failure. '
    'transaction_us=0xFFFFFFFF means unknown duration and is excluded from timing distributions.',
    'Exact percentiles retain captured records in host RAM; firmware queues and USB remain bounded.',
]


def decode_payload(payload, nodes=4):
    """Decode the little-endian schema in src/imu_protocol.h, rejecting malformed fields."""
    if not 1 <= nodes <= 4:
        raise ValueError('nodes must be 1..4')
    if len(payload) < 16:
        raise ValueError('short header')
    version, kind, node, flags, session, tx_seq, read_seq = struct.unpack_from('<BBBBIII', payload)
    if version != 1 or kind not in LENGTHS or len(payload) != LENGTHS[kind]:
        raise ValueError('unsupported version/type or incorrect payload length')
    if flags & 0xf0 or node > nodes:
        raise ValueError('invalid flags or node')
    if kind in (1, 2, 5, 7, 9) and node == 0:
        raise ValueError('node packet requires node 1..nodes')
    row = dict(version=version, type=kind, record=TYPES[kind], node=node, flags=flags,
               session=session, tx_seq=tx_seq, read_seq=read_seq,
               valid=int(bool(flags & 1)), synced=int(bool(flags & 2)),
               stale=int(bool(flags & 4)), paused=int(bool(flags & 8)))
    if kind in (1, 2, 9):
        if bool(flags & 1) != (kind != 2) or payload[33] > 3 or any(payload[34:36]):
            raise ValueError('invalid sample validity/state/reserved bytes')
        completed, w, x, y, z, calibration, state, age = struct.unpack_from('<Q4hBB2xI', payload, 16)
        row.update(completed_us=completed, qw=w, qx=x, qy=y, qz=z,
                   calibration=calibration, state=state, beacon_age_us=age)
        if kind == 9:
            local, hub, ppm, uncertainty, hub_session, duration = struct.unpack_from('<IIiIII', payload, 40)
            if not flags & 2 or abs(ppm) > 200 or uncertainty > 50 or duration > 30000:
                raise ValueError('invalid timed-data clock mapping')
            row.update(local_anchor_us=local, hub_anchor_us=hub, clock_ppm=ppm,
                       clock_uncertainty_us=uncertainty, hub_session=hub_session,
                       sample_i2c_duration_us=duration)
    elif kind in (3, 4):
        event, frame, period, count, rate = struct.unpack_from('<IIIBB', payload, 16)
        if node != 0 or flags or read_seq or not 1 <= count <= 4 or rate not in (0, 1) or any(payload[30:32]) or period != 40000:
            raise ValueError('invalid beacon/followup fields')
        row.update(beacon_event_us_low32=event, hub_frame=frame, period_us=period,
                   nodes=count, rate_code=rate, rate_hz=400 if rate else 100)
    elif kind == 5:
        transaction, start, interval, duration, late, attempts, ack = struct.unpack_from('<5IBB', payload, 16)
        if ack not in (0, 1) or any(payload[38:40]):
            raise ValueError('invalid diagnostic ACK/reserved bytes')
        # The wire schema defines an unrestricted u8 attempts field, not a retry limit.
        row.update(transaction_us=transaction, tx_start_us_low32=start,
                   read_interval_us=interval, i2c_duration_us=duration, lateness_us=late,
                   attempts=attempts, ack=ack)
    elif kind == 6:
        row.update(zip(COUNTERS, struct.unpack_from('<12I', payload, 16)))
    elif kind == 7:
        if flags & 2 or payload[46] not in (0, 0x28, 0x29) or payload[47] not in (0, 100) or payload[55] > 4:
            raise ValueError('invalid sensor diagnostic fields')
        values = struct.unpack_from('<7I4B8B3h2B', payload, 16)
        (uptime, init_count, recovery_count, reset_errors, runtime_errors,
         consecutive, last_error, last_reg, last_phase, address,
         i2c_khz, calib_raw, sys_status, sys_error, unit_sel, opr_mode,
         pwr_mode, page, nvs_state, ax, ay, az, chip_id, st_result) = values
        row.update(sensor_uptime_ms=uptime, init_count=init_count,
                   recovery_count=recovery_count, reset_errors=reset_errors,
                   runtime_errors=runtime_errors, consecutive_errors=consecutive,
                   last_error=struct.unpack('<i', struct.pack('<I', last_error))[0],
                   last_error_reg=last_reg, last_error_phase=last_phase,
                   i2c_address=address, i2c_khz=400 if i2c_khz == 0 else i2c_khz, calib_raw=calib_raw,
                   sys_status=sys_status, sys_error=sys_error, unit_sel=unit_sel,
                   opr_mode=opr_mode, pwr_mode=pwr_mode, page=page,
                   nvs_state=nvs_state, accel_x_raw=ax, accel_y_raw=ay,
                   accel_z_raw=az, chip_id=chip_id, st_result=st_result)
    else:
        command, nvs_state, sensor_state, reserved, result = struct.unpack_from('<4BI', payload, 16)
        if flags or reserved or command not in b'QSLCPR' or nvs_state > 4 or sensor_state > 3:
            raise ValueError('invalid command acknowledgement')
        row.update(command=chr(command), command_result=struct.unpack('<i', struct.pack('<I', result))[0],
                   command_nvs_state=nvs_state, command_sensor_state=sensor_state)
    return row


def encode_frame(payload, event_us_low32=0):
    """Frame helper for offline fixtures; CRC excludes magic and includes length/timestamp."""
    if not 16 <= len(payload) <= 64:
        raise ValueError('payload length must be 16..64')
    body = struct.pack('<HI', len(payload), event_us_low32) + payload
    return MAGIC + body + struct.pack('<I', zlib.crc32(body) & MASK32)


class FrameDecoder:
    """Incremental bounded framing, preserving fragments and resynchronizing after damage."""
    def __init__(self, nodes=4):
        if not 1 <= nodes <= 4:
            raise ValueError('nodes must be 1..4')
        self.nodes = nodes
        self.buffer = bytearray()
        self.counts = Counter()

    def feed(self, data, final=False):
        self.buffer.extend(data)
        rows = []
        while self.buffer:
            pos = self.buffer.find(MAGIC)
            if pos < 0:
                suffix = next((n for n in (3, 2, 1) if self.buffer.endswith(MAGIC[:n])), 0)
                if final and suffix:
                    self.counts['truncated_candidates'] += 1
                keep = 0 if final else suffix
                discard = len(self.buffer) - keep
                self.counts['discarded_bytes'] += discard
                if discard:
                    del self.buffer[:discard]
                break
            if pos:
                self.counts['discarded_bytes'] += pos
                del self.buffer[:pos]
            if len(self.buffer) < 10:
                if not final:
                    break
                self.counts['truncated_candidates'] += 1
                self.counts['discarded_bytes'] += len(self.buffer)
                self.buffer.clear()
                break
            size, event = struct.unpack_from('<HI', self.buffer, 4)
            if not 16 <= size <= 64:
                self.counts['invalid_lengths'] += 1
                self.counts['discarded_bytes'] += 1
                del self.buffer[0]
                continue
            total = 14 + size
            if len(self.buffer) < total:
                if not final:
                    break
                # At EOF a corrupt length must not hide a later complete frame.
                self.counts['truncated_candidates'] += 1
                self.counts['discarded_bytes'] += 1
                del self.buffer[0]
                continue
            expected = struct.unpack_from('<I', self.buffer, total - 4)[0]
            if zlib.crc32(self.buffer[4:total - 4]) & MASK32 != expected:
                self.counts['crc_errors'] += 1
                self.counts['discarded_bytes'] += 1
                del self.buffer[0]
                continue
            payload = bytes(self.buffer[10:total - 4])
            del self.buffer[:total]
            self.counts['crc_valid_frames'] += 1
            try:
                row = decode_payload(payload, self.nodes)
            except ValueError:
                self.counts['malformed_payloads'] += 1
                continue
            row['event_us_low32'] = event
            rows.append(row)
            self.counts['accepted_frames'] += 1
        return rows

    def finish(self):
        self.counts['pending_bytes_at_end'] = len(self.buffer)
        return self.feed(b'', final=True)


def distribution(values):
    """Exact captured-sample statistics; percentiles use nearest rank, no histogram approximation."""
    values = sorted(values)
    if not values:
        return dict(count=0, min=None, mean=None, median=None, p95=None, p96=None, p99=None, max=None)
    result = dict(count=len(values), min=values[0], mean=statistics.mean(values),
                  median=statistics.median(values), max=values[-1])
    result.update({f'p{p}': values[(p * len(values) + 99) // 100 - 1] for p in (95, 96, 99)})
    return result


class SequenceTracker:
    """Unwrap relative to high water; late packets fill gaps without creating false gaps."""
    def __init__(self):
        self.high = None
        self.seen = set()
        self.duplicates = 0
        self.out_of_order = 0

    def add(self, seq):
        if self.high is None:
            absolute = seq
        else:
            delta = ((seq - (self.high & MASK32) + HALF32) & MASK32) - HALF32
            absolute = self.high + delta
        duplicate = absolute in self.seen
        if duplicate:
            self.duplicates += 1
        elif self.high is not None and absolute < self.high:
            self.out_of_order += 1
        self.seen.add(absolute)
        self.high = absolute if self.high is None else max(self.high, absolute)
        return not duplicate, absolute

    def summary(self):
        missing = max(self.seen) - min(self.seen) + 1 - len(self.seen) if self.seen else 0
        return dict(distinct=len(self.seen), duplicates=self.duplicates,
                    out_of_order=self.out_of_order, missing_between_endpoints=missing)


def cadence(points, low32=False):
    """Rate of observed unique identities over their device-time endpoint span."""
    points = sorted(points.items())
    intervals = []
    discontinuities = 0
    for (_, previous), (_, current) in zip(points, points[1:]):
        delta = (current - previous) & MASK32 if low32 else current - previous
        if delta <= 0 or (low32 and delta >= HALF32):
            discontinuities += 1
        else:
            intervals.append(delta)
    span = sum(intervals)
    return dict(observed_interval_us=distribution(intervals), discontinuities=discontinuities,
                endpoint_span_us=span if not discontinuities else None,
                observed_hz=(len(points) - 1) * 1e6 / span if span and not discontinuities else None)


def counter_summary(rows):
    totals = Counter({key: 0 for key in COUNTERS[:-1]})
    duration_ms = intervals = discontinuities = 0
    for previous, current in zip(rows, rows[1:]):
        deltas = {key: (current[key] - previous[key]) & MASK32 for key in COUNTERS}
        if not 0 < deltas['uptime_ms'] < HALF32 or any(v >= HALF32 for v in deltas.values()):
            discontinuities += 1
            continue
        intervals += 1
        duration_ms += deltas.pop('uptime_ms')
        totals.update(deltas)
    return dict(snapshots=len(rows), latest_cumulative={k: rows[-1][k] for k in COUNTERS} if rows else None,
                accepted_intervals=intervals, discontinuities=discontinuities,
                covered_duration_ms=duration_ms, deltas=dict(totals),
                per_second={k: v * 1000 / duration_ms if duration_ms else None for k, v in totals.items()})


class CaptureSummary:
    def __init__(self):
        self.groups = defaultdict(list)

    def add(self, row):
        self.groups[(row['node'], row['session'])].append(row)

    def report(self, elapsed_s):
        groups = []
        for (node, session), rows in sorted(self.groups.items()):
            samples = [r for r in rows if r['type'] in (1, 2, 9)]
            diags = [r for r in rows if r['type'] == 5]
            tx, reads, diag_seq = SequenceTracker(), SequenceTracker(), SequenceTracker()
            read_points, tx_points = {}, {}
            cached = invalid = conflicting_reads = 0
            identities = {}
            for row in samples:
                tx.add(row['tx_seq'])
                if not row['valid']:
                    invalid += 1
                    continue
                new, seq = reads.add(row['read_seq'])
                signature = tuple(row[k] for k in ('completed_us', 'qw', 'qx', 'qy', 'qz'))
                if new:
                    read_points[seq] = row['completed_us']
                    identities[seq] = signature
                else:
                    cached += 1
                    conflicting_reads += identities[seq] != signature
            unique_diags = []
            conflicting_diags = 0
            diag_identities = {}
            for row in diags:
                new, seq = diag_seq.add(row['tx_seq'])
                signature = tuple(row[k] for k in ('transaction_us', 'tx_start_us_low32', 'attempts', 'ack', 'read_seq'))
                if new:
                    unique_diags.append(row)
                    tx_points[seq] = row['tx_start_us_low32']
                    diag_identities[seq] = signature
                else:
                    conflicting_diags += diag_identities[seq] != signature
            success = [r for r in unique_diags if r['ack']]
            failed = [r for r in unique_diags if not r['ack']]
            subsets = dict(success=success, first_attempt_success=[r for r in success if r['attempts'] == 1],
                           retried_success=[r for r in success if r['attempts'] > 1], failure=failed)
            counts = Counter(r['record'] for r in rows)
            group = dict(node=node, session=session, captured_records=len(rows), record_counts=dict(counts),
                         records_per_pc_capture_second={k: n / elapsed_s if elapsed_s > 0 else None for k, n in counts.items()},
                         sample_tx_sequences=tx.summary(), valid_read_sequences=reads.summary(),
                         cached_valid_records=cached, invalid_status_records=invalid,
                         conflicting_read_identities=conflicting_reads,
                         flags={name: sum(r[name] for r in samples) for name in ('valid', 'synced', 'stale', 'paused')},
                         distinct_read_cadence=cadence(read_points),
                         diagnostic_sequences=diag_seq.summary(), conflicting_diagnostic_identities=conflicting_diags,
                         captured_transactions=len(unique_diags), successes=len(success), failures=len(failed),
                         success_percent=100 * len(success) / len(unique_diags) if unique_diags else None,
                         failure_percent=100 * len(failed) / len(unique_diags) if unique_diags else None,
                         unknown_transaction_durations=sum(r['transaction_us'] == MASK32 for r in unique_diags),
                         zero_attempt_diagnostics=sum(r['attempts'] == 0 for r in unique_diags),
                         transaction_us={key: distribution(r['transaction_us'] for r in subset
                                                           if r['transaction_us'] != MASK32)
                                         for key, subset in subsets.items()},
                         attempts={key: dict(distribution=distribution(r['attempts'] for r in subset),
                                            histogram=dict(sorted(Counter(r['attempts'] for r in subset).items())))
                                   for key, subset in dict(all=unique_diags, success=success, failure=failed).items()},
                         diagnostic_tx_cadence=cadence(tx_points, low32=True),
                         diagnostic_timing_us={key: distribution(r[key] for r in unique_diags)
                                               for key in ('read_interval_us', 'i2c_duration_us', 'lateness_us')},
                         counters=counter_summary([r for r in rows if r['type'] == 6]))
            groups.append(group)
        return dict(pc_capture_duration_s=elapsed_s, percentile_method='nearest rank; median averages middle pair',
                    distribution_coverage='unique captured diagnostic tx_seq per node/session; duplicates excluded',
                    rate_coverage='PC rates use entire capture duration; device cadence uses first/last distinct observed identities',
                    groups=groups)


@contextmanager
def output_files(path):
    """Reserve both names exclusively before opening hardware; never overwrite either artifact."""
    path = Path(path)
    metadata_path = path.with_suffix('.metadata.json')
    if path == metadata_path:
        raise ValueError('CSV path must differ from metadata path')
    output = path.open('x', newline='', encoding='utf-8')
    try:
        metadata = metadata_path.open('x', encoding='utf-8')
    except BaseException:
        output.close()
        path.unlink()  # Only the empty file exclusively created by this call.
        raise
    try:
        yield output, metadata, metadata_path
    finally:
        output.close()
        metadata.close()


def save_metadata(file, metadata):
    file.seek(0)
    json.dump(metadata, file, indent=2, allow_nan=False)
    file.write('\n')
    file.truncate()
    file.flush()


def serial_factory():
    import serial  # Offline parsing/tests and --help do not require pyserial.
    return serial.Serial


def positive_finite(value):
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise argparse.ArgumentTypeError('must be positive and finite')
    return value


def capture(args, factory=None):
    print(f'IMU capture starting: {args.port}; close other serial monitors.', flush=True)
    factory = factory or serial_factory()
    decoder, summary = FrameDecoder(args.nodes), CaptureSummary()
    measurement_summary = CaptureSummary()
    phase_counts = Counter(waiting=0, recording=0)
    measurement_started = None
    started = time.monotonic()
    metadata = dict(format='IMU1', schema_version=1, source=args.source, port=args.port,
                    requested_seconds=args.seconds, startup_timeout_s=args.startup_timeout,
                    started_utc=datetime.now(timezone.utc).isoformat(), status='starting',
                    measurement_started_utc=None, measurement_start_pc_elapsed_s=None,
                    measurement_gate='first DATA with valid=1, stale=0, paused=0, state=2, calibration=255; '
                    'calibration/fault waiting is unbounded',
                    csv_coverage='All accepted records; capture_phase distinguishes waiting from recording. '
                    'summary includes both phases; measurement_summary includes recording only.',
                    framing='IMU1 + u16 LE length + u32 LE event low32 + payload + CRC32(length,timestamp,payload)',
                    quaternion='raw int16 w,x,y,z; no fusion, normalization or axis remapping',
                    commands_sent=[], dtr=True, limitations=LIMITATIONS)
    with output_files(args.out) as (output, meta_file, metadata_path):
        writer = csv.DictWriter(output, fieldnames=FIELDS)
        writer.writeheader()
        output.flush()
        save_metadata(meta_file, metadata)

        def accept(rows, allow_start=True):
            nonlocal measurement_started
            for row in rows:
                now = time.monotonic()
                if (allow_start and measurement_started is None and row['type'] in (1, 9)
                        and row['valid'] and not row['stale'] and not row['paused']
                        and row['state'] == 2 and row['calibration'] == 255):
                    measurement_started = now
                    metadata.update(status='recording',
                                    measurement_started_utc=datetime.now(timezone.utc).isoformat(),
                                    measurement_start_pc_elapsed_s=now - started)
                    save_metadata(meta_file, metadata)
                    print(f'Ready DATA record seen; recording for {args.seconds:g}s.', flush=True)
                phase = 'waiting' if measurement_started is None else 'recording'
                row.update(pc_elapsed_s=now - started, source=args.source, capture_phase=phase,
                           measurement_elapsed_s=None if measurement_started is None else now - measurement_started)
                writer.writerow(row)
                summary.add(row)
                phase_counts[phase] += 1
                if phase == 'recording':
                    measurement_summary.add(row)
            if rows:
                output.flush()

        try:
            print(f'Opening {args.port}; asserting DTR, no command writes.', flush=True)
            with factory(args.port, 115200, timeout=.25, write_timeout=3) as port:
                port.dtr = True
                started = time.monotonic()
                metadata['status'] = 'waiting'
                save_metadata(meta_file, metadata)
                print(f'Waiting indefinitely for calibrated DATA (state=2, calibration=255, '
                      f'valid, nonstale, unpaused); then recording {args.seconds:g}s '
                      f'-> {Path(args.out).resolve()}', flush=True)
                while measurement_started is None or time.monotonic() < measurement_started + args.seconds:
                    accept(decoder.feed(port.read(4096)))
                    # STATS, STATUS and hub beacons also prove the binary stream is alive.
                    if not decoder.counts['accepted_frames'] and time.monotonic() - started >= args.startup_timeout:
                        raise TimeoutError('No valid IMU1 frames before startup timeout; check firmware/port/DTR')
            metadata['status'] = 'completed'
        except KeyboardInterrupt:
            metadata['status'] = 'interrupted'
            print('\nCapture stopped; retaining accepted records.', flush=True)
        except Exception as exc:
            metadata.update(status='error', error=f'{type(exc).__name__}: {exc}')
            raise
        finally:
            # EOF recovery retains records but must not start a measurement after stopping.
            accept(decoder.finish(), allow_start=False)
            ended = time.monotonic()
            elapsed = ended - started
            recording_s = 0 if measurement_started is None else ended - measurement_started
            metadata.update(ended_utc=datetime.now(timezone.utc).isoformat(), framing_counts=dict(decoder.counts),
                            calibration_wait_s=elapsed if measurement_started is None else measurement_started - started,
                            measurement_duration_s=recording_s, phase_record_counts=dict(phase_counts),
                            summary=summary.report(elapsed), measurement_summary=measurement_summary.report(recording_s))
            save_metadata(meta_file, metadata)
    print(json.dumps(metadata['summary'], indent=2), flush=True)
    print('Framing/capture loss indicators: ' + json.dumps(metadata['framing_counts']), flush=True)
    if not decoder.counts['accepted_frames']:
        print('No valid IMU1 records captured; no measured rates or latency statistics are available.', flush=True)
    print('Coverage limitations:\n- ' + '\n- '.join(LIMITATIONS), flush=True)
    print(f'Saved {Path(args.out).resolve()} and {metadata_path.resolve()}', flush=True)
    return metadata


def command(args, factory=None):
    """Submit only an explicitly requested command; observe binary replies for bounded time."""
    print(f'Opening local node USB {args.port} for explicit {args.command} command.', flush=True)
    factory = factory or serial_factory()
    decoder = FrameDecoder(args.nodes)
    acknowledged = False
    with factory(args.port, 115200, timeout=.25, write_timeout=3) as port:
        port.dtr = True
        wire = (COMMANDS[args.command] + '\n').encode('ascii')
        if port.write(wire) != len(wire):
            raise IOError('Short command write; command execution is unknown')
        # Do not flush(): Windows serial flush/drain is not bounded by write_timeout.
        print('Command submitted, not acknowledged. Observing binary records only.', flush=True)
        deadline = time.monotonic() + args.seconds
        while time.monotonic() < deadline:
            for row in decoder.feed(port.read(4096)):
                print(json.dumps(row), flush=True)
                if row['type'] == 8 and row['command'] == COMMANDS[args.command]:
                    acknowledged = True
                    print(f"Command {row['command']} ACK result={row['command_result']}", flush=True)
        for row in decoder.finish():
            print(json.dumps(row), flush=True)
    if not acknowledged:
        print('No matching command ACK observed; execution is unconfirmed. Older firmware may not emit ACKs.', flush=True)
    return dict(decoder.counts)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--port', required=True, help='Application COM port, not bootloader')
    parser.add_argument('--source', choices=('node', 'hub'), default='hub', help='Capture clock/coverage label (default hub)')
    parser.add_argument('--nodes', type=int, choices=range(1, 5), default=4)
    parser.add_argument('--seconds', type=positive_finite,
                        help='Measurement duration after first calibrated, valid, nonstale, unpaused DATA (120s); '
                        'command observation duration remains finite from submission (2s)')
    parser.add_argument('--startup-timeout', type=positive_finite, default=10,
                        help='Seconds to first valid binary frame (including STATS/STATUS/beacons); '
                        'not a calibration timeout')
    parser.add_argument('--out', type=Path, help='New CSV name; metadata uses .metadata.json suffix')
    parser.add_argument('--command', choices=tuple(COMMANDS), help='Standalone local node USB command; no CSV capture')
    args = parser.parse_args(argv)
    if args.command and args.out:
        parser.error('--command is standalone and cannot be combined with --out')
    args.seconds = args.seconds if args.seconds is not None else (2 if args.command else 120)
    args.out = args.out or Path('imu.csv')
    try:
        if args.command:
            command(args)
        else:
            capture(args)
    except KeyboardInterrupt:
        print('\nStopped; a submitted command may already have executed.', flush=True)
        return 130
    except (OSError, ValueError, ImportError) as exc:
        print(f'Error: {exc}', flush=True)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
