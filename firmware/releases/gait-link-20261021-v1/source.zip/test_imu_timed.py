"""Clock-map wire format and four-node slot regression tests; no hardware."""
from pathlib import Path
import struct
import tempfile
import unittest

import imu_capture
from test_imu_radio import ATOMIC, ESB, KERNEL, RADIO_TEST, compile_run


class TimedDataTests(unittest.TestCase):
    def payload(self):
        p = bytearray(64)
        struct.pack_into('<BBBBIII', p, 0, 1, 9, 4, 3, 123, 10, 7)
        struct.pack_into('<Q4hBB2xI', p, 16, 1011000, 16384, 0, 0, 0, 255, 2, 1000)
        struct.pack_into('<IIiIII', p, 40, 1000000, 5000000, 100, 30, 99, 1100)
        return p

    def test_capture_retains_clock_fit_and_read_time(self):
        row = imu_capture.decode_payload(self.payload())
        self.assertEqual(row['record'], 'timed_data')
        self.assertEqual(row['node'], 4)
        self.assertEqual(row['completed_us'], 1011000)
        self.assertEqual(row['clock_ppm'], 100)
        self.assertEqual(row['sample_i2c_duration_us'], 1100)

    def test_bad_fit_and_missing_sync_flag_are_rejected(self):
        for offset, fmt, value in ((3, '<B', 1), (48, '<i', 201), (52, '<I', 51), (60, '<I', 30001)):
            p = self.payload()
            struct.pack_into(fmt, p, offset, value)
            with self.assertRaises(ValueError):
                imu_capture.decode_payload(p)

    def test_actual_radio_source_emits_timed_samples_for_all_four_nodes(self):
        for node in range(1, 5):
            with self.subTest(node=node), tempfile.TemporaryDirectory() as tmp:
                tmp = Path(tmp)
                (tmp/'zephyr'/'sys').mkdir(parents=True)
                (tmp/'zephyr'/'kernel.h').write_text(KERNEL)
                (tmp/'zephyr'/'sys'/'atomic.h').write_text(ATOMIC)
                (tmp/'esb.h').write_text(ESB)
                source = RADIO_TEST.split('int main(void) {')[0]
                source = source.replace('#define CONFIG_IMU_NODES 1', '#define CONFIG_IMU_NODES 4')
                source = source.replace('#define CONFIG_IMU_NODE_ID 1', f'#define CONFIG_IMU_NODE_ID {node}')
                source = source.replace('p->pipe==1', 'p->pipe==CONFIG_IMU_NODE_ID')
                source += r'''
int main(void) {
    struct imu_sync s=reset_test();
    node_frame(&s);
    assert(calls==4 && published==8);
    for(unsigned i=0;i<4;++i) {
        assert(records[2*i][1]==IMU_TIMED_DATA);
        assert(records[2*i][2]==CONFIG_IMU_NODE_ID);
        assert(imu_validate(records[2*i],64,4));
        assert(imu_get32(records[2*i+1]+20)==15000+i*10000+(CONFIG_IMU_NODE_ID-1)*1000);
    }
    /* Each 4-node group ends before the next 10 ms group and frame guard. */
    for(unsigned i=0;i<4;++i) {
        assert(imu_slot_offset(100,i,4)+IMU_SLOT_US<=40000);
        if(i<3) assert(imu_slot_offset(100,i,4)+IMU_SLOT_US<=imu_slot_offset(100,i+1,1));
    }
    return 0;
}
'''
                compile_run(source, tmp)

    def check_unusable_snapshot(self, mutation, expected_kind=1):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp/'zephyr/sys').mkdir(parents=True)
            (tmp/'zephyr/kernel.h').write_text(KERNEL)
            (tmp/'zephyr/sys/atomic.h').write_text(ATOMIC)
            (tmp/'esb.h').write_text(ESB)
            source = RADIO_TEST.split('int main(void) {')[0]
            source = source.replace('s->state=IMU_READY;',
                                    's->state=IMU_READY; s->q[0]=16384; '+mutation)
            source += f'\n#define EXPECTED_KIND {expected_kind}\n'
            source += r'''
int main(void) {
    struct imu_sync s=reset_test();
    now=1000000;
    s.frame=s.local_anchor=s.hub_anchor=(uint32_t)now;
    s.last_pair=(uint32_t)now+1200; s.beacon_rx=(uint32_t)now+240;
    node_frame(&s);
    assert(calls==4 && published==8);
    for(unsigned i=0;i<4;++i) {
        /* Preserve a valid diagnostic record, without an unusable clock map. */
        assert(records[2*i][1]==EXPECTED_KIND && (records[2*i][3]&IMU_STALE));
        assert(imu_validate(records[2*i],EXPECTED_KIND==IMU_DATA?IMU_DATA_LEN:IMU_TIMED_DATA_LEN,1));
    }
    FILE *f=fopen("fallback.bin","wb"); assert(f);
    unsigned length=EXPECTED_KIND==IMU_DATA?IMU_DATA_LEN:IMU_TIMED_DATA_LEN;
    assert(fwrite(records[0],1,length,f)==length); fclose(f);
    return 0;
}
'''
            compile_run(source, tmp)
            row = imu_capture.decode_payload((tmp/'fallback.bin').read_bytes())
            self.assertTrue(row['flags'] & 4)

    def test_slow_successful_read_preserves_stale_diagnostic_packet(self):
        self.check_unusable_snapshot('m->duration_us=30001;')

    def test_old_fault_snapshot_does_not_export_expired_clock_fit(self):
        self.check_unusable_snapshot('s->completed_us=1000; s->state=IMU_SENSOR_FAULT;')

    def test_recent_fault_keeps_valid_clock_map_and_stale_flag(self):
        self.check_unusable_snapshot('s->state=IMU_SENSOR_FAULT;', expected_kind=9)


if __name__ == '__main__':
    unittest.main()
