"""Actual C clock, USB and radio recovery paths; fake peripherals, no boards.

Clock tests follow ESB8's lifetime-HFXO check. USB tests extend its FIFO design
with a bounded stall, disconnect/reopen and independent Python CRC validation.
"""
from pathlib import Path
import struct
import tempfile
import unittest
import zlib

from test_imu_radio import ATOMIC, ESB, KERNEL, RADIO_TEST, ROOT, compile_run


def section(source, start, end):
    return source[source.index(start):source.index(end, source.index(start))]


CLOCK_MOCK = r'''
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <errno.h>
#define CLOCK_CONTROL_NRF_SUBSYS_HF 1
struct device { int dummy; };
static struct device timer;
static const struct device *wall_timer=&timer;
struct onoff_manager { unsigned refs; };
struct sys_notify { int dummy; };
struct onoff_client { struct sys_notify notify; };
static struct onoff_manager manager;
static bool ready=true, have_manager=true;
static int request_error, start_error, timer_error, pending, canceled;
static int64_t milliseconds;
static uint32_t frequency=1000000;
static bool device_is_ready(const struct device *p) { (void)p; return ready; }
static uint32_t counter_get_frequency(const struct device *p) { (void)p; return frequency; }
static int counter_start(const struct device *p) { (void)p; assert(manager.refs); return timer_error; }
static struct onoff_manager *z_nrf_clock_control_get_onoff(int subsystem) {
    assert(subsystem==1); return have_manager?&manager:0;
}
static void sys_notify_init_spinwait(struct sys_notify *n) { (void)n; }
static int onoff_request(struct onoff_manager *m,struct onoff_client *c) {
    (void)c; if(request_error) return request_error; ++m->refs; return 0;
}
static int sys_notify_fetch_result(struct sys_notify *n,int *result) {
    (void)n; if(pending) { --pending; return -EAGAIN; }
    *result=start_error; return 0;
}
static int onoff_cancel_or_release(struct onoff_manager *m,struct onoff_client *c) {
    (void)c; assert(m->refs); --m->refs; ++canceled; return 0;
}
static int64_t k_uptime_get(void) { return milliseconds; }
static void k_msleep(int ms) { milliseconds+=ms; }
'''
USB_MOCK = r'''
#include <assert.h>
#include <stdio.h>
#include "imu_protocol.h"
#define ARG_UNUSED(x) (void)(x)
#define K_MSEC(x) (x)
#define K_SEM_DEFINE(n,a,b) static int n=a
struct k_spinlock { int unused; };
typedef int k_spinlock_key_t;
static int locked;
static k_spinlock_key_t k_spin_lock(struct k_spinlock *p) { (void)p; ++locked; return 0; }
static void k_spin_unlock(struct k_spinlock *p,int k) { (void)p; (void)k; --locked; }
struct device { int unused; };
static struct device mock_usb;
static const struct device *usb=&mock_usb;
static bool ready=true, dtr=true, tx_enabled;
static uint32_t now_ms, disconnect_at;
static int capacity=7, failures;
static unsigned enabled_count, sink_len, rx_len, rx_offset;
static uint8_t sink[4096], rx[128];
static int commands, command_drops, command_resync, usb_drops;
static int rx_capacity=64;
static bool device_is_ready(const struct device *p) { assert(p==usb); return ready; }
#define UART_LINE_CTRL_DTR 1
static int uart_line_ctrl_get(const struct device *p,int ctrl,uint32_t *value) {
    assert(p==usb && ctrl==1); *value=dtr; return 0;
}
static uint32_t k_uptime_get_32(void) { return now_ms; }
static void k_sem_reset(int *p) { *p=0; }
static void k_sem_give(int *p) { *p=1; }
static void uart_irq_tx_enable(const struct device *p) { assert(p==usb); tx_enabled=true; ++enabled_count; }
static void uart_irq_tx_disable(const struct device *p) { assert(p==usb); tx_enabled=false; }
static int uart_irq_update(const struct device *p) { assert(p==usb); return 1; }
static int uart_irq_rx_ready(const struct device *p) { assert(p==usb); return rx_offset<rx_len; }
static int uart_irq_tx_ready(const struct device *p) { assert(p==usb); return tx_enabled; }
static int uart_fifo_read(const struct device *p,uint8_t *out,int n) {
    assert(p==usb && n==1); if(rx_offset>=rx_len) return 0; *out=rx[rx_offset++]; return 1;
}
static int k_msgq_put(int *p,const void *value,int timeout) {
    assert(p==&commands); (void)value; (void)timeout;
    if(rx_capacity<=0) return -1; --rx_capacity; return 0;
}
#define K_NO_WAIT 0
static void atomic_inc(int *p) { ++*p; }
static void atomic_set(int *p,int value) { *p=value; }
static int uart_fifo_fill(const struct device *p,const uint8_t *data,int n) {
    assert(p==usb && n>0);
    if(failures) { --failures; return -1; }
    if(capacity==0) return 0;
    int count=n<capacity?n:capacity;
    assert(sink_len+count<=sizeof(sink)); memcpy(sink+sink_len,data,count); sink_len+=count;
    return count;
}
static uint32_t crc32_ieee(const uint8_t *data,size_t length) {
    assert(!locked); uint32_t crc=~0U;
    while(length--) { crc^=*data++; for(int i=0;i<8;++i) crc=(crc>>1)^((crc&1)?0xedb88320U:0); }
    return ~crc;
}
static void uart_io(const struct device *,void *);
static int k_sem_take(int *p,int timeout) {
    if(*p) { *p=0; return 0; }
    now_ms+=timeout;
    if(disconnect_at && now_ms>=disconnect_at) dtr=false;
    if(tx_enabled && dtr) uart_io(usb,0);
    if(*p) { *p=0; return 0; }
    return -1;
}
'''


class LinkUpgradeTests(unittest.TestCase):
    def test_clock_holds_hfxo_without_usb_and_cleans_start_failures(self):
        source = (ROOT/'src/imu_main.c').read_text()
        clock = section(source, 'static int start_wall_clock(void)', 'uint64_t imu_clock_us(void)')
        self.assertIn('if ((err = start_wall_clock())) { fatal(err); }', source)
        with tempfile.TemporaryDirectory() as tmp:
            compile_run(CLOCK_MOCK+clock+r'''
int main(void) {
    pending=3; assert(!start_wall_clock() && manager.refs==1 && milliseconds==3);
    struct onoff_client esb;
    for(unsigned i=0;i<10000;++i) {
        assert(!onoff_request(&manager,&esb) && manager.refs==2);
        assert(!onoff_cancel_or_release(&manager,&esb) && manager.refs==1);
    }
    manager.refs=0; request_error=-1;
    assert(start_wall_clock()==-1 && !manager.refs); request_error=0;
    start_error=-1; assert(start_wall_clock()==-1 && !manager.refs); start_error=0;
    timer_error=-1; assert(start_wall_clock()==-1 && !manager.refs); timer_error=0;
    pending=2000; milliseconds=0;
    assert(start_wall_clock()==-ETIMEDOUT && !manager.refs && milliseconds==1000);
    have_manager=false; assert(start_wall_clock()==-ENODEV && !manager.refs);
    have_manager=true; ready=false; assert(start_wall_clock()==-ENODEV);
    ready=true; frequency=100; assert(start_wall_clock()==-ENODEV);
    return 0;
}
''', Path(tmp))

    def test_usb_partial_zero_negative_writes_stall_reopen_and_command_framing(self):
        source = (ROOT/'src/imu_main.c').read_text()
        declarations = section(source, 'struct record {', 'K_MSGQ_DEFINE(output,')
        declarations += section(source, 'static struct k_spinlock tx_lock;', 'void imu_publish(')
        send = section(source, 'static bool usb_open(void)', 'static void writer_thread(')
        callback = section(source, 'static void uart_io(', '/* Calibration persistence:')
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            compile_run(USB_MOCK+declarations+send+callback+r'''
int main(void) {
    struct record r={.event=123,.len=40};
    for(unsigned i=0;i<40;++i) r.data[i]=(uint8_t)i;
    dtr=false; usb_send_record(&r); assert(usb_drops==1 && !enabled_count);
    dtr=true; failures=2; usb_send_record(&r);
    assert(sink_len==54 && !tx_active && !tx_enabled && usb_drops==1);
    FILE *file=fopen("usb.bin","wb"); assert(file);
    assert(fwrite(sink,1,sink_len,file)==sink_len); fclose(file);
    /* A stalled host with DTR still asserted must not strand the writer. */
    capacity=0; uint32_t began=now_ms; usb_send_record(&r);
    assert(now_ms-began==100 && usb_drops==2 && !tx_active && !tx_enabled);
    capacity=100; usb_send_record(&r); assert(sink_len==108 && usb_drops==2);
    /* Disconnect in the middle of a frame, then resume without restarting USB. */
    sink_len=0; capacity=7; disconnect_at=now_ms+20;
    usb_send_record(&r); assert(sink_len==7 && usb_drops==3 && !tx_active);
    disconnect_at=0; dtr=true; capacity=100;
    usb_send_record(&r); assert(sink_len==61 && usb_drops==3);
    /* The progress timeout uses modular uptime, including its 49.7-day wrap. */
    now_ms=0xfffffff0U; capacity=0; began=now_ms;
    usb_send_record(&r); assert(now_ms-began==100 && usb_drops==4);
    struct command_parser parser={0}; char command=0;
    const char *bad="xxxxxxxxxC\nSx\n";
    while(*bad) assert(!command_parse(&parser,(uint8_t)*bad++,&command));
    assert(!command_parse(&parser,'C',&command));
    assert(!command_parse(&parser,0,&command));
    assert(!command_parse(&parser,'\n',&command));
    assert(!command_parse(&parser,'Q',&command));
    assert(!command_parse(&parser,'\r',&command));
    assert(command_parse(&parser,'\n',&command) && command=='Q');
    /* The real IRQ drains RX even while TX is stalled and marks lost framing. */
    memcpy(rx,"QQQQ",4); rx_len=4; rx_capacity=1;
    uart_io(usb,0); assert(command_resync==1 && rx_offset==4 && command_drops>=6);
    parser=(struct command_parser){.discard=true};
    assert(!command_parse(&parser,'S',&command));
    assert(!command_parse(&parser,'\n',&command));
    assert(!command_parse(&parser,'Q',&command));
    assert(command_parse(&parser,'\n',&command) && command=='Q');
    return 0;
}
''', tmp)
            frame = (tmp/'usb.bin').read_bytes()
            self.assertEqual(frame[:4], b'IMU1')
            self.assertEqual(struct.unpack_from('<HI', frame, 4), (40, 123))
            self.assertEqual(frame[10:50], bytes(range(40)))
            self.assertEqual(struct.unpack_from('<I', frame, 50)[0], zlib.crc32(frame[4:50]))
        self.assertNotIn('uart_poll_out(usb', source)
        self.assertIn('k_msgq_purge(&commands)', source)
        self.assertIn('uart_io, NULL', source)

    def radio_unit(self, tmp, source):
        (tmp/'zephyr/sys').mkdir(parents=True)
        (tmp/'zephyr/kernel.h').write_text(KERNEL)
        (tmp/'zephyr/sys/atomic.h').write_text(ATOMIC)
        (tmp/'esb.h').write_text(ESB)
        compile_run(source, tmp)

    def test_real_slot_scheduler_preserves_100_and_400_hz_with_slow_reconfiguration(self):
        for hz, nodes in ((100, 4), (400, 2)):
            for node in range(1, nodes+1):
                with self.subTest(hz=hz, node=node), tempfile.TemporaryDirectory() as tmp:
                    source = RADIO_TEST.split('int main(void) {')[0]
                    source = source.replace('#define CONFIG_IMU_NODES 1', f'#define CONFIG_IMU_NODES {nodes}')
                    source = source.replace('#define CONFIG_IMU_NODE_ID 1', f'#define CONFIG_IMU_NODE_ID {node}')
                    source = source.replace('#define CONFIG_IMU_RADIO_HZ 100', f'#define CONFIG_IMU_RADIO_HZ {hz}')
                    source = source.replace('p->pipe==1', 'p->pipe==CONFIG_IMU_NODE_ID')
                    source = source.replace('static uint64_t now;', 'static uint64_t now; static unsigned inits, sleeps;')
                    source = source.replace('k_usleep(uint32_t us) { k_busy_wait(us); }',
                                            'k_usleep(uint32_t us) { ++sleeps; k_busy_wait(us); }')
                    source = source.replace('c->tx_output_power==8); return 0;',
                                            'c->tx_output_power==8); ++inits; now+=1000; return 0;')
                    source += r'''
int main(void) {
    struct imu_sync s=reset_test();
    node_frame(&s);
    unsigned count=imu_slot_count(CONFIG_IMU_RADIO_HZ);
    assert(calls==count && published==2*count && !missed && s.locked);
    assert(inits==2 && prx && configured && !fatal_error);
    assert(now<s.frame+IMU_FRAME_US); /* Already listening before next beacon. */
    for(unsigned i=0;i<count;++i) {
        assert(imu_get32(records[2*i+1]+20)==
               s.frame+imu_slot_offset(CONFIG_IMU_RADIO_HZ,i,CONFIG_IMU_NODE_ID));
    }
    sleeps=0; uint32_t before=clock32(); wait_until(before+900);
    assert(sleeps && clock32()==before+900); /* Sensor gets CPU in short gaps. */
    return 0;
}
'''
                    self.radio_unit(Path(tmp), source)

    def test_single_timeout_does_not_throw_away_clock_lock(self):
        source = RADIO_TEST.split('int main(void) {')[0]
        source = source.replace('++calls;', '++calls; if(calls==2) completion_kind=ESB_EVENT_TX_SUCCESS;')
        source += r'''
int main(void) {
    struct imu_sync s=reset_test(); completion_kind=0;
    node_frame(&s);
    assert(calls==4 && published==8 && errors==1 && !losses && s.locked && prx);
    assert(records[1][37]==0 && records[3][37]==1);
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            self.radio_unit(Path(tmp), source)

    def test_repeated_last_slot_timeouts_keep_next_beacon_window_across_clock_wrap(self):
        for hz, nodes, node in ((100, 4, 4), (400, 2, 2)):
            with self.subTest(hz=hz), tempfile.TemporaryDirectory() as tmp:
                source = RADIO_TEST.split('int main(void) {')[0]
                for key, old, new in (('NODES', 1, nodes), ('NODE_ID', 1, node), ('RADIO_HZ', 100, hz)):
                    source = source.replace(f'#define CONFIG_IMU_{key} {old}', f'#define CONFIG_IMU_{key} {new}')
                source = source.replace('p->pipe==1', 'p->pipe==CONFIG_IMU_NODE_ID')
                source = source.replace('static uint64_t now;', 'static uint64_t now; static unsigned frame_number, inits;')
                source = source.replace('c->tx_output_power==8); return 0;',
                    'c->tx_output_power==8); ++inits; now+=1000; return 0;')
                source = source.replace('++calls;', '++calls; completion_kind=(frame_number%7==0 && '
                    'calls==imu_slot_count(CONFIG_IMU_RADIO_HZ))?0:ESB_EVENT_TX_SUCCESS;')
                source += r'''
int main(void) {
    reset_test(); tx_seq=UINT32_MAX-10;
    uint64_t origin=(uint64_t)UINT32_MAX-20000;
    for(frame_number=0;frame_number<500;++frame_number) {
        uint64_t frame=origin+frame_number*(uint64_t)IMU_FRAME_US;
        now=frame+1440; calls=published=0;
        struct imu_sync s={.locked=true,.frame=(uint32_t)frame,.hub_anchor=(uint32_t)frame,
            .local_anchor=(uint32_t)frame,.last_pair=(uint32_t)frame+1440,
            .beacon_rx=(uint32_t)frame+240,.uncertainty_us=16};
        uint32_t before=tx_seq; unsigned count=imu_slot_count(CONFIG_IMU_RADIO_HZ);
        node_frame(&s);
        assert(calls==count && published==2*count && tx_seq==before+count);
        assert(!missed && !losses && s.locked && prx && configured && !fatal_error);
        assert(errors==frame_number/7+1 && now<frame+IMU_FRAME_US);
    }
    assert(inits==1000); /* No redundant PTX re-init after the last slot fails. */
    return 0;
}
'''
                self.radio_unit(Path(tmp), source)

    def test_configuration_failure_retries_at_bounded_rate_and_keeps_session(self):
        source = '#include <setjmp.h>\nstatic jmp_buf finished; static unsigned inits;\n'
        source += RADIO_TEST.split('int main(void) {')[0]
        source = source.replace('c->tx_output_power==8); return 0;',
            'c->tx_output_power==8); if(++inits<=3) return -1; longjmp(finished,1); return 0;')
        source += r'''
int main(void) {
    reset_test(); configured=false; start_gate=1; hub_sequence=99;
    if(!setjmp(finished)) radio_thread(0,0,0);
    assert(inits==4 && now>=310000 && now<315000 && errors==3);
    assert(boot_session==42 && hub_sequence==99 && !fatal_error);
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            self.radio_unit(Path(tmp), source)

    def test_hub_beacon_identity_continues_after_configuration_failure(self):
        source = '#include <setjmp.h>\nstatic jmp_buf finished; static unsigned inits;\n'
        source += RADIO_TEST.split('int main(void) {')[0]
        source = source.replace('#define CONFIG_IMU_NODE_ID 1', '#define CONFIG_IMU_NODE_ID 0')
        source = source.replace('p->pipe==1 && !p->noack', 'p->pipe==0 && p->noack')
        source = source.replace('c->tx_output_power==8); return 0;',
            'c->tx_output_power==8); if(++inits==5) return -1; return 0;')
        source = source.replace('++calls;', '++calls; if(inits>=6 && p->data[1]==IMU_BEACON) { '
            'assert(imu_get32(p->data+8)==2); longjmp(finished,1); }')
        source += r'''
int main(void) {
    reset_test(); start_gate=1; hub_sequence=0;
    if(!setjmp(finished)) radio_thread(0,0,0);
    assert(inits==7 && errors==1 && hub_sequence==2 && boot_session==42);
    assert(now>180000 && !fatal_error);
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            self.radio_unit(Path(tmp), source)

    def test_noisy_sync_retains_only_a_bounded_fit_and_cannot_refresh_expiry(self):
        source = r'''
#define IMU_SYNC_TEST
#define main existing_sync_tests
#include "imu_sync.h"
#undef main
static void pair(struct imu_sync *s,uint32_t frame,uint32_t seq,int noise) {
    uint8_t p[IMU_MAX_LEN];
    imu_test_control(p,IMU_BEACON,7,seq,frame);
    assert(imu_sync_receive(s,p,32,frame+240+noise,2,400)==0);
    imu_test_control(p,IMU_FOLLOWUP,7,seq,frame);
    assert(imu_sync_receive(s,p,32,frame+1440+noise,2,400)==1);
}
int main(void) {
    existing_sync_tests();
    for(unsigned wrap=0;wrap<2;++wrap) {
        uint32_t start=wrap?0xfffe0000U:10000;
        struct imu_sync s={0};
        for(unsigned i=0;i<3;++i) pair(&s,start+i*IMU_FRAME_US,i,0);
        assert(s.locked && s.uncertainty_us==16);
        uint32_t last=s.last_pair, local=s.local_anchor, hub=s.hub_anchor;
        pair(&s,start+3*IMU_FRAME_US,3,9); /* 225 ppm observation: reject its fit. */
        assert(s.locked && s.uncertainty_us==48 && s.ppm==0);
        assert(s.last_pair==last && s.local_anchor==local && s.hub_anchor==hub);
        assert(imu_sync_current(&s,start+3*IMU_FRAME_US+38000));
        struct imu_sync expires=s, consecutive=s;
        assert(imu_sync_expire(&expires,last+IMU_SYNC_TIMEOUT_US) && !expires.locked);
        pair(&consecutive,start+4*IMU_FRAME_US,4,18);
        assert(!consecutive.locked); /* A second bad pair cannot sustain lock. */
        pair(&s,start+4*IMU_FRAME_US,4,0);
        assert(s.locked && s.uncertainty_us==16 && s.last_pair!=last);
        pair(&s,start+5*IMU_FRAME_US,5,100);
        assert(!s.locked); /* Large clock jumps never use the guard. */
    }
    /* An extreme discontinuity must not wrap a uint32 uncertainty back to 0. */
    struct imu_sync s={.session_valid=true,.session=7,.observed=true,.locked=true,
        .seq=2,.frame=90000,.hub_anchor=91000,.local_anchor=91000,
        .last_pair=91400,.uncertainty_us=16,.pairs=3};
    uint8_t p[IMU_MAX_LEN];
    uint32_t residual=(uint32_t)(((1ULL<<32)+20)*39000/79000);
    uint32_t receive=s.local_anchor+39000+residual;
    imu_test_control(p,IMU_BEACON,7,3,130000);
    assert(imu_sync_receive(&s,p,32,receive,2,400)==0);
    imu_test_control(p,IMU_FOLLOWUP,7,3,130000); imu_put32(p+16,130000);
    assert(imu_sync_receive(&s,p,32,receive+1200,2,400)==1 && !s.locked);
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            compile_run(source, Path(tmp))


if __name__ == '__main__':
    unittest.main()
