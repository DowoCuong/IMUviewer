cmake_minimum_required(VERSION 3.20.0)
find_package(Zephyr REQUIRED HINTS $ENV{ZEPHYR_BASE})
project(supermini_esb)
if(CONFIG_IMU_BNO_PROBE)
  target_sources(app PRIVATE ../src/imu_bno_probe.c)
elseif(CONFIG_IMU_APP)
  target_sources(app PRIVATE
    ../src/imu_main.c
    ../src/imu_sensor.c
    ../third_party/bno055/bno055.c
  )
  target_include_directories(app PRIVATE ../third_party/bno055)
  if(NOT CONFIG_IMU_USB_ONLY)
    target_sources(app PRIVATE ../src/imu_radio.c)
    include(${CMAKE_CURRENT_LIST_DIR}/../cmake/esb_timestamp.cmake) # Replace stock ESB sources with local timestamped build.
  endif()
else()
  target_sources(app PRIVATE ../src/main.c)
endif()
target_compile_definitions(app PRIVATE ESB_TEST_TRANSMITTER=1)
