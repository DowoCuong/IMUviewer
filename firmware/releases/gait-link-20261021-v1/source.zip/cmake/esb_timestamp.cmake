# Include after find_package(Zephyr). Keep CONFIG_ESB and its stock library;
# replace that library's sources rather than compiling a second ESB instance.
include_guard(GLOBAL)
if(NOT CONFIG_ESB)
  return()
endif()
if(NOT TARGET zephyr_interface)
  message(FATAL_ERROR "esb_timestamp.cmake must follow find_package(Zephyr)")
endif()
get_filename_component(_esb_local "${CMAKE_CURRENT_LIST_DIR}/../third_party/esb" ABSOLUTE)

# Inspect registered Zephyr libraries rather than assuming a target spelling.
get_property(_esb_libraries GLOBAL PROPERTY ZEPHYR_LIBS)
set(_esb_target "")
foreach(_candidate IN LISTS _esb_libraries)
  get_target_property(_dir "${_candidate}" SOURCE_DIR)
  if(_dir MATCHES "/subsys/esb$")
    if(_esb_target)
      message(FATAL_ERROR "Multiple stock ESB targets found")
    endif()
    set(_esb_target "${_candidate}")
  endif()
endforeach()
if(NOT _esb_target)
  message(FATAL_ERROR "Stock CONFIG_ESB library not found in ZEPHYR_LIBS")
endif()
if(NOT CONFIG_SOC_NRF52840 OR NOT CONFIG_HAS_HW_NRF_PPI OR CONFIG_ESB_MPSL_TIMESLOT)
  message(FATAL_ERROR "Local ESB timestamps support standalone nRF52840 PPI only")
endif()
set_property(TARGET "${_esb_target}" PROPERTY SOURCES
  "${_esb_local}/esb.c"
  "${_esb_local}/esb_workarounds.c"
  "${_esb_local}/esb_glue.c"
  "${_esb_local}/esb_ppi.c")
# The public payload ABI changed. Every Zephyr consumer, including app, must
# resolve <esb.h> to the same local copy before any SDK include directory.
target_include_directories(zephyr_interface BEFORE INTERFACE "${_esb_local}")
message(STATUS "ESB hardware timestamps: ${_esb_target} -> ${_esb_local}")
