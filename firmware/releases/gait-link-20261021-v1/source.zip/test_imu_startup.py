"""Execute actual sensor startup/calibration gating and radio start in native C.

Run: python test_imu_startup.py
Only Zephyr, Bosch calls, I2C and persistence are mocked. The real sensor_run,
initialize_sensor, calibration transaction, cache publication and metrics execute.
Time is virtual; longjmp bounds the worker without changing production sources.
All generated headers and executables stay in temporary directories. No devices.
"""
from pathlib import Path
import tempfile
import unittest

from test_imu_radio import ATOMIC, ESB, KERNEL, RADIO_TEST, ROOT, compile_run


SENSOR_KERNEL = KERNEL.replace(
    '#define K_SEM_DEFINE(n,a,b) static int n = a',
    '#define K_SEM_DEFINE(n,a,b) int n = a',
) + r'''
#define K_SECONDS(x) ((x)*1000000)
#define K_THREAD_STACK_DEFINE(n,s) char n[s]
#define K_THREAD_STACK_SIZEOF(n) sizeof(n)
struct k_spinlock { int unused; };
typedef int k_spinlock_key_t;
struct k_thread { int unused; };
static k_spinlock_key_t k_spin_lock(struct k_spinlock *l) { (void)l; return 0; }
static void k_spin_unlock(struct k_spinlock *l, k_spinlock_key_t k) { (void)l; (void)k; }
static bool k_is_in_isr(void) { return false; }
static struct k_thread *k_current_get(void) { return NULL; }
static void (*worker_entry)(void *, void *, void *);
static unsigned thread_creates;
static void k_thread_create(struct k_thread *t, char *s, size_t n,
    void (*entry)(void *, void *, void *), void *a, void *b, void *c,
    int priority, int options, int delay) {
    (void)t; (void)s; (void)n; (void)a; (void)b; (void)c;
    worker_entry = entry;
    ++thread_creates;
    (void)priority; (void)options; (void)delay;
}
static void k_thread_name_set(struct k_thread *t, const char *n) { (void)t; (void)n; }
'''

I2C = r'''
struct device { int unused; };
static const struct device fake_bus = {0};
#define DT_NODELABEL(x) 0
#define DEVICE_DT_GET(x) (&fake_bus)
static bool device_is_ready(const struct device *d) { return d == &fake_bus; }
int i2c_burst_read(const struct device *, uint16_t, uint8_t, uint8_t *, uint32_t);
int i2c_burst_write(const struct device *, uint16_t, uint8_t, const uint8_t *, uint32_t);
'''

SENSOR_TEST = r'''
#define CONFIG_IMU_SDA_PIN 11
#define CONFIG_IMU_SCL_PIN 12
#include "imu_sensor.c"
#include <assert.h>
#include <setjmp.h>
_Static_assert(SENSOR_IO_ENABLED == 1, "Must execute the real I2C sensor path");

enum scenario { LONG_WAIT, NEVER_READY, STATUS_FAULT, READ_FAULT, CONFIG_CHANGE };
static enum scenario scenario;
static jmp_buf finished;
static uint64_t now, first_poll, last_poll, released_at, first_completed;
static unsigned init_calls, polls, total_polls, quaternion_calls, releases;
static unsigned fault_sleeps, offset_reads;
static bool allowed, injected, posted;
static unsigned status_retries;
static uint8_t registers[2][256], page;
static struct bno055_t *driver;

uint64_t imu_clock_us(void) { return now; }
static bool measurement_started;
static unsigned radio_starts;
static const uint32_t session = 0x12345678;
void imu_radio_start(uint32_t value) {
    struct imu_sample s;
    struct imu_sensor_metrics m;
    imu_sensor_snapshot(&s, &m);
    assert(value == session && radio_starts == 0);
    assert(allowed && releases && m.reads && s.valid && s.state == IMU_READY);
    assert(s.calibration == 255 && now - s.completed_us <= 30000);
    assert(!m.paused && !m.last_error);
    ++radio_starts;
}
#define CONFIG_IMU_PIN_SCAN 0
#define IS_ENABLED(x) (x)
static void pump_main(void) {
    uint64_t now = imu_clock_us();
    /* MAIN_READINESS_BLOCK */
}
static void check_main(void) {
    pump_main();
    pump_main(); /* Repeated main iterations must not repeat the callback. */
    assert(radio_starts == (stats.reads ? 1U : 0U));
}
int imu_calibration_fetch(uint8_t payload[22]) { (void)payload; return -ENOENT; }
int imu_calibration_store(const uint8_t payload[22]) { (void)payload; return 0; }

static void new_gate(void) {
    allowed = false;
    polls = 0;
    first_poll = last_poll = released_at = 0;
}

int i2c_burst_read(const struct device *d, uint16_t address, uint8_t reg,
                   uint8_t *data, uint32_t length) {
    assert(d == sensor_bus && address == BNO055_I2C_ADDR2);
    if (page == 0 && ((reg == 0x36 && length == 9) || (reg == 0x08 && length == 6))) {
        memcpy(data, &registers[0][reg], length);
        return 0;
    }
    assert(length == 1);
    if (page == 0 && reg == 0x35) {
        if (status_retries) { --status_retries; *data = 255; return -EIO; }
        struct imu_sample s;
        struct imu_sensor_metrics m;
        imu_sensor_snapshot(&s, &m);
        assert(m.missed == 0);
        assert(s.state == IMU_CALIBRATING);
        if (polls) assert(now - last_poll == 500000ULL);
        else first_poll = now;
        last_poll = now;
        ++polls; ++total_polls;
        /* Even a failed read that leaves 255 in the buffer cannot release. */
        if (scenario == STATUS_FAULT && !injected && polls == 3) {
            injected = true;
            status_retries = 2;
            *data = 255;
            return -EIO;
        }
        if (scenario != NEVER_READY && now - first_poll >= 12000000ULL) {
            *data = 255;
            allowed = true;
            released_at = now;
            ++releases;
        } else {
            /* Includes partially calibrated combinations close to 255. */
            static const uint8_t partial[] = {0, 0x3f, 0xcf, 0xf3, 0xfc, 0xfe};
            *data = partial[(polls - 1) % sizeof(partial)];
            assert(!allowed);
            assert(m.reads == ((scenario == READ_FAULT || scenario == CONFIG_CHANGE)
                               && releases ? 1U : 0U));
            if (!m.reads) assert(!s.valid && s.seq == 0 && s.completed_us == 0);
            else assert(s.valid && s.seq == 1 && s.completed_us == first_completed);
        }
        return 0;
    }
    if (page == 0 && reg >= 0x55 && reg <= 0x6a) ++offset_reads;
    *data = reg == 0 ? 0xa0 : registers[page][reg];
    return 0;
}

int i2c_burst_write(const struct device *d, uint16_t address, uint8_t reg,
                    const uint8_t *data, uint32_t length) {
    assert(d == sensor_bus && address == BNO055_I2C_ADDR2 && length == 1);
    if (reg == 0x07) { assert(*data <= 1); page = *data; }
    registers[page][reg] = *data;
    if (page == 0 && reg == 0x3d && *data == 0) new_gate();
    if (page == 0 && reg == 0x3f && *data == 0x20) {
        memset(registers, 0, sizeof(registers));
        page = 0;
        new_gate();
    }
    return 0;
}

s8 bno055_init(struct bno055_t *b) {
    ++init_calls;
    driver = b;
    return b->bus_read(b->dev_addr, 0, &b->chip_id, 1);
}
s8 bno055_read_register(u8 reg, u8 *data, u8 length) {
    return driver->bus_read(driver->dev_addr, reg, data, length);
}
s8 bno055_write_register(u8 reg, u8 *data, u8 length) {
    return driver->bus_write(driver->dev_addr, reg, data, length);
}
s8 bno055_read_quaternion_wxyz(struct bno055_quaternion_t *q) {
    check_main(); /* 255 alone is insufficient before a valid quaternion. */
    /* This trips immediately if the gate is removed or given a timeout. */
    assert(allowed && released_at && now >= released_at);
    assert(now - first_poll >= 12000000ULL);
    assert(registers[0][0x3d] == 0x0c && page == 0);
    ++quaternion_calls;
    if (scenario == READ_FAULT && quaternion_calls >= 2 && quaternion_calls <= 4) {
        injected = true;
        return -1;
    }
    q->w = 16384; q->x = -123; q->y = 456; q->z = -789;
    now += 250; /* A real, nonzero acquisition duration. */
    return 0;
}

static void sleep_us(uint64_t us) {
    check_main();
    struct imu_sample s;
    struct imu_sensor_metrics m;
    imu_sensor_snapshot(&s, &m);
    assert(m.missed == 0); /* Initialization, calibration and retries are not slots. */
    if (s.state == IMU_SENSOR_FAULT) {
        assert(m.errors == 3 && m.last_error == -EIO);
        assert(!s.valid || (s.seq == 1 && s.completed_us == first_completed));
        if (us == 1000000) ++fault_sleeps; /* FAULT persists through reinit sleeps. */
    }
    if (m.reads) {
        assert(s.valid && s.seq == m.reads);
        assert(s.q[0] == 16384 && s.q[1] == -123 && s.q[2] == 456 && s.q[3] == -789);
        assert(m.duration_us == 250 && m.lateness_us == 0);
        if (!first_completed) {
            first_completed = s.completed_us;
            assert(s.state == IMU_READY && s.calibration == 255);
            assert(m.interval_us == 0);
        }
        unsigned target = scenario == READ_FAULT || scenario == CONFIG_CHANGE ? 2 : 1;
        if (m.reads == target) {
            assert(s.state == IMU_READY && s.calibration == 255 && m.last_error == 0);
            assert(s.completed_us == released_at + 250);
            longjmp(finished, 1);
        }
        if (scenario == CONFIG_CHANGE && !posted) {
            /* Post the worker mailbox directly, not a fake transaction result. */
            posted = true;
            calib.operation = CALIB_READ;
            calib.state = CALIB_PENDING;
        }
    } else {
        assert(!s.valid && s.seq == 0 && s.completed_us == 0);
    }
    now += us;
    if (scenario == NEVER_READY && first_poll && now - first_poll >= 15000000ULL) {
        assert(total_polls == 30 && quaternion_calls == 0 && releases == 0);
        assert(s.state == IMU_CALIBRATING && m.errors == 0);
        longjmp(finished, 1);
    }
    assert(now < 40000000ULL); /* Deterministic watchdog in addition to process timeout. */
}
void k_msleep(uint32_t ms) { sleep_us((uint64_t)ms * 1000); }
void k_usleep(uint32_t us) { sleep_us(us); }
void k_busy_wait(uint32_t us) { now += us; }

int main(void) {
    scenario = TEST_SCENARIO;
    struct imu_sample s;
    struct imu_sensor_metrics m;
    imu_sensor_snapshot(&s, &m);
    assert(s.state == IMU_INITIALIZING && !s.valid && !m.reads && !m.missed);
    check_main();
    imu_sensor_start();
    imu_sensor_start();
    assert(thread_creates == 1 && worker_entry != NULL);
    if (setjmp(finished) == 0) worker_entry(NULL, NULL, NULL);
    check_main();
    assert(radio_starts == (scenario == NEVER_READY ? 0U : 1U));
    imu_sensor_snapshot(&s, &m);
    assert(m.missed == 0 && !m.paused);
    assert(init_calls == ((scenario == STATUS_FAULT || scenario == READ_FAULT) ? 2U : 1U));
    assert(fault_sleeps == ((scenario == STATUS_FAULT || scenario == READ_FAULT) ? 1U : 0U));
    assert(m.errors == 3 * fault_sleeps);
    if (scenario == NEVER_READY) assert(!s.valid && m.reads == 0);
    else {
        assert(s.state == IMU_READY && s.valid && s.calibration == 255);
        assert(releases == ((scenario == READ_FAULT || scenario == CONFIG_CHANGE) ? 2U : 1U));
        assert(m.reads == releases && s.seq == releases);
        assert(quaternion_calls == m.reads + (scenario == READ_FAULT ? 3U : 0U));
        assert(total_polls >= 25 * releases);
    }
    if (scenario == CONFIG_CHANGE) {
        assert(posted && offset_reads == 22 && calib.state == CALIB_DONE);
        assert(calib.result == 0 && calib_done == 1);
        assert(m.interval_us > 12000000ULL);
    }
    return 0;
}
'''


class StartupTests(unittest.TestCase):
    def run_sensor(self, scenario):
        with tempfile.TemporaryDirectory() as directory:
            tmp = Path(directory)
            (tmp / 'zephyr/sys').mkdir(parents=True)
            (tmp / 'zephyr/drivers').mkdir()
            (tmp / 'zephyr/kernel.h').write_text(SENSOR_KERNEL)
            (tmp / 'zephyr/sys/atomic.h').write_text(ATOMIC)
            (tmp / 'zephyr/drivers/i2c.h').write_text(I2C)
            # Use Bosch's actual types/signatures; only function bodies are mocked.
            bosch = (ROOT / 'third_party/bno055/bno055.h').as_posix()
            (tmp / 'bno055.h').write_text(f'#include "{bosch}"\n')
            # Execute the production main readiness block verbatim, not all of
            # imu_main.c (USB/GPIO/NVS orchestration is outside this harness).
            main_source = (ROOT / 'src/imu_main.c').read_text()
            start = main_source.index('        if (!measurement_started &&')
            end = main_source.index('        if (!IS_ENABLED(CONFIG_IMU_PIN_SCAN) &&', start)
            readiness = main_source[start:end]
            source = SENSOR_TEST.replace('    /* MAIN_READINESS_BLOCK */', readiness)
            compile_run(f'#define TEST_SCENARIO {scenario}\n' + source, tmp)

    def test_twelve_second_calibration_blocks_reads_until_255(self):
        self.run_sensor('LONG_WAIT')

    def test_no_timeout_release_after_fifteen_seconds(self):
        self.run_sensor('NEVER_READY')

    def test_failed_status_read_of_255_retries_without_releasing(self):
        self.run_sensor('STATUS_FAULT')

    def test_quaternion_fault_reset_requires_fresh_calibration(self):
        self.run_sensor('READ_FAULT')

    def test_config_transaction_requires_fresh_calibration_preserves_sample(self):
        self.run_sensor('CONFIG_CHANGE')

    def test_actual_radio_start_signals_once_and_preserves_first_session(self):
        # Separate executable/translation unit avoids sensor/radio static name
        # collisions. Reuse only the radio harness, not a model of imu_radio_start.
        source = '#define main existing_radio_tests\n' + RADIO_TEST + r'''
#undef main
int main(void) {
    assert(started == 0 && start_gate == 0);
    assert(k_sem_take(&start_gate, K_NO_WAIT) != 0);
    imu_radio_start(0x12345678);
    assert(started == 1 && start_gate == 1 && boot_session == 0x12345678);
    imu_radio_start(99); /* Repeated before the worker consumes the signal. */
    assert(boot_session == 0x12345678);
    assert(k_sem_take(&start_gate, K_NO_WAIT) == 0);
    assert(start_gate == 0);
    imu_radio_start(0); /* Must not re-arm after consumption, either. */
    assert(start_gate == 0 && boot_session == 0x12345678);
    assert(k_sem_take(&start_gate, K_NO_WAIT) != 0);
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as directory:
            tmp = Path(directory)
            (tmp / 'zephyr/sys').mkdir(parents=True)
            (tmp / 'zephyr/kernel.h').write_text(KERNEL)
            (tmp / 'zephyr/sys/atomic.h').write_text(ATOMIC)
            (tmp / 'esb.h').write_text(ESB)
            compile_run(source, tmp)


if __name__ == '__main__':
    unittest.main(verbosity=2)
