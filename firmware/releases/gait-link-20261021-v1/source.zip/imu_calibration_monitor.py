"""Print transmitter USB calibration progress once per second; no command writes."""
import argparse
import time

from imu_capture import FrameDecoder, positive_finite, serial_factory

STATES = {0: 'INITIALIZING', 1: 'CALIBRATING', 2: 'READY', 3: 'SENSOR_FAULT'}
DIAGNOSTIC_FRESHNESS_S = 3.5
SAMPLE_FRESHNESS_S = 3.5
STATS_FRESHNESS_S = 3.5


def _levels(calibration):
    return ((calibration >> 6) & 3, (calibration >> 4) & 3,
            (calibration >> 2) & 3, calibration & 3)


def _levels_text(calibration):
    system, gyro, accel, mag = _levels(calibration)
    return f'sys = {system}         gy = {gyro}         mag = {mag}         acc = {accel}'


def _calibration_label(calibration):
    return 'FULL' if calibration == 0xff else 'PARTIAL'


def _freshness(row, age, limit, diagnostic=False):
    if row.get('paused'):
        return 'PAUSED'
    if row.get('stale') or age > limit:
        return 'STALE'
    if diagnostic:
        if not row.get('valid'):
            return 'INVALID'
    elif row['state'] in (0, 3):
        return STATES[row['state']]
    elif row.get('type', 2) == 1 and not row.get('valid'):
        return 'INVALID'
    return 'CURRENT'


def format_progress(row, age, stats=None, diagnostic=None, diagnostic_age=None,
                    stats_age=None):
    """Format one node using fresh diagnostic calibration before DATA/STATUS.

    ``age`` is host receive age for DATA/STATUS. ``diagnostic_age`` and
    ``stats_age`` are also host receive ages; none is a sensor timestamp.
    Keeping this policy here prevents the one-second display loop from
    accidentally reviving an old STATUS after diagnostic packets continue.
    """
    if row is None and diagnostic is None:
        return 'sys = ?         gy = ?         mag = ?         acc = ?    state = WAITING_FOR_TX_STATUS'
    node = (diagnostic if diagnostic is not None else row)['node']
    sample_source = 'DATA' if row is not None and row.get('type', 2) == 1 else 'STATUS'
    sample_warning = None
    if row is not None and age <= SAMPLE_FRESHNESS_S:
        if row.get('paused'):
            sample_warning = 'PAUSED'
        elif row['state'] in (0, 3):
            sample_warning = STATES[row['state']]
    if diagnostic is not None:
        source = 'DIAG'
        receive_age = diagnostic_age if diagnostic_age is not None else float('inf')
        quality = _freshness(diagnostic, receive_age, DIAGNOSTIC_FRESHNESS_S, True)
        # A newer state/pause warning invalidates an older FULL observation.
        if quality == 'CURRENT' and sample_warning and age <= receive_age:
            quality = sample_warning
        calibration = diagnostic['calib_raw']
    else:
        source, receive_age = sample_source, age
        quality = _freshness(row, age, SAMPLE_FRESHNESS_S)
        calibration = row['calibration']
    if quality == 'CURRENT':
        text = f'{_levels_text(calibration)}    calibration = {_calibration_label(calibration)}'
    else:
        text = 'sys = ?         gy = ?         mag = ?         acc = ?    calibration = UNKNOWN'
    text += f' source = {source} freshness = {quality} host_age = {receive_age:.1f}s'
    if row is not None and age <= SAMPLE_FRESHNESS_S and not row.get('stale'):
        text += (f"    firmware_state = {STATES.get(row['state'], 'UNKNOWN')}"
                 f' state_source = {sample_source} state_host_age = {age:.1f}s')
    else:
        text += '    firmware_state = UNKNOWN (DATA/STATUS stale or absent)'
        if row is not None:
            text += f" last_known_state = {STATES.get(row['state'], 'UNKNOWN')}"
    if sample_warning:
        text += f'    sample_warning = {sample_warning}'
    text += f'    node = {node}'
    if stats is not None and (stats_age is None or stats_age <= STATS_FRESHNESS_S):
        text += f"    i2c_errors = {stats['i2c_errors']}"
    elif stats is not None:
        text += '    i2c_errors = STALE'
    if row is not None and age > SAMPLE_FRESHNESS_S:
        text += f'    NO_RECENT_STATUS (last received {age:.1f}s ago)'
    return text


def format_sensor_diag(row, age=0):
    calibration = row.get('calib_raw', 0)
    quality = _freshness(row, age, DIAGNOSTIC_FRESHNESS_S, True)
    return (f"diag node = {row['node']} addr = 0x{row['i2c_address']:02x} "
            f"i2c = {row['i2c_khz']}kHz chip = 0x{row['chip_id']:02x} "
            f"diag = {'VALID' if quality == 'CURRENT' else quality} "
            f"host_age = {age:.1f}s "
            f"{'calib' if quality == 'CURRENT' else 'last_known_calib'} = 0x{calibration:02x} "
            f"values = {'CURRENT' if quality == 'CURRENT' else 'CACHED/UNCONFIRMED'} "
            f"acc_raw = ({row['accel_x_raw']}, {row['accel_y_raw']}, {row['accel_z_raw']}) "
            f"unit = 0x{row['unit_sel']:02x} sys_status = 0x{row['sys_status']:02x} "
            f"err = 0x{row['sys_error']:02x} st = 0x{row['st_result']:02x} "
            f"init = {row['init_count']} recovery = {row['recovery_count']} "
            f"reset_err = {row['reset_errors']} runtime_err = {row['runtime_errors']} "
            f"last_error_history = {row['last_error']} reg = 0x{row['last_error_reg']:02x} "
            f"nvs = {row['nvs_state']}")


def monitor(args, factory=None):
    factory = factory or serial_factory()
    decoder = FrameDecoder(args.nodes)
    samples, diagnostics, stats = {}, {}, {}
    diagnostic_sessions = {}
    started = time.monotonic()
    next_print = started + 1
    print(f'Opening TX USB {args.port}; no commands sent. Ctrl+C to stop.', flush=True)
    print('Levels range from 0 to 3; full calibration requires all four to be 3.', flush=True)
    print('host_age is time since PC receipt, not sensor sample age.', flush=True)
    try:
        with factory(args.port, 115200, timeout=.1, write_timeout=3) as port:
            port.dtr = True
            started = time.monotonic()
            next_print = started + 1
            while args.seconds is None or time.monotonic() - started < args.seconds:
                rows = decoder.feed(port.read(4096))
                now = time.monotonic()
                for row in rows:
                    if row['type'] in (1, 2, 9):
                        samples[row['node']] = (row, now)
                    elif row['type'] == 6:
                        stats[row['node']] = (row, now)
                    elif row['type'] == 7:
                        previous_session = diagnostic_sessions.get(row['node'])
                        if previous_session is not None and previous_session != row['session']:
                            # Diagnostic confirms a reboot. Query session cannot
                            # identify its boot: discard prior snapshots too.
                            # Conservative if a new-boot snapshot arrived first;
                            # the next snapshot/stats will repopulate the cache.
                            samples.pop(row['node'], None)
                            stats.pop(row['node'], None)
                        diagnostic_sessions[row['node']] = row['session']
                        diagnostics[row['node']] = (row, now)
                        print(format_sensor_diag(row, 0), flush=True)
                    elif row['type'] == 8:
                        print(f"command {row['command']} result = {row['command_result']} "
                              f"nvs = {row['command_nvs_state']} state = {STATES.get(row['command_sensor_state'], '?')}",
                              flush=True)
                if now >= next_print:
                    nodes = set(samples) | set(diagnostics)
                    if nodes:
                        for node in sorted(nodes):
                            sample_item = samples.get(node)
                            diag_item = diagnostics.get(node)
                            stats_item = stats.get(node)
                            sample_row, sample_received = sample_item if sample_item else (None, now)
                            diag_row, diag_received = diag_item if diag_item else (None, now)
                            stats_row, stats_received = stats_item if stats_item else (None, now)
                            print(format_progress(
                                sample_row, now - sample_received, stats_row,
                                diag_row, now - diag_received,
                                now - stats_received), flush=True)
                    else:
                        print(format_progress(None, 0), flush=True)
                    if 0 in stats and now - stats[0][1] <= STATS_FRESHNESS_S:
                        print('This port reports hub STATS (node 0). Use the transmitter USB port.', flush=True)
                    next_print = now + 1  # Do not burst-print missed intervals.
    except KeyboardInterrupt:
        print('\nCalibration monitor stopped.', flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', required=True, help='Transmitter application COM port, e.g. COM9')
    parser.add_argument('--nodes', type=int, choices=range(1, 5), default=4)
    parser.add_argument('--seconds', type=positive_finite, help='Optional monitoring duration; default until Ctrl+C')
    args = parser.parse_args(argv)
    try:
        monitor(args)
    except (OSError, ValueError, ImportError) as exc:
        print(f'Error: {exc}. Close other programs using this COM port.', flush=True)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
