# SuperMini ESB USB message test

## Current IMU gait upgrade (2026-10-21)

Đã đối chiếu với `esb8-20261012-v1` của Sleepify. Bản gait hiện chọn:

- ESB **2 Mbps, +8 dBm**, kênh **80 (2480 MHz)** và địa chỉ riêng cho gait.
- Bốn IMU, **100 Hz mỗi node**, tổng **400 gói dữ liệu/giây** theo lịch danh định.
  Profile 400 Hz cho tối đa hai node vẫn được kiểm tra bằng scheduler C mô phỏng;
  BNO055 vẫn chỉ được đọc 100 Hz, không coi gói lặp là mẫu fusion mới.
- Giữ HFXO suốt thời gian chạy để clock TIMER3 không phụ thuộc USB/đổi vai radio.
- Chỉ đổi PRX/PTX một lần mỗi frame; giữ deadline 700 µs và cổng slot 100 µs.
  Lỗi truyền riêng lẻ không xóa clock fit; lỗi cấu hình được thử lại sau 100 ms.
- Một cặp đồng bộ nhiễu chỉ được dùng clock fit cũ nếu tổng bất định dự báo đến
  cuối frame vẫn ≤50 µs. Giữ nguyên anchor và tuổi cặp tốt cuối; chuỗi lỗi không
  được kéo dài khóa đồng bộ. Có chặn bước nhảy lớn trước phép tính giới hạn.
- USB dùng FIFO interrupt thay cho gửi từng byte; giới hạn 100 ms không tiến
  triển. Dữ liệu bị gián đoạn được đếm, parser PC dùng CRC để bắt lại khung.
  Dòng lệnh quá dài hoặc mất byte bị bỏ đến dấu kết thúc, tránh lệnh hiệu chuẩn sai.

**Nạp đồng bộ hub và cả bốn node** bằng bộ UF2 mới; chúng đã đổi kênh/địa chỉ
so với bản cũ. App portable 2.1 vẫn dùng được, không cần cài lại.
Gói phát hành: `firmware/releases/gait-link-20261021-v1/`.
Đối chiếu/test/build: `evidence/link-upgrade-20261021/`.
Các kiểm tra trên PC chưa xác nhận RF, nguồn, COM hoặc RMSE trên board thật.

The current BNO055 application is selected by `build-imu.ps1` and `src/imu_*.c`.
The older USB-message/latency tests below are retained as historical workflows.

Four-node, 100 Hz profiles now cover one leg:

| Board | Configuration | Built image in `firmware/` |
| --- | --- | --- |
| Hub | `prx/gait100.conf` | `imu-hub-accuracy-gait100.uf2` |
| Pelvis, node 1 | `ptx/gait100-n1.conf` | `imu-tx-accuracy-gait100-n1.uf2` |
| Thigh, node 2 | `ptx/gait100-n2.conf` | `imu-tx-accuracy-gait100-n2.uf2` |
| Shank, node 3 | `ptx/gait100-n3.conf` | `imu-tx-accuracy-gait100-n3.uf2` |
| Foot, node 4 | `ptx/gait100-n4.conf` | `imu-tx-accuracy-gait100-n4.uf2` |

Update hub and nodes together. The 1 ms slot schedule supports four nodes at
100 Hz; a build assertion rejects more than two nodes at 400 Hz to prevent
overlapping slots. I2C pins/address retain the existing verified configuration
(SDA 17, SCL 20, address 0x29); adapt configuration to actual wiring if different.

```powershell
.\build-imu.ps1 -Role prx -Conf gait100.conf -Variant accuracy-gait100
.\build-imu.ps1 -Role ptx -Conf gait100-n1.conf -Variant accuracy-gait100-n1
python -m unittest discover -s . -p 'test_imu*.py' -q
```

Build node 2..4 with the corresponding configuration and variant name. Images
are built and UF2-validated, not flashed by these commands.

New `IMU_TIMED_DATA` type 9 is 64 bytes and preserves the type-1 sample fields
at offsets 0..39. Additional little-endian fields are local clock anchor u32
(40), hub anchor u32 (44), signed node/hub frequency difference in ppm (48),
clock-fit uncertainty u32 (52), hub boot/session u32 (56), I2C duration u32 (60).
Map local read completion onto hub time using:

```text
hub = unwrap(hub_anchor) + signed_delta(local_completed_low32, local_anchor)/(1 + ppm/1e6)
```

This is a software clock-fit estimate, not proof of microsecond hardware timing.
The timestamp still describes I2C read completion; BNO internal fusion epochs
and latency are not measured by this extension. Acquisition remains 100 Hz,
and retransmissions retain their read identity. Sensor fusion and calibration
policy are retained. `imu_capture.py`, `imu_plot.py`, and the calibration monitor
accept the new record type. The historical `IMU_READY/` snapshot is unchanged.

The matching desktop engine is in `D:\imu-web-min-main`; its raw export records
clock metadata, flags, source sequence and original quaternion values.

### Kiểm tra ngày 19/10/2026

Đã sửa đường xuất dữ liệu khi cảm biến lỗi/đọc chậm: I²C kéo dài quá 30 ms
được đánh dấu `STALE`. Nếu thời gian đọc vượt giới hạn hoặc mẫu cũ quá 120 ms,
node gửi bản ghi DATA loại 1 để giữ chẩn đoán, thay vì gói TIMED_DATA có metadata
bị bộ giải mã từ chối. Mẫu lỗi gần đây vẫn giữ bản đồ clock hợp lệ cùng cờ STALE
để ứng dụng ngắt chuỗi đo. Không thay timestamp cũ bằng thời gian gửi mới.

Đã bổ sung ba test chạy trực tiếp `imu_radio.c`: đọc chậm, lỗi với mẫu cũ,
lỗi với mẫu gần đây. Gói đo bình thường vẫn là loại 9. Các UF2 gait100 được
build lại và kiểm tra phân vùng; chưa nạp board hoặc đo sai số phần cứng.

## Flash
Use two SuperMini nRF52840 boards with the nice!nano S140 v6 UF2 bootloader.
Double-tap RST to GND, releasing between taps, to enter the bootloader.
Copy only one file to each board:
- A: firmware/transmitter-usb.uf2
- B: firmware/receiver-usb.uf2
The bootloader drive disappears when flashing finishes. The application should
then enumerate as USB serial. Existing transmitter.uf2/receiver.uf2 files are
the earlier LED test; they are intentionally retained as a fallback.

## Monitor
Connect each board by a USB data cable. Open each application's COM port in a
serial terminal at 115200 baud, 8N1, no flow control. Enable DTR if needed.
Only one program may open each port. Arduino Serial Monitor is also suitable
for viewing output; no Arduino upload or board selection is required.
The COM port may differ from the bootloader/CircuitPython port. Connect one
board at a time if necessary to identify its port. Both boards continue radio
operation with no terminal attached. Per-packet lines appear at about 10 Hz;
summaries appear every five seconds, including when the receiver is idle.

Illustrative output (not measured results):
```
TX session=12345678 seq=42 message=Hello ACK=yes attempts=1
RX session=12345678 seq=42 message=Hello rssi=-45 dBm
TX SUMMARY sent=100 acked=100 failed=0 ack_rate=100.0% write_errors=0
RX SUMMARY received=100 gaps=0 duplicates=0 sessions=1 queue_drops=0 invalid=0
```

## Tests
1. Nearby baseline: run for 60 seconds. Note the change in sent, acked, failed,
   received, and gaps between two summaries. An ideal bench result has no
   failures or gaps; actual RF conditions determine results.
2. Turn off receiver B for five seconds. TX should show ACK=NO and failures,
   then ACK=yes after reconnection. Receiver counters restart on power loss.
3. Turn off transmitter A for five seconds. RX summaries should continue but
   received should stop rising. A new session appears when A restarts; this
   prevents sequence reset from being counted as billions of missing packets.
4. Move one board farther away or behind a wall. Compare attempts, failures,
   gaps and RSSI. A more negative RSSI indicates a weaker received signal.
5. Close both monitors: LEDs and radio should continue. Reopen a monitor to
   see current totals; previously skipped USB lines are not replayed.

ACK failures are not identical to receiver packet losses: a packet can arrive
but its ACK can be lost. RX gaps count absent sequence numbers BETWEEN observed
packets within one transmitter session. They cannot detect initial/final missing
packets or packets missed while the receiver was powered off. A new session
establishes a new baseline. Queue drops are local application overruns and can
also create gaps, so check queue_drops before blaming the radio. Counters reset
on each board's reboot and otherwise accumulate across terminal reconnects.
These diagnostics do not measure one-way latency or maximum throughput.

## Firmware
13-byte packet: little-endian random boot/session ID (4 bytes), little-endian
sequence (4 bytes), ASCII Hello (5 bytes). The receiver validates the length
and text. 2 Mbps, channel 40 (2440 MHz), 0 dBm TX power, three retries after the
initial attempt, 600 microsecond retry delay. The send period is approximately
100 ms; USB output and radio activity can affect timing. No BLE is enabled.

The ESB callback only publishes results or queues received records. Formatting
and USB printing happen in the main thread. LEDs track successful TX/RX.
The test addresses are inherited from Nordic samples; use distinct addresses
for independent device pairs.

## Build and source
src/main.c contains the message format, callbacks, radio setup and both roles.
ptx/CMakeLists.txt and prx/CMakeLists.txt select the role at compile time.
Each prj.conf enables ESB clock startup and the board's USB CDC console.
Adapted from nRF Connect SDK v3.4.0 ESB samples under Nordic's sample license.

From PowerShell:
```
.\build.ps1
```
The script uses the installed SDK/toolchain paths, builds both roles outside
OneDrive, runs verify_uf2.py, and refreshes the two *-usb.uf2 files. SDK and
Toolchain parameters allow changing those installation paths. Logs are saved
as build-ptx.log and build-prx.log. The verification script checks UF2 structure,
nRF52840 family ID and flash bounds [0x26000, 0xEC000).

Both firmware images must be updated together for the new message format.
Build verification does not substitute for the two-board hardware tests above.

## Packet-and-ACK transaction latency
Flash firmware/transmitter-latency.uf2 to A. B can keep receiver-usb.uf2:
the over-air packet format is unchanged. transmitter-usb.uf2 also now contains
the timing feature. This is an acknowledged transaction measurement, NOT
one-way data latency, pure RF airtime, or IMU-to-PC end-to-end latency.

TIMER3 is a free-running 32-bit 1 MHz hardware counter (prescaler 4), independent
of ESB's TIMER2. It continues during CPU sleep. The start timestamp is taken
immediately before esb_write_payload, the end timestamp in the TX success/fail
callback, before waking the application and printing. The interval includes
software submission, radio startup, packet transmission, receiver ACK turnaround,
ACK reception, retries, and interrupt/callback dispatch. Timer resolution is
1 microsecond, not a guarantee of 1 microsecond measurement accuracy. USB
printing is outside the timestamp interval, though USB interrupts can affect
callback scheduling. Failed transactions report completion time, not delivered
packet latency. Do not divide the interval by two to claim one-way latency.

Each TX record now appends transaction_us. Every five seconds TX LATENCY shows
cumulative successful-transaction min/mean/max, including successful retries.
No time-of-arrival comparison between PC serial windows is needed.

For a reproducible capture, close Arduino/VS Code monitors on the TX port and
run the following from this folder (replace COM9 with the application's TX port):

```powershell
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\capture_latency.py --port COM9 --seconds 120 --out nearby.csv
```

The bundled Python includes pyserial. Do not reset the board into bootloader
mode for capture. Opening the port normally does not reset this firmware.
The script asserts DTR, captures only new TX records, saves CSV, and prints
sample counts, mean, median, nearest-rank p95/p99, min/max and observed ACK
failure rate. It separates successful first-attempt, successful retried and
failed transactions. An existing output file is never overwritten. Use a new
filename for each run. Ctrl+C keeps and summarizes the samples already captured.

Repeat at fixed distance with a wall, then at greater distance. Keep bitrate,
payload length, TX power and retry settings unchanged between comparisons.
A 120-second run at 10 Hz provides approximately 1200 samples; larger runs make
tail percentiles more stable. Report sample counts with percentiles. Capture
sequence gaps flag missing serial records; statistics then describe the captured
subset, and are not guaranteed to represent every radio attempt.

For actual one-way application delivery timing, use a shared logic analyzer:
record a GPIO marker just before submission on A and a GPIO marker in B's RX
callback on another channel, with a common ground. This requires an additional
GPIO instrumentation build. A sensor-to-PC test also needs explicitly chosen
sensor acquisition and host-processing endpoints; this test excludes both.

Self-test for the capture parser and percentile calculations:
```powershell
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\capture_latency.py --self-test
```

## 400 Hz radio-load variant
Build with .\build.ps1 -HighRate. Flash transmitter-400hz.uf2 to A and
receiver-400hz.uf2 to B. The packet stays 13 bytes, 2 Mbps, channel 40, 0 dBm,
with ACK and up to three retries retained. Both images disable per-packet
printing but retain five-second summaries. The receiver firmware update removes
its printing bottleneck; it is not required for packet-format compatibility.

The transmitter uses CONFIG_ESB_TEST_PERIOD_US=2500 and absolute Zephyr wakeup
deadlines. CONFIG_ESB_TEST_PACKET_LOG=n disables packet text on both devices.
Expired slots are skipped rather than sent in a burst; cumulative skipped_slots
and windowed actual_hz are reported. Scheduling uses the RTC-backed kernel
clock (~30.5 us tick resolution), so this is nominal 400 Hz, not a precision
2.500 ms hardware-triggered stream. USB summary printing and interrupts can
cause additional jitter or missed slots. TX timing still uses 1 MHz TIMER3.
The user LED stays near a one-second blink period rather than flashing at 40 Hz.

Every five seconds, check:
- TX RATE actual_hz: target is about 400, not simply an assumed rate.
- RX RATE actual_hz: should closely follow TX when the link is healthy.
- TX SUMMARY failed and RX SUMMARY gaps/queue_drops: examine increases.
- TX RATE skipped_slots: scheduler misses, separate from failed radio packets.
- TX LATENCY: cumulative successful transaction min/mean/max.
Counters survive serial reconnects, but reset when their board restarts.
Approximately 2000 packets per five-second window is the target.

capture_latency.py supports both per-packet and summary-only firmware. With
400 Hz firmware it saves TX SUMMARY, TX RATE and TX LATENCY rows (or RX rows
when connected to the receiver). It reports the latest cumulative successful
transaction min/mean/max, rates and counters. Median/p95/p99 require per-packet
records and cannot be reconstructed from these summaries.

The radio clock initialization, CRC, ACK and retries stay enabled. BLE and
Zephyr logging were already disabled. Packet data is already compact binary
(session and sequence), with five Hello bytes. For actual IMU packets use a
compact binary quaternion and sequence/timestamp rather than JSON text.
Reducing retries can bound waiting time but increases final packet failures;
disabling ACK removes delivery confirmation. Neither change is necessary just
to try 400 Hz. Fast radio ramp-up can be evaluated separately on both devices
with matching ESB timing, keeping comparisons independent of send-rate changes.

BNO055 fused output is 100 Hz in IMU and NDOF modes (Bosch datasheet table 3-14).
A 400 Hz packet rate does not create 400 fresh quaternion samples per second.
https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bno055-ds000.pdf


## Capture the 400 Hz summaries (no firmware update needed)
Close other serial monitors on the selected port, then:
```powershell
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\capture_latency.py --port COM9 --seconds 120 --out latency400.csv
```
Use the actual transmitter application COM port. To record the receiver too,
run a separate terminal using --port COM6 --out receiver400.csv (adjust COM6).
CSV uses one row per record, with record identifying TX PACKET, TX SUMMARY,
TX RATE, TX LATENCY, RX SUMMARY or RX RATE. Columns not applicable are blank.
The pc_elapsed_s column is the PC collection time, not a radio timestamp.

Firmware latency summaries are cumulative since board boot, including time
before this script starts. Do not average cumulative means across rows or claim
capture-only percentiles. Counter resets indicate a restart; use the saved
rows to examine each run separately. Separate TX and RX PC arrival timestamps
must not be subtracted to estimate one-way RF latency. The original 10 Hz
firmware still produces per-packet records and full percentile reports.

## Full per-transaction 400 Hz benchmark (median/p95/p96/p99)
This is the recommended mode for a full distribution at 400 Hz. Flash
firmware/transmitter-benchmark400.uf2 to A. Keep firmware/receiver-400hz.uf2 on B.
The transmitter waits for the script's command, so idle LEDs and no continuous
packet output before a command are expected. No CircuitPython is involved.

Close serial monitors on the transmitter port. Keep both boards powered. Run:
```powershell
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\capture_latency.py --benchmark --port COM9 --seconds 120 --out benchmark400.csv
```
Adjust COM9 to the transmitter application port. Start with --seconds 5 for
a short hardware check if desired. Supported durations: integer 1..120 seconds.
Each invocation starts a new independent measurement; reflash/reset is not
needed between completed tests. Change --out for every run. A completed test
returns the transmitter to the command-waiting state.

During the timed run the transmitter saves EVERY completed transaction in RAM,
including failures and attempt counts. It emits no per-packet or summary USB
text and does not update its LED inside the timed loop. Afterward it exports
all records in a compact binary transfer. The script waits for completion,
validates the record count, ACK count, scheduled-slot accounting, CRC32 and end
marker, then saves individual records to CSV and metadata/statistics to
benchmark400.metadata.json. Partial/corrupt transfers are rejected without
presenting them as valid latency statistics. Keep the cable connected until
export finishes. If interrupted or disconnected, allow the run/export to
finish; if USB export remains blocked, reset the transmitter before retrying.

Report contents:
- Exact per-run success/failure counts and ACK success rate.
- Latency min, mean, median, p95, p96, p99 and max for successful transactions.
- Separate distributions for first-attempt successes, retried successes, and
  failure completion times (failures are excluded from successful latency).
- Actual sent packets/second, skipped scheduler slots and local write errors.
The rate target is 400 Hz; timing is still RTC-scheduled with roughly 30.5 us
resolution. The measured transaction timestamps use the 1 MHz hardware timer.
These measurements are submission-to-ACK callback times, not one-way RF or
IMU-to-PC latency. USB interrupts may still occur; USB printing/export is moved
outside the timed run, not every source of system overhead.

Maximum buffer: 48000 x 4 bytes = 192000 bytes. Each little-endian record packs
microseconds in bits 0..23, attempts in bits 24..27 and ACK in bit 31. The
record index is the packet sequence. Firmware refuses out-of-range values.
The buffer does not wrap or sample a subset. Write failures and expired slots
are accounted separately; they can reduce completed transactions below 48000.
The build uses approximately 211 KB of the board's 256 KB RAM.

Build: .\build.ps1 -Benchmark (only the transmitter needs this variant).
Checks:
```powershell
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\capture_latency.py --self-test
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\test_benchmark_capture.py
```
The second test simulates the serial command and fragmented binary download,
then verifies CSV, metadata, failure separation and overwrite protection.
Hardware timing and USB enumeration must still be verified on the two boards.

### Benchmark USB command receive fix
The transmitter now explicitly registers a UART RX callback and calls
uart_irq_rx_enable() before announcing READY. In NCS v3.4.0 USB CDC ACM,
poll_in alone does not arm the USB OUT endpoint; the initial benchmark build
could print READY while PC writes timed out. The callback drains incoming bytes
to a bounded command queue and the main thread parses them. Reflash the rebuilt
transmitter-benchmark400.uf2; the receiver and capture command are unchanged.
Check first with --benchmark --seconds 5 and a new output filename. BENCH START
confirms command receipt. Full binary export still checks CRC32 and counts.
