"""Hardware-free IMU protocol, serial lifecycle, statistics and CSV/plot tests.

Run with C:/ncs/toolchains/dcbdc366a1/opt/bin/python.exe test_imu_capture.py
No real serial ports are opened; temporary output artifacts are removed.
"""
import contextlib
import csv
import io
import json
from pathlib import Path
import random
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zlib

import imu_capture as capture
import imu_plot


def payload(kind=1, node=1, session=123, tx=0, read=0, **kw):
    raw = bytearray(capture.LENGTHS[kind])
    flags = kw.get('flags', 1 if kind == 1 else 0)
    struct.pack_into('<BBBBIII', raw, 0, 1, kind, node, flags, session, tx, read)
    if kind in (1, 2):
        struct.pack_into('<Q4hBB2xI', raw, 16, kw.get('completed', 100000),
                         *kw.get('q', (16384, -2, 3, -4)), kw.get('calibration', 255),
                         kw.get('state', 2), kw.get('age', 1234))
    elif kind in (3, 4):
        struct.pack_into('<IIIBB2x', raw, 16, 0xabcdef01, 77, 40000, 2, kw.get('rate', 1))
    elif kind == 5:
        struct.pack_into('<5IBB2x', raw, 16, kw.get('transaction', 444), kw.get('start', 1000),
                         kw.get('interval', 10000), kw.get('duration', 200), kw.get('late', 4),
                         kw.get('attempts', 1), kw.get('ack', 1))
    else:
        struct.pack_into('<12I', raw, 16, *kw.get('counters', range(12)))
    return bytes(raw)


def frame(raw, event=0):
    # Independent wire encoder: do not simply use the implementation under test.
    body = len(raw).to_bytes(2, 'little') + event.to_bytes(4, 'little') + raw
    return b'IMU1' + body + (zlib.crc32(body) & 0xffffffff).to_bytes(4, 'little')


def summary(rows, elapsed=1):
    result = capture.CaptureSummary()
    for raw in rows:
        result.add(capture.decode_payload(raw))
    return result.report(elapsed)['groups']


class Clock:
    def __init__(self):
        self.now = 0

    def __call__(self):
        return self.now


class MockPort:
    def __init__(self, clock, stream=b'', fragment=7, interrupt=False, failure=None):
        self.clock, self.buffer = clock, bytearray(stream)
        self.fragment, self.interrupt, self.failure = fragment, interrupt, failure
        self.closed, self.dtr, self.writes = False, False, []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.closed = True

    def read(self, size):
        if not self.dtr:
            raise AssertionError('DTR was not asserted')
        self.clock.now += .01 if self.buffer else .25
        if not self.buffer and self.interrupt:
            raise KeyboardInterrupt
        if not self.buffer and self.failure:
            raise self.failure
        size = min(size, self.fragment, len(self.buffer))
        result = bytes(self.buffer[:size])
        del self.buffer[:size]
        return result

    def write(self, data):
        if not self.dtr:
            raise AssertionError('DTR was not asserted')
        self.writes.append(data)
        return len(data)

    def flush(self):
        raise AssertionError('Unbounded serial flush must never be called')

    def reset_input_buffer(self):
        raise AssertionError('Capture must not discard startup records')

    def factory(self, port, baud, **kwargs):
        if (port, baud, kwargs) != ('TEST', 115200, dict(timeout=.25, write_timeout=3)):
            raise AssertionError('Serial timeouts/configuration changed')
        return self


class ScheduledPort(MockPort):
    """Deliver whole frames at mock wall times, with a guard against endless test loops."""
    def __init__(self, clock, events, interrupt_at=None, stop_after=70):
        super().__init__(clock)
        self.events = list(events)
        self.interrupt_at, self.stop_after = interrupt_at, stop_after

    def read(self, size):
        if not self.dtr:
            raise AssertionError('DTR was not asserted')
        self.clock.now += .25
        if self.clock.now > self.stop_after:
            raise AssertionError('Capture did not stop at its measurement deadline')
        if self.interrupt_at is not None and self.clock.now >= self.interrupt_at:
            raise KeyboardInterrupt
        chunks = []
        while self.events and self.events[0][0] <= self.clock.now:
            chunks.append(self.events.pop(0)[1])
        return b''.join(chunks)


class ProtocolTests(unittest.TestCase):
    def test_all_layouts_and_endianness(self):
        row = capture.decode_payload(payload(tx=0x11223344, read=0xaabbccdd,
                                             completed=0x123456789abcdef0, flags=15))
        self.assertEqual(row['tx_seq'], 0x11223344)
        self.assertEqual(row['read_seq'], 0xaabbccdd)
        self.assertEqual(row['completed_us'], 0x123456789abcdef0)
        self.assertEqual([row[k] for k in ('qw', 'qx', 'qy', 'qz')], [16384, -2, 3, -4])
        self.assertEqual([row[k] for k in ('valid', 'synced', 'stale', 'paused')], [1] * 4)
        self.assertEqual(row['calibration'], 255)
        self.assertEqual(row['beacon_age_us'], 1234)
        self.assertEqual(capture.decode_payload(payload(2))['record'], 'status')
        for kind in (3, 4):
            row = capture.decode_payload(payload(kind, node=0))
            self.assertEqual(row['beacon_event_us_low32'], 0xabcdef01)
            self.assertEqual((row['hub_frame'], row['period_us'], row['nodes'], row['rate_hz']), (77, 40000, 2, 400))
            self.assertEqual(capture.decode_payload(payload(kind, node=0, rate=0))['rate_hz'], 100)
            with self.assertRaises(ValueError):
                capture.decode_payload(payload(kind, node=0, rate=4))
            with self.assertRaises(ValueError):
                capture.decode_payload(payload(kind, node=0, read=1))
        row = capture.decode_payload(payload(5, transaction=123, start=0xfffffffe, attempts=255, ack=0))
        self.assertEqual((row['transaction_us'], row['tx_start_us_low32'], row['attempts'], row['ack']),
                         (123, 0xfffffffe, 255, 0))
        row = capture.decode_payload(payload(6, node=0))
        self.assertEqual([row[k] for k in capture.COUNTERS], list(range(12)))

    def test_malformed_schema(self):
        mutations = [(1, 0, 2), (1, 1, 99), (1, 2, 0), (1, 2, 5), (1, 3, 16),
                     (1, 3, 0), (2, 3, 1), (1, 33, 4), (1, 34, 1), (1, 35, 1),
                     (3, 2, 1), (3, 3, 1), (3, 28, 0), (3, 28, 5), (3, 29, 2),
                     (3, 30, 1), (4, 31, 1), (5, 2, 0), (5, 37, 2), (5, 38, 1), (5, 39, 1)]
        for kind, offset, value in mutations:
            with self.subTest(kind=kind, offset=offset, value=value):
                raw = bytearray(payload(kind, node=0 if kind in (3, 4) else 1))
                raw[offset] = value
                with self.assertRaises(ValueError):
                    capture.decode_payload(raw)
        for raw in (b'', payload()[:15], payload()[:-1], payload() + b'\0'):
            with self.assertRaises(ValueError):
                capture.decode_payload(raw)
        with self.assertRaises(ValueError):
            capture.decode_payload(payload(node=2), nodes=1)

    def test_every_split_and_bytewise(self):
        wire = frame(payload(), 0xf1234567)
        self.assertEqual(wire, capture.encode_frame(payload(), 0xf1234567))
        for split in range(len(wire) + 1):
            decoder = capture.FrameDecoder()
            rows = decoder.feed(wire[:split]) + decoder.feed(wire[split:]) + decoder.finish()
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]['event_us_low32'], 0xf1234567)
        decoder = capture.FrameDecoder()
        rows = [row for byte in wire for row in decoder.feed(bytes([byte]))]
        self.assertEqual(len(rows), 1)
        self.assertFalse(decoder.buffer)

    def test_crc_coverage_and_resync(self):
        original = frame(payload())
        for offset in range(4, len(original)):
            with self.subTest(offset=offset):
                bad = bytearray(original)
                bad[offset] ^= 0x40
                decoder = capture.FrameDecoder()
                rows = decoder.feed(b'junkIM' + bad + original) + decoder.finish()
                self.assertEqual(len(rows), 1)
                self.assertGreater(decoder.counts['discarded_bytes'], 0)

    def test_invalid_lengths_malformed_payload_and_truncated_tail(self):
        decoder = capture.FrameDecoder()
        bad = bytearray(payload())
        bad[34] = 1
        wire = b'IMU1\xff\xff' + b'\0' * 4 + frame(bad) + frame(payload()) + b'IMU1\x28'
        rows = decoder.feed(wire) + decoder.finish()
        self.assertEqual(len(rows), 1)
        self.assertEqual(decoder.counts['invalid_lengths'], 1)
        self.assertEqual(decoder.counts['malformed_payloads'], 1)
        self.assertEqual(decoder.counts['pending_bytes_at_end'], 5)
        self.assertEqual(decoder.counts['truncated_candidates'], 1)

    def test_partial_magic_tail_metrics(self):
        for tail in (b'I', b'IM', b'IMU'):
            decoder = capture.FrameDecoder()
            self.assertEqual(len(decoder.feed(frame(payload()) + tail)), 1)
            self.assertEqual(decoder.finish(), [])
            self.assertEqual(decoder.counts['pending_bytes_at_end'], len(tail))
            self.assertEqual(decoder.counts['truncated_candidates'], 1)
            self.assertEqual(decoder.counts['discarded_bytes'], len(tail))

    def test_eof_false_length_does_not_hide_valid_frame(self):
        decoder = capture.FrameDecoder()
        wire = b'IMU1' + struct.pack('<HI', 64, 0) + frame(payload())
        self.assertEqual(decoder.feed(wire), [])
        self.assertEqual(len(decoder.finish()), 1)

    def test_magic_inside_payload_is_not_a_frame_boundary(self):
        raw = bytearray(payload())
        raw[24:28] = b'IMU1'
        decoder = capture.FrameDecoder()
        self.assertEqual(len(decoder.feed(frame(raw))), 1)

    def test_random_chunks_bounded_retained_buffer(self):
        rng = random.Random(42)
        stream = b''.join(frame(payload(tx=n), n) for n in range(100))
        decoder = capture.FrameDecoder()
        rows = []
        while stream:
            size = rng.randint(1, 180)
            rows.extend(decoder.feed(stream[:size]))
            stream = stream[size:]
            self.assertLess(len(decoder.buffer), 78)
        rows += decoder.finish()
        self.assertEqual([r['tx_seq'] for r in rows], list(range(100)))
        decoder.feed(b'x' * 100000 + b'IMU')
        self.assertEqual(decoder.buffer, b'IMU')


class StatisticsTests(unittest.TestCase):
    def test_exact_distributions(self):
        self.assertEqual(capture.distribution(range(1, 101)),
                         dict(count=100, min=1, mean=50.5, median=50.5, p95=95, p96=96, p99=99, max=100))
        self.assertEqual(capture.distribution([])['count'], 0)
        self.assertIsNone(capture.distribution([])['p99'])
        self.assertEqual(capture.distribution([9])['median'], 9)
        self.assertEqual(capture.distribution([1, 9])['median'], 5)

    def test_success_failure_attempts_duplicates_and_gaps(self):
        rows = [payload(5, tx=1, transaction=100, attempts=1),
                payload(5, tx=2, transaction=200, attempts=2, start=3500),
                payload(5, tx=4, transaction=900, attempts=4, ack=0, start=8500),
                payload(5, tx=2, transaction=200, attempts=2, start=3500)]
        group = summary(rows, 2)[0]
        self.assertEqual((group['captured_transactions'], group['successes'], group['failures']), (3, 2, 1))
        self.assertAlmostEqual(group['success_percent'], 200 / 3)
        self.assertEqual(group['transaction_us']['success']['max'], 200)
        self.assertEqual(group['transaction_us']['failure']['min'], 900)
        self.assertEqual(group['transaction_us']['first_attempt_success']['count'], 1)
        self.assertEqual(group['transaction_us']['retried_success']['count'], 1)
        self.assertEqual(group['attempts']['all']['histogram'], {1: 1, 2: 1, 4: 1})
        self.assertEqual(group['diagnostic_sequences']['missing_between_endpoints'], 1)
        self.assertEqual(group['diagnostic_sequences']['duplicates'], 1)
        self.assertEqual(group['records_per_pc_capture_second']['diag'], 2)
        self.assertAlmostEqual(group['diagnostic_tx_cadence']['observed_hz'], 2e6 / 7500)

    def test_unknown_transaction_time_is_not_latency(self):
        group = summary([payload(5, tx=1, transaction=capture.MASK32, attempts=0, ack=0),
                         payload(5, tx=2, transaction=600, attempts=1, ack=0),
                         payload(5, tx=3, transaction=400)])[0]
        self.assertEqual(group['captured_transactions'], 3)
        self.assertEqual(group['failures'], 2)
        self.assertEqual(group['unknown_transaction_durations'], 1)
        self.assertEqual(group['zero_attempt_diagnostics'], 1)
        self.assertEqual(group['transaction_us']['failure']['count'], 1)
        self.assertEqual(group['transaction_us']['failure']['max'], 600)
        group = summary([payload(5, transaction=capture.MASK32, attempts=0, ack=0)])[0]
        self.assertIsNone(group['transaction_us']['failure']['mean'])

    def test_cached_vs_distinct_reads_use_sequence_not_quaternion(self):
        rows = [payload(tx=1, read=50, completed=10000),
                payload(tx=2, read=50, completed=10000),
                payload(tx=3, read=51, completed=20000),  # Identical quaternion, new read.
                payload(2, tx=4, read=52, completed=30000),
                payload(tx=5, read=53, completed=40000, flags=15)]
        group = summary(rows)[0]
        self.assertEqual(group['cached_valid_records'], 1)
        self.assertEqual(group['valid_read_sequences']['distinct'], 3)
        self.assertEqual(group['invalid_status_records'], 1)
        self.assertEqual(group['flags']['stale'], 1)
        self.assertEqual(group['valid_read_sequences']['missing_between_endpoints'], 1)
        self.assertAlmostEqual(group['distinct_read_cadence']['observed_hz'], 2e6 / 30000)

    def test_wrap_late_arrival_and_reboot_sessions(self):
        tracker = capture.SequenceTracker()
        for seq in (0xfffffffe, 0, 0xffffffff, 1, 0xffffffff):
            tracker.add(seq)
        self.assertEqual(tracker.summary(), dict(distinct=4, duplicates=1, out_of_order=1, missing_between_endpoints=0))
        groups = summary([payload(tx=0xffffffff, read=0xffffffff, completed=2**32),
                          payload(tx=0, read=0, completed=2**32 + 10000),
                          payload(session=456, tx=0, read=0, completed=10000),
                          payload(node=2, session=123, tx=0, read=0)])
        self.assertEqual(len(groups), 3)
        self.assertEqual(groups[0]['sample_tx_sequences']['missing_between_endpoints'], 0)
        self.assertEqual(groups[0]['distinct_read_cadence']['observed_hz'], 100)
        self.assertEqual(groups[1]['valid_read_sequences']['distinct'], 1)

    def test_timer_wrap_and_discontinuity(self):
        group = summary([payload(5, tx=0xffffffff, start=0xfffffff0),
                         payload(5, tx=0, start=0x10)])[0]
        self.assertEqual(group['diagnostic_tx_cadence']['observed_interval_us']['min'], 32)
        self.assertEqual(group['diagnostic_tx_cadence']['observed_hz'], 31250)
        group = summary([payload(5, tx=1, start=1000), payload(5, tx=2, start=500)])[0]
        self.assertIsNone(group['diagnostic_tx_cadence']['observed_hz'])
        self.assertEqual(group['diagnostic_tx_cadence']['discontinuities'], 1)

    def test_counter_wrap_delta_coverage_and_reset(self):
        first = [0xfffffffe] * 11 + [0xffffff00]
        second = [1] * 11 + [744]
        group = summary([payload(6, counters=first), payload(6, counters=second)])[0]
        stats = group['counters']
        self.assertEqual(stats['covered_duration_ms'], 1000)
        self.assertEqual(stats['deltas']['usb_drops'], 3)
        self.assertEqual(stats['per_second']['reads'], 3)
        rows = [payload(6, counters=[100] * 11 + [1000]), payload(6, counters=[1] * 11 + [20])]
        self.assertEqual(summary(rows)[0]['counters']['discontinuities'], 1)
        self.assertEqual(summary(rows)[0]['counters']['accepted_intervals'], 0)
        self.assertIsNone(summary(rows[:1])[0]['counters']['per_second']['reads'])

    def test_conflicting_identity_is_flagged(self):
        group = summary([payload(read=1), payload(tx=1, read=1, q=(1, 2, 3, 4)),
                         payload(5), payload(5, transaction=999)])[0]
        self.assertEqual(group['conflicting_read_identities'], 1)
        self.assertEqual(group['conflicting_diagnostic_identities'], 1)

    def test_hub_data_cannot_infer_ack_or_latency(self):
        group = summary([payload()])[0]
        self.assertEqual(group['captured_transactions'], 0)
        self.assertIsNone(group['success_percent'])
        self.assertEqual(group['transaction_us']['success']['count'], 0)


class SerialAndArtifactTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.out = Path(self.temp.name) / 'run.csv'
        self.clock = Clock()
        self.args = SimpleNamespace(port='TEST', nodes=4, source='node', seconds=3,
                                    startup_timeout=1, out=self.out, command='query')
        self.log = io.StringIO()

    def run_capture(self, port):
        with patch.object(capture.time, 'monotonic', self.clock), contextlib.redirect_stdout(self.log):
            return capture.capture(self.args, port.factory)

    def metadata(self):
        return json.loads(self.out.with_suffix('.metadata.json').read_text(encoding='utf-8'))

    def test_mock_usb_csv_metadata_end_to_end(self):
        stream = b'junk' + frame(payload(read=10)) + frame(payload(tx=1, read=10))
        stream += frame(payload(tx=2, read=11, completed=110000))
        stream += frame(payload(5, tx=0, transaction=100))
        stream += frame(payload(5, tx=1, transaction=900, ack=0, attempts=4, start=3500))
        stream += frame(payload(6, counters=[0] * 12))
        stream += frame(payload(6, counters=[2] * 11 + [1000]))
        stream += b'IMU1\x28'
        port = MockPort(self.clock, stream)
        metadata = self.run_capture(port)
        with self.out.open(newline='') as file:
            rows = list(csv.DictReader(file))
        self.assertEqual(len(rows), 7)
        self.assertEqual(rows[0]['qw'], '16384')
        self.assertEqual(rows[0]['source'], 'node')
        self.assertEqual(rows[4]['ack'], '0')
        self.assertEqual(json.loads(json.dumps(metadata)), self.metadata())
        self.assertEqual(metadata['status'], 'completed')
        self.assertIsNotNone(metadata['measurement_started_utc'])
        self.assertAlmostEqual(metadata['calibration_wait_s'], .09)
        self.assertGreaterEqual(metadata['measurement_duration_s'], 3)
        self.assertLess(metadata['measurement_duration_s'], 3.25)
        self.assertEqual(metadata['phase_record_counts'], dict(waiting=0, recording=7))
        self.assertEqual(metadata['measurement_summary']['pc_capture_duration_s'],
                         metadata['measurement_duration_s'])
        group = metadata['summary']['groups'][0]
        self.assertEqual(group['success_percent'], 50)
        self.assertEqual(group['cached_valid_records'], 1)
        self.assertEqual(metadata['measurement_summary']['groups'][0]['counters']['deltas']['usb_drops'], 2)
        self.assertEqual(metadata['framing_counts']['pending_bytes_at_end'], 5)
        self.assertTrue(port.closed)
        self.assertEqual(port.writes, [])
        self.assertEqual(metadata['commands_sent'], [])
        series = imu_plot.load_series(self.out)
        self.assertEqual(len(series[(1, 123)]), 2)
        self.assertEqual(series[(1, 123)][1][1], 110000)
        self.assertEqual(imu_plot.load_series(self.out, node=2), {})

    def test_long_calibration_wait_then_full_measurement(self):
        # STATS alone satisfy startup timeout, even with silence until calibration finishes.
        # Multiple records in one USB read must straddle the phase boundary correctly.
        ready_batch = frame(payload(2, state=1, calibration=0)) + frame(payload()) + frame(payload(tx=1))
        port = ScheduledPort(self.clock, [(.25, frame(payload(6))), (60, ready_batch),
                                          (61, frame(payload(tx=2))), (62, frame(payload(2, state=3)))])
        metadata = self.run_capture(port)
        self.assertEqual(self.clock.now, 63)
        self.assertEqual(metadata['status'], 'completed')
        self.assertEqual(metadata['calibration_wait_s'], 60)
        self.assertEqual(metadata['measurement_start_pc_elapsed_s'], 60)
        self.assertEqual(metadata['measurement_duration_s'], 3)
        self.assertIsNotNone(metadata['measurement_started_utc'])
        self.assertEqual(metadata['phase_record_counts'], dict(waiting=2, recording=4))
        self.assertEqual(metadata['summary']['pc_capture_duration_s'], 63)
        self.assertEqual(metadata['measurement_summary']['pc_capture_duration_s'], 3)
        self.assertEqual(metadata['measurement_summary']['groups'][0]['captured_records'], 4)
        with self.out.open(newline='') as file:
            rows = list(csv.DictReader(file))
        self.assertEqual([r['capture_phase'] for r in rows], ['waiting'] * 2 + ['recording'] * 4)
        self.assertEqual([r['measurement_elapsed_s'] for r in rows], ['', '', '0.0', '0.0', '1.0', '2.0'])
        self.assertEqual(self.metadata(), json.loads(json.dumps(metadata)))
        self.assertTrue(port.closed)
        self.assertEqual(port.writes, [])

    def test_faults_and_uncalibrated_data_do_not_start_measurement(self):
        faults = [payload(2), payload(2, state=3), payload(state=0), payload(state=1),
                  payload(state=3), payload(calibration=254), payload(flags=5), payload(flags=9),
                  payload(flags=15), payload(3, node=0), payload(4, node=0), payload(5)]
        # Each nonready record outlasts --seconds, but none may start the deadline.
        events = [(.25, frame(payload(6, node=0)))]
        events += [(2 + i * 4, frame(raw)) for i, raw in enumerate(faults)]
        events.append((50, frame(payload(node=2, flags=3))))
        self.args.source = 'hub'
        port = ScheduledPort(self.clock, events)
        metadata = self.run_capture(port)
        self.assertEqual(self.clock.now, 53)
        self.assertEqual(metadata['calibration_wait_s'], 50)
        self.assertEqual(metadata['phase_record_counts'], dict(waiting=13, recording=1))
        self.assertEqual(metadata['measurement_summary']['groups'][0]['node'], 2)

    def test_interrupt_during_indefinite_calibration_wait(self):
        port = ScheduledPort(self.clock, [(.25, frame(payload(6))),
                                          (30, frame(payload(2, state=1, calibration=0)))], interrupt_at=60)
        metadata = self.run_capture(port)
        self.assertEqual(metadata['status'], 'interrupted')
        self.assertEqual(metadata['calibration_wait_s'], 60)
        self.assertEqual(metadata['measurement_duration_s'], 0)
        self.assertIsNone(metadata['measurement_started_utc'])
        self.assertIsNone(metadata['measurement_start_pc_elapsed_s'])
        self.assertEqual(metadata['phase_record_counts'], dict(waiting=2, recording=0))
        self.assertEqual(metadata['measurement_summary']['groups'], [])
        self.assertEqual(self.metadata()['status'], 'interrupted')
        self.assertTrue(port.closed)
        self.assertEqual(port.writes, [])

    def test_eof_recovery_does_not_start_measurement(self):
        # A bogus frame length can defer a following valid DATA until finish().
        wire = b'IMU1' + struct.pack('<HI', 64, 0) + frame(payload())
        port = MockPort(self.clock, wire, interrupt=True)
        metadata = self.run_capture(port)
        self.assertEqual(metadata['framing_counts']['accepted_frames'], 1)
        self.assertEqual(metadata['phase_record_counts'], dict(waiting=1, recording=0))
        self.assertIsNone(metadata['measurement_started_utc'])
        self.assertEqual(metadata['status'], 'interrupted')

    def test_malformed_binary_does_not_satisfy_startup_timeout(self):
        bad = bytearray(payload())
        bad[34] = 1
        port = MockPort(self.clock, b'USB text' + frame(bad), fragment=4096)
        with self.assertRaises(TimeoutError):
            self.run_capture(port)
        metadata = self.metadata()
        self.assertEqual(metadata['framing_counts']['malformed_payloads'], 1)
        self.assertIsNone(metadata['measurement_started_utc'])
        self.assertEqual(metadata['measurement_duration_s'], 0)
        self.assertLessEqual(self.clock.now, 1.25)
        self.assertTrue(port.closed)

    def test_exclusive_csv_and_metadata(self):
        self.out.write_text('existing csv', encoding='utf-8')
        with self.assertRaises(FileExistsError):
            self.run_capture(MockPort(self.clock))
        self.assertEqual(self.out.read_text(), 'existing csv')
        self.out.unlink()
        meta = self.out.with_suffix('.metadata.json')
        meta.write_text('existing metadata', encoding='utf-8')
        with self.assertRaises(FileExistsError):
            self.run_capture(MockPort(self.clock))
        self.assertFalse(self.out.exists())
        self.assertEqual(meta.read_text(), 'existing metadata')

    def test_clean_ctrl_c_during_capture(self):
        port = MockPort(self.clock, frame(payload()), interrupt=True)
        metadata = self.run_capture(port)
        self.assertEqual(metadata['status'], 'interrupted')
        self.assertEqual(metadata['framing_counts']['accepted_frames'], 1)
        self.assertIsNotNone(metadata['measurement_started_utc'])
        self.assertEqual(metadata['phase_record_counts'], dict(waiting=0, recording=1))
        self.assertAlmostEqual(metadata['measurement_duration_s'], .25)
        self.assertTrue(port.closed)
        self.assertEqual(self.metadata()['status'], 'interrupted')

    def test_clean_ctrl_c_during_startup(self):
        def interrupted(*args, **kwargs):
            raise KeyboardInterrupt
        with patch.object(capture.time, 'monotonic', self.clock), contextlib.redirect_stdout(self.log):
            metadata = capture.capture(self.args, interrupted)
        self.assertEqual(metadata['status'], 'interrupted')
        self.assertEqual(metadata['summary']['groups'], [])
        self.assertEqual(self.metadata()['status'], 'interrupted')

    def test_serial_disconnect_retains_data_and_error(self):
        port = MockPort(self.clock, frame(payload()), failure=OSError('disconnected'))
        with self.assertRaisesRegex(OSError, 'disconnected'):
            self.run_capture(port)
        self.assertTrue(port.closed)
        self.assertEqual(self.metadata()['status'], 'error')
        self.assertEqual(self.metadata()['framing_counts']['accepted_frames'], 1)

    def test_finite_startup_timeout(self):
        # A requested measurement shorter than startup timeout must not hide broken USB.
        self.args.seconds = .25
        port = MockPort(self.clock)
        with self.assertRaises(TimeoutError):
            self.run_capture(port)
        self.assertLessEqual(self.clock.now, 1.25)
        self.assertTrue(port.closed)
        self.assertEqual(self.metadata()['status'], 'error')

    def test_all_explicit_commands_and_no_output_files(self):
        for name, letter in capture.COMMANDS.items():
            with self.subTest(command=name):
                self.args.command = name
                self.args.seconds = .5
                port = MockPort(self.clock, frame(payload(2)), fragment=100)
                started = self.clock.now
                with patch.object(capture.time, 'monotonic', self.clock), contextlib.redirect_stdout(self.log):
                    capture.command(self.args, port.factory)
                self.assertGreaterEqual(self.clock.now - started, .5)
                self.assertLess(self.clock.now - started, .75)
                self.assertEqual(port.writes, [(letter + '\n').encode('ascii')])
                self.assertTrue(port.closed)
                self.assertIn('not acknowledged', self.log.getvalue())
                self.assertIn('No matching command ACK observed', self.log.getvalue())
        self.assertFalse(self.out.exists())

    def test_matching_ack_reports_result(self):
        self.args.command = 'save'
        self.args.seconds = .5
        ack = bytearray(24)
        struct.pack_into('<BBBBIII', ack, 0, 1, 8, 1, 0, 42, 0, 0)
        ack[16] = ord('S')
        struct.pack_into('<i', ack, 20, -11)
        port = MockPort(self.clock, frame(ack), fragment=100)
        with patch.object(capture.time, 'monotonic', self.clock), contextlib.redirect_stdout(self.log):
            capture.command(self.args, port.factory)
        self.assertIn('ACK result=-11', self.log.getvalue())
        self.assertNotIn('No matching command ACK', self.log.getvalue())

    def test_short_command_write(self):
        port = MockPort(self.clock)
        port.write = lambda data: 1
        with contextlib.redirect_stdout(self.log), self.assertRaisesRegex(IOError, 'Short command write'):
            capture.command(self.args, port.factory)
        self.assertTrue(port.closed)

    def test_cli_rejects_nonfinite_duration_and_mixed_command(self):
        for value in ('nan', 'inf', '0', '-1'):
            with self.subTest(value=value), contextlib.redirect_stderr(self.log), self.assertRaises(SystemExit):
                capture.main(['--port', 'TEST', '--seconds', value])
        with contextlib.redirect_stderr(self.log), self.assertRaises(SystemExit):
            capture.main(['--port', 'TEST', '--command', 'query', '--out', str(self.out)])
        self.assertFalse(self.out.exists())

    def test_cli_command_standalone(self):
        port = MockPort(self.clock)
        with patch.object(capture, 'serial_factory', return_value=port.factory), \
                patch.object(capture.time, 'monotonic', self.clock), contextlib.redirect_stdout(self.log):
            self.assertEqual(capture.main(['--port', 'TEST', '--command', 'pause', '--seconds', '.5']), 0)
        self.assertEqual(port.writes, [b'P\n'])

    def test_plot_keeps_same_quaternion_new_sequence_and_sessions(self):
        with self.out.open('w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=capture.FIELDS)
            writer.writeheader()
            for raw in (payload(read=0xffffffff), payload(tx=1, read=0xffffffff),
                        payload(tx=2, read=0, completed=110000),
                        payload(session=456), payload(2, session=456, tx=1)):
                writer.writerow(capture.decode_payload(raw))
        series = imu_plot.load_series(self.out)
        self.assertEqual(len(series), 2)
        self.assertEqual([p[0] for p in series[(1, 123)]], [0xffffffff, 0x100000000])
        self.assertEqual(series[(1, 123)][0][2], series[(1, 123)][1][2])

    def test_optional_matplotlib_rendering_and_exclusive_image(self):
        try:
            import matplotlib
        except ImportError:
            self.skipTest('matplotlib is optional and not installed in this interpreter')
        with self.out.open('w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=capture.FIELDS)
            writer.writeheader()
            writer.writerow(capture.decode_payload(payload()))
        image = Path(self.temp.name) / 'plot.png'
        with contextlib.redirect_stdout(self.log):
            imu_plot.plot(self.out, out=image)
        self.assertTrue(image.read_bytes().startswith(b'\x89PNG\r\n\x1a\n'))
        with self.assertRaises(FileExistsError):
            imu_plot.plot(self.out, out=image)


if __name__ == '__main__':
    unittest.main(verbosity=2)
