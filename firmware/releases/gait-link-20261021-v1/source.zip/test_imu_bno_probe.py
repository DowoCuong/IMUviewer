"""Execute diagnostic startup sequence with mocked bus; no hardware."""
import tempfile
from pathlib import Path
import unittest
from test_imu_radio import compile_run

ROOT = Path(__file__).resolve().parent


class ProbeTests(unittest.TestCase):
    def test_startup_sequence_and_abort(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp / 'zephyr/drivers').mkdir(parents=True)
            (tmp / 'zephyr/sys').mkdir()
            (tmp / 'zephyr/kernel.h').write_text('#include <stdint.h>\nvoid k_msleep(int ms);\n')
            (tmp / 'zephyr/device.h').write_text('''
#include <stdbool.h>
struct device {int unused;};
#define DEVICE_DT_GET(x) ((const struct device *)0)
#define DT_NODELABEL(x) 0
#define DT_CHOSEN(x) 0
static bool device_is_ready(const struct device *d) {return true;}
''')
            (tmp / 'zephyr/drivers/i2c.h').write_text('''
int i2c_burst_read(const struct device *, uint8_t, uint8_t, uint8_t *, unsigned);
int i2c_burst_write(const struct device *, uint8_t, uint8_t, const uint8_t *, unsigned);
''')
            (tmp / 'zephyr/drivers/uart.h').write_text('''
#define UART_LINE_CTRL_DTR 1
static int uart_line_ctrl_get(const struct device *d,int c,uint32_t *v){*v=1;return 0;}
''')
            (tmp / 'zephyr/sys/printk.h').write_text('#define printk(...) ((void)0)\n')
            source = r'''
#define main probe_main
#include "imu_bno_probe.c"
#undef main
#include <assert.h>
static unsigned calls, waits, fail_at;
static uint8_t regs[32], values[32], writes[32];
static int delays[16];
void k_msleep(int ms) {delays[waits++]=ms;}
int i2c_burst_read(const struct device *d,uint8_t addr,uint8_t reg,uint8_t *v,unsigned n) {
    assert(addr==0x28 && n==1); regs[calls]=reg; writes[calls]=0;
    *v=reg==0?0xa0:0; return ++calls==fail_at?-5:0;
}
int i2c_burst_write(const struct device *d,uint8_t addr,uint8_t reg,const uint8_t *v,unsigned n) {
    assert(addr==0x28 && n==1); regs[calls]=reg; values[calls]=*v; writes[calls]=1;
    return ++calls==fail_at?-5:0;
}
int main(void) {
    assert(startup(0x28)==0);
    assert(calls==17 && waits==6);
    assert(writes[1] && regs[1]==0x3d && values[1]==0);
    assert(writes[2] && regs[2]==0x3f && values[2]==0x20);
    assert(writes[6] && regs[6]==0x3f && values[6]==0x80);
    assert(writes[9] && regs[9]==0x3d && values[9]==0x0c);
    assert(delays[0]==20 && delays[1]==700 && delays[2]==500);
    assert(delays[3]==20 && delays[4]==10 && delays[5]==1000);
    calls=waits=0; fail_at=1;
    assert(startup(0x28)==-5 && calls==1 && waits==0);
    calls=waits=0; fail_at=3;
    assert(startup(0x28)==0); /* Reset write error must be checked by ID read. */
    return 0;
}
'''
            compile_run(source, tmp)


if __name__ == '__main__':
    unittest.main()
