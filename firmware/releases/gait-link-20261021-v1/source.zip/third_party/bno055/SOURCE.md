# Bosch BNO055 Sensor API provenance

Upstream: https://github.com/boschsensortec/BNO055_SensorAPI (formerly BNO055_driver).

Pinned commit: `6c5d87b771b1a002518ef82231608dcab0d75d30` (2020-01-14, "Updated license and formatting").

Retrieved 2026-09-17 from the immutable raw URLs below. Full upstream files are preserved without modification. License: BSD-3-Clause; see LICENSE and the source file headers.

- https://raw.githubusercontent.com/boschsensortec/BNO055_SensorAPI/6c5d87b771b1a002518ef82231608dcab0d75d30/bno055.c
- https://raw.githubusercontent.com/boschsensortec/BNO055_SensorAPI/6c5d87b771b1a002518ef82231608dcab0d75d30/bno055.h
- https://raw.githubusercontent.com/boschsensortec/BNO055_SensorAPI/6c5d87b771b1a002518ef82231608dcab0d75d30/LICENSE

SHA-256:

- bno055.c: `df90512c4102e9265bdbc8dd9950fe8e9f4300c8f2dffd66a93e023086a8ef55`
- bno055.h: `f09691c2d714bfaf6ff320be6a0561ff944e0145fd03c1df7ff8cd1ca0d04449`
- LICENSE: `c6c5f610dfce4c6a325b9d245a0aad2c8c9edc4a99e8cfa953a81883224ded51`
