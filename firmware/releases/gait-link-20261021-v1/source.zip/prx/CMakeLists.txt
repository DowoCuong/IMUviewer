cmake_minimum_required(VERSION 3.20.0)
find_package(Zephyr REQUIRED HINTS $ENV{ZEPHYR_BASE})
include("${CMAKE_CURRENT_LIST_DIR}/../cmake/esb_timestamp.cmake") # Replace stock ESB sources with local timestamped build.
project(supermini_esb)
if(CONFIG_IMU_APP)
  target_sources(app PRIVATE
    ../src/imu_main.c
    ../src/imu_radio.c
    ../src/imu_sensor_stub.c
  )
else()
  target_sources(app PRIVATE ../src/main.c)
endif()
target_compile_definitions(app PRIVATE ESB_TEST_TRANSMITTER=0)
