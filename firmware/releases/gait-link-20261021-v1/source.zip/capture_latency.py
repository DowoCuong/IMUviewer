"""Capture device-measured ESB transaction timing, not USB arrival latency.

Run with the NCS toolchain Python (includes pyserial), closing other monitors.
"""
import argparse
import csv
import math
import re
import statistics
import struct
import time
import json
import zlib
from pathlib import Path

LINE = re.compile(r'TX session=([0-9a-fA-F]+) seq=(\d+) message=Hello ACK=(yes|NO) attempts=(\d+) transaction_us=(\d+)')
SUMMARY_FIELDS = {
    'TX SUMMARY': ['sent', 'acked', 'failed', 'ack_rate', 'write_errors'],
    'TX RATE': ['target_hz', 'actual_hz', 'skipped_slots'],
    'TX LATENCY': ['ack_samples', 'min_us', 'mean_us', 'max_us', 'timer_hz'],
    'RX SUMMARY': ['received', 'gaps', 'duplicates', 'sessions', 'queue_drops', 'invalid'],
    'RX RATE': ['actual_hz'],
}
FIELDS = list(dict.fromkeys(
    ['record', 'pc_elapsed_s', 'session', 'seq', 'ack', 'attempts', 'transaction_us'] +
    [field for fields in SUMMARY_FIELDS.values() for field in fields]))


def parse_record(line):
    packet = parse(line)
    if packet:
        return dict(record='TX PACKET', **packet)
    for kind, required in SUMMARY_FIELDS.items():
        if not line.startswith(kind + ' '):
            continue
        pairs = dict(re.findall(r'(\w+)=([0-9]+(?:\.[0-9]+)?)%?(?=\s|$)', line.strip()))
        if not all(key in pairs for key in required):
            return None  # Ignore truncated lines, including partial serial reads.
        return dict(record=kind, **{
            key: float(pairs[key]) if '.' in pairs[key] else int(pairs[key])
            for key in required})
    return None


def report_summaries(records):
    latest = {r['record']: r for r in records if r['record'] != 'TX PACKET'}
    if not latest:
        return
    print('\nLatest device summaries (counters and latency are cumulative since board boot):')
    for kind, row in latest.items():
        print(kind + ': ' + ', '.join(f'{key}={row[key]}' for key in SUMMARY_FIELDS[kind]))
    print('RATE values describe the latest firmware reporting window, approximately five seconds.')
    if 'TX LATENCY' in latest:
        print('Latency min/mean/max cover successful packet-and-ACK transactions, including retries.')
        print('They may include packets sent BEFORE capture started; they are not capture-only statistics.')
    if not any(r['record'] == 'TX PACKET' for r in records):
        print('Summary-only firmware: median/p95/p99 cannot be recovered from min/mean/max.')
    print('PC elapsed time labels when a record was collected; it is NOT wireless latency.')


def parse(line):
    match = LINE.search(line)
    if not match:
        return None
    session, seq, ack, attempts, elapsed = match.groups()
    return dict(session=session.lower(), seq=int(seq), ack=ack == 'yes',
                attempts=int(attempts), transaction_us=int(elapsed))


def distribution(rows):
    values = sorted(row['transaction_us'] for row in rows)
    if not values:
        return None
    def percentile(p):
        return values[math.ceil(p * len(values)) - 1]
    return dict(n=len(values), min_us=values[0], mean_us=round(statistics.mean(values), 2),
                median_us=statistics.median(values), p95_us=percentile(.95),
                p96_us=percentile(.96), p99_us=percentile(.99), max_us=values[-1])


def report(rows):
    if not rows:
        print('No timing records. Check TX firmware, COM port and DTR; receiver output has no TX timing.')
        return
    failed = sum(not row['ack'] for row in rows)
    print(f'Captured={len(rows)} ACK_failures={failed} success_rate={100 * (len(rows) - failed) / len(rows):.3f}% failure_rate={100 * failed / len(rows):.3f}%')
    for label, subset in [
        ('ACK successful (all attempts)', [r for r in rows if r['ack']]),
        ('ACK successful (first attempt)', [r for r in rows if r['ack'] and r['attempts'] == 1]),
        ('ACK successful (retried)', [r for r in rows if r['ack'] and r['attempts'] > 1]),
        ('Failure completion time', [r for r in rows if not r['ack']]),
    ]:
        stats = distribution(subset)
        print(label + ': ' + (', '.join(f'{k}={v}' for k, v in stats.items()) if stats else 'no samples'))
    last = {}
    gaps = duplicates = 0
    for row in rows:
        session = row['session']
        if session in last:
            delta = (row['seq'] - last[session]) & 0xFFFFFFFF
            if delta == 0:
                duplicates += 1
            elif delta < 0x80000000:
                gaps += delta - 1
        last[session] = row['seq']
    print(f'TX sessions={len(last)}, capture_sequence_gaps={gaps}, duplicate_records={duplicates}')
    if gaps or duplicates:
        print('WARNING: capture is incomplete or duplicated; reported statistics cover captured records only.')
    print('transaction_us is enqueue-to-ESB-callback time, not one-way latency. Failures are excluded from ACK latency.')


def decode_benchmark(header, raw):
    """Reject incomplete/corrupted exports before calculating any statistics."""
    required = ['session', 'records', 'sent', 'acked', 'failed', 'write_errors',
                'skipped_slots', 'duration_us', 'period_us', 'crc32']
    if not header.startswith('BENCH DATA '):
        raise ValueError('Not a benchmark header')
    fields = dict(re.findall(r'(\w+)=([0-9a-fA-F]+)(?=\s|$)', header.strip()))
    if not all(key in fields for key in required):
        raise ValueError('Incomplete benchmark header')
    meta = {key: fields[key] if key in ('session', 'crc32') else int(fields[key]) for key in required}
    count = meta['records']
    if not 0 <= count <= 48000 or len(raw) != count * 4:
        raise ValueError('Incomplete benchmark payload or invalid record count')
    if zlib.crc32(raw) != int(meta['crc32'], 16):
        raise ValueError('Benchmark checksum mismatch; statistics would be unreliable')
    if meta['sent'] != count or meta['acked'] + meta['failed'] != count:
        raise ValueError('Benchmark counts disagree')
    if meta['period_us'] != 2500 or meta['duration_us'] <= 0:
        raise ValueError('Unexpected benchmark timing configuration')
    rows = []
    for seq, (word,) in enumerate(struct.iter_unpack('<I', raw)):
        attempts = (word >> 24) & 15
        if word & 0x70000000 or not 1 <= attempts <= 4:
            raise ValueError('Invalid packed record')
        rows.append(dict(session=meta['session'], seq=seq, ack=bool(word & 0x80000000),
                         attempts=attempts, transaction_us=word & 0xFFFFFF))
    if sum(r['ack'] for r in rows) != meta['acked']:
        raise ValueError('ACK count disagrees with exported records')
    return meta, rows


def capture_benchmark(args):
    print('Benchmark capture script started.', flush=True)
    import serial
    if args.seconds != int(args.seconds) or not 1 <= args.seconds <= 120:
        raise ValueError('Benchmark duration must be an integer from 1 to 120 seconds')
    metadata_path = args.out.with_suffix('.metadata.json')
    if args.out.exists() or metadata_path.exists():
        raise FileExistsError('Choose a new output name; capture files are never overwritten')
    seconds = int(args.seconds)
    print(f'Opening {args.port}...', flush=True)
    with serial.Serial(args.port, 115200, timeout=.25, write_timeout=3) as port:
        port.dtr = True
        port.reset_input_buffer()
        pending = bytearray()

        def read_line(deadline):
            while time.monotonic() < deadline:
                pending.extend(port.read_until(b'\n', 4096))
                if b'\n' in pending:
                    line, tail = pending.split(b'\n', 1)
                    pending[:] = tail
                    return line.decode('ascii', errors='replace').strip()
                if len(pending) > 4096:
                    raise ValueError('Invalid benchmark control line')
            raise TimeoutError('Timed out waiting for benchmark firmware')

        ready_deadline = time.monotonic() + 10
        print('Port opened. Waiting up to 10 seconds for BENCH READY...', flush=True)
        while not read_line(ready_deadline).startswith('BENCH READY '):
            pass
        print('BENCH READY received. Sending start command...', flush=True)
        port.write(f'S {seconds}\n'.encode('ascii'))
        # Windows flush waits for driver TX drain without a timeout; write()
        # already submitted the short command and has a bounded write timeout.
        print(f'Starting {seconds}s at 400 Hz; every transaction is buffered on the board.', flush=True)
        deadline = time.monotonic() + seconds + 30
        header = None
        next_progress = time.monotonic() + 10
        while time.monotonic() < deadline:
            try:
                line = read_line(min(deadline, next_progress))
            except TimeoutError:
                print('Measurement running; USB export follows completion...', flush=True)
                next_progress = time.monotonic() + 10
                continue
            if line.startswith('BENCH DATA '):
                header = line
                break
            if line.startswith('BENCH ERROR') or line.startswith('ERROR'):
                raise RuntimeError(line)
            if line.startswith('BENCH START '):
                print(line, flush=True)
        if header is None:
            raise TimeoutError('Benchmark did not complete; no statistics reported')
        match = re.search(r'\brecords=(\d+)\b', header)
        if not match or int(match[1]) > 48000:
            raise ValueError('Invalid benchmark record count')
        size = int(match[1]) * 4
        print(f'Downloading {int(match[1])} records ({size} bytes)...', flush=True)
        raw = bytearray(pending)
        pending.clear()
        export_deadline = time.monotonic() + 60
        while len(raw) < size and time.monotonic() < export_deadline:
            raw.extend(port.read(min(4096, size - len(raw))))
        meta, rows = decode_benchmark(header, raw)
        end = read_line(export_deadline)
        while not end:
            end = read_line(export_deadline)
        if end != f"BENCH END records={meta['records']}":
            raise ValueError('Missing benchmark end marker')
    meta['requested_seconds'] = seconds
    meta['actual_hz'] = round(meta['sent'] * 1000000 / meta['duration_us'], 3)
    if meta['sent'] + meta['write_errors'] + meta['skipped_slots'] != seconds * 400:
        raise ValueError('Scheduled slot accounting mismatch; no statistics reported')
    meta['success_rate_percent'] = round(100 * meta['acked'] / meta['sent'], 6) if meta['sent'] else None
    meta['successful_latency'] = distribution([r for r in rows if r['ack']])
    meta['first_attempt_latency'] = distribution([r for r in rows if r['ack'] and r['attempts'] == 1])
    meta['retried_latency'] = distribution([r for r in rows if r['ack'] and r['attempts'] > 1])
    meta['failed_completion_time'] = distribution([r for r in rows if not r['ack']])
    with args.out.open('x', newline='', encoding='utf-8') as output:
        writer = csv.DictWriter(output, fieldnames=['session', 'seq', 'ack', 'attempts', 'transaction_us'])
        writer.writeheader()
        writer.writerows(rows)
    with metadata_path.open('x', encoding='utf-8') as output:
        json.dump(meta, output, indent=2)
    print('All records received: count, ACK totals and CRC32 verified.')
    print(f"Actual send rate={meta['actual_hz']} Hz, skipped_slots={meta['skipped_slots']}, write_errors={meta['write_errors']}")
    report(rows)
    print(f'Saved {args.out.resolve()} and {metadata_path.resolve()}')


def self_test():
    line = 'TX session=1234abcd seq=42 message=Hello ACK=yes attempts=1 transaction_us=321'
    assert parse(line) == dict(session='1234abcd', seq=42, ack=True, attempts=1, transaction_us=321)
    assert parse(line.replace('ACK=yes', 'ACK=NO'))['ack'] is False
    assert parse('TX SUMMARY sent=10') is None
    assert parse(line.rsplit(' transaction_us', 1)[0]) is None
    assert distribution([]) is None
    assert distribution([{'transaction_us': x} for x in range(1, 101)]) == dict(
        n=100, min_us=1, mean_us=50.5, median_us=50.5, p95_us=95, p96_us=96, p99_us=99, max_us=100)
    # Failed transactions must not enter the successful latency distribution.
    rows = [parse(line), parse(line.replace('ACK=yes', 'ACK=NO').replace('=321', '=2000'))]
    assert distribution([r for r in rows if r['ack']])['max_us'] == 321
    assert parse_record(line)['record'] == 'TX PACKET'
    summary = parse_record('TX SUMMARY sent=2000 acked=1999 failed=1 ack_rate=99.9% write_errors=0')
    assert summary['failed'] == 1 and summary['ack_rate'] == 99.9
    assert parse_record('TX RATE target_hz=400 actual_hz=399.8 skipped_slots=2')['actual_hz'] == 399.8
    assert parse_record('TX LATENCY ack_samples=1999 min_us=444 mean_us=450 max_us=2243 timer_hz=1000000')['max_us'] == 2243
    assert parse_record('RX SUMMARY received=2000 gaps=0 duplicates=0 sessions=1 queue_drops=0 invalid=0')['received'] == 2000
    assert parse_record('RX RATE actual_hz=400.0')['actual_hz'] == 400
    assert parse_record('TX LATENCY ack_samples=1999 min_us=444 mean_us=450 max_us=') is None
    # Exercise the CSV writer and reporting with no per-packet data.
    import contextlib
    import io
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=FIELDS)
    writer.writeheader()
    writer.writerow(dict(pc_elapsed_s=5.0, **summary))
    assert list(csv.DictReader(io.StringIO(output.getvalue())))[0]['sent'] == '2000'
    with contextlib.redirect_stdout(output):
        report_summaries([summary])
    assert 'cannot be recovered' in output.getvalue()
    raw = struct.pack('<3I', 0x81000000 | 445, 0x82000000 | 1142, 0x04000000 | 2243)
    header = f'BENCH DATA session=1234abcd records=3 sent=3 acked=2 failed=1 write_errors=0 skipped_slots=0 duration_us=7500 period_us=2500 crc32={zlib.crc32(raw):08x}'
    meta, decoded = decode_benchmark(header, raw)
    assert meta['failed'] == 1 and decoded[1]['attempts'] == 2 and not decoded[2]['ack']
    assert distribution([r for r in decoded if r['ack']])['median_us'] == 793.5
    for bad_header, bad_data in [(header, raw[:-1]), (header, b'\0' + raw[1:]),
                                 (header.replace('acked=2', 'acked=3'), raw)]:
        try:
            decode_benchmark(bad_header, bad_data)
        except ValueError:
            pass
        else:
            raise AssertionError('Corrupted or inconsistent benchmark was accepted')
    print('Packet/summary parsing, CSV, reporting, percentile and ACK separation tests passed.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', help='Transmitter or receiver COM port, e.g. COM9')
    parser.add_argument('--seconds', type=float, default=120)
    parser.add_argument('--out', type=Path, default=Path('latency.csv'))
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--benchmark', action='store_true', help='Start buffered 400 Hz run, then verify and download all records')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if not args.port:
        parser.error('--port is required')
    if not math.isfinite(args.seconds) or args.seconds <= 0:
        parser.error('--seconds must be positive and finite')
    if args.benchmark:
        capture_benchmark(args)
        return
    import serial
    records = []
    # Exclusive creation avoids silently replacing an earlier measurement.
    with args.out.open('x', newline='', encoding='utf-8') as output:
        writer = csv.DictWriter(output, fieldnames=FIELDS)
        writer.writeheader()
        with serial.Serial(args.port, 115200, timeout=.25) as port:
            port.dtr = True
            time.sleep(.3)
            port.reset_input_buffer()
            started = time.monotonic()
            deadline = started + args.seconds
            print(f'Capturing {args.port} for {args.seconds:g} seconds -> {args.out.resolve()}', flush=True)
            pending = b''
            try:
                while time.monotonic() < deadline:
                    # read_until may return a fragment on timeout; preserve it.
                    # At these rates a full line fits comfortably within 4096 bytes.
                    pending += port.read_until(b'\n', 4096)
                    if b'\n' not in pending:
                        if len(pending) > 4096:
                            pending = b''
                        continue
                    line, pending = pending.split(b'\n', 1)
                    text = line.decode('utf-8', errors='replace').strip()
                    row = parse_record(text)
                    if row:
                        row['pc_elapsed_s'] = round(time.monotonic() - started, 3)
                        records.append(row)
                        writer.writerow(row)
                        output.flush()
                        if row['record'] != 'TX PACKET':
                            print(text, flush=True)
                    elif text.startswith('ERROR') or 'write_error=' in text:
                        print(text, flush=True)
            except KeyboardInterrupt:
                print('Capture stopped; retaining recorded samples.')
    packets = [r for r in records if r['record'] == 'TX PACKET']
    if packets:
        report(packets)
    report_summaries(records)
    if not records:
        print('No recognized records. Check COM port/DTR and allow more than five seconds for summaries.')
    else:
        print(f'Saved {len(records)} records to {args.out.resolve()}')


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nCapture cancelled. A running board benchmark may continue; reset the transmitter before retrying.', flush=True)
