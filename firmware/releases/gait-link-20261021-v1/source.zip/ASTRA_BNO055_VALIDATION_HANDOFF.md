# Astra handoff — BNO055 calibration diagnostics

> Historical Luna handoff. Superseded by `ASTRA_BNO055_VALIDATION_REPORT.md`
> for tested behavior and artifacts. In particular, bus frequency now comes from
> devicetree, save admission reads CALIB_STAT on the worker, and diagnostic validity
> is explicit. Claims below describe the pre-validation implementation.

Luna implementation handoff. No tests, Zephyr builds, UF2 verification, COM capture, flashing, or hardware validation was run in this turn.

## Changed

- Added transmitter configuration for BNO055 address (`CONFIG_IMU_BNO055_ADDRESS`, default 0x29), I2C frequency (`CONFIG_IMU_I2C_FREQUENCY`, default 100000 Hz), and clean boot offset bypass (`CONFIG_IMU_BYPASS_SAVED_CALIBRATION`). Existing A/B transmitter profiles explicitly use 100 kHz.
- Added `ptx/diagnostic-a100.conf` for a clean A100 diagnostic build using the production sensor path.
- Added sensor diagnostic packet type 7 (64 bytes), emitted locally every 2 seconds. It reports address/frequency, chip ID and ST_RESULT, raw CALIB_STAT, SYS_STATUS, SYS_ERR, UNIT_SEL, OPR_MODE, PWR_MODE, raw signed accelerometer X/Y/Z, NVS state, init/recovery counts, reset/runtime/consecutive errors, and last error context.
- Added command acknowledgement packet type 8 (24 bytes) for local P/R/S/L/C commands. Result is signed errno; command monitor can distinguish action result from continued USB traffic.
- Added bounded calibration save admission: `S` is rejected unless a fresh valid sample has CALIB_STAT `0xff` and READY state. Calibration writes now read back and compare all 22 bytes before returning success. Boot load also reads back and compares.
- Added MicroPython/CircuitPython comparison requirements and implementation notes to the Luna prompt. MicroPython's `crystal=True` default is documented as a difference; C remains internal-oscillator by design.
- Extended `imu_capture.py` and `imu_calibration_monitor.py` to decode/display types 7 and 8.

## Wire additions

Type 7 payload after the common 16-byte header:

`u32 uptime_ms, init_count, recovery_count, reset_errors, runtime_errors, consecutive_errors, last_error; u8 last_error_reg, last_error_phase, i2c_address, i2c_khz; u8 calib_raw, sys_status, sys_error, unit_sel, opr_mode, pwr_mode, page, nvs_state; i16 accel_x/y/z; u8 chip_id, st_result`.

Type 8 payload after the common header: `u8 command, nvs_state, sensor_state, reserved; i32 result`.

## Astra checks

1. Compile all transmitter/hub profiles and inspect generated devicetree: transmitter I2C must be P0.17/P0.20 and 100 kHz by default. Check `CONFIG_IMU_BNO055_ADDRESS` is accepted by the target build.
2. Run existing regression suite, then add production-C coverage for type 7/8 decoding, signed raw ACC, save rejection before READY, calibration write readback mismatch, and bypass preventing NVS writes.
3. Verify `imu_validate()` and Python decoder reject malformed new packet lengths/reserved fields without affecting old packet types.
4. Build `ptx/diagnostic-a100.conf` with a new artifact name. Verify UF2 family/address range and record SHA-256, memory, config, and build ID. Do not overwrite old UF2s.
5. With user hardware, flash only after build verification. Confirm monitor shows address/frequency/build profile, raw ACC changes with six faces, CALIB_STAT raw byte, SYS_ERR, reset/runtime errors, and NVS bypass state.
6. Decision: raw ACC static → investigate sensor page/units/config/power; raw ACC normal but ACC calibration 0/1 → inspect SYS_ERR/reset/NVS policy; 100 kHz passes but 400 kHz fails → investigate I2C timing/electrical; both Python and C fail on same physical pair → investigate shared sensor/power/module.

## Known limits

- Error recovery policy still follows existing initialization-reset flow for runtime quaternion/status errors; Astra should review whether bounded transient retry is safe before changing it.
- Type 7 telemetry is local transmitter USB only; it is not sent over ESB.
- NVS record remains keyed by node ID because BNO055 exposes no verified unique serial in this design. Replacing a sensor still requires clear/recalibrate or clean bypass.
- No hardware result is implied by these source changes.
