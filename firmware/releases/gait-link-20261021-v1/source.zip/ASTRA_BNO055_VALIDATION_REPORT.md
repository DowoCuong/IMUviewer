# BNO055 — Astra validation, 2026-09-18

## Scope

Validate the existing IMU C firmware and build new UF2 artifacts. No blinking,
GPIO scan, standalone probe or benchmark firmware built. No flashing or COM I/O.
Hardware ACC calibration root cause remains unproven.

## Defects found and fixed

- DTS cannot expand a Kconfig variable during devicetree processing. Replaced
  `CONFIG_IMU_I2C_FREQUENCY` with a real 100000 Hz overlay. Optional
  `build-imu.ps1 -I2cHz 400000` applies a second overlay. Telemetry reads the DT
  frequency; radio 100/400 Hz remains independent.
- SAVE rejection used an uninitialized error output, and could invalidate the
  calibration gate without a mode transition. Worker now initializes outputs,
  reads fresh CALIB_STAT before saving, rejects partial calibration with EAGAIN,
  and records whether a CONFIG transition actually occurred.
- Failed boot offset verification prematurely reported NVS offsets as applied.
  Applied state now follows successful 22-byte readback.
- Failed diagnostic reads left cached ACC displayed as current. Type 7 now has
  validity/stale/pause flags and the diagnostic timestamp in header tx_seq.
  Invalid/cached values are explicitly labeled by the monitor. Diagnostic error
  history is separate from the acquisition error used by the radio gate.
- I2C 400 kHz overflowed the original u8 frequency field. The local type 7 field
  uses 100 for 100 kHz and 0 for 400 kHz; C and Python agree.
- Retry failures preceding another attempt were uncounted. They now increment
  runtime/total counters and preserve register/error context. The final failed
  attempt is counted by fault handling. A recovered read does not force reset.
- Command ACK no longer consumes sample-query sequence numbers or interleaves
  unframed error printk output with USB frames. Capture recognizes matching ACKs;
  absence of ACK is unconfirmed execution, including on older firmware.
- C/Python validate new ACK fields consistently, including hub node 0 replies.
  NVS read errors and invalid record lengths retain distinct results.

## Tests

Full IMU suite: **62 tests passed** across six modules:

```
python -m unittest test_imu_sensor_diagnostics test_imu_startup test_imu_sensor_calibration test_imu_calibration_monitor test_imu_capture test_imu_radio
```

The initial run had five native harness errors and two source-wiring failures.
The harness previously rejected every multibyte diagnostic read; it now models
those real bus requests. Persistent fault scenarios inject all three failed
attempts, retaining assertions about reset, fresh calibration gating, sequence,
and preserved last quaternion. No readiness timeout was introduced.

New native C coverage executes production sensor code with mocked Zephyr/I2C:
reset-write error followed by successful recovery; NVS bypass; fresh save
admission despite cached READY; rejected save with initialized outputs and no
mode change; save completion; offset readback mismatch and mode cleanup; signed
raw ACC; invalid cached diagnostics; transient retry counting without reinit;
failed boot readback not marked applied. Python tests exercise type 7/8 fields,
malformed input and command ACK reporting. Existing radio/capture/gating tests
remain included. This does not simulate electrical behavior or real RF timing.

## Build outputs

SDK: NCS v3.4.0; toolchain dcbdc366a1;
board `promicro_nrf52840/nrf52840/uf2`.

All new artifacts use `astra-` names in `firmware/`; previous firmware preserved.

| Artifact suffix | Role / profile | Radio | I2C | Boot offsets |
|---|---|---|---|---|
| imu-tx-astra-diag-a100.uf2 | TX1 diagnostic-a100.conf | A100 | 100 kHz | Bypass |
| imu-tx-astra-diag-a100-i2c400.uf2 | TX1 diagnostic-a100.conf | A100 | 400 kHz | Bypass |
| imu-tx-astra-a100.uf2 | TX1 a100.conf | A100 | 100 kHz | Load if valid |
| imu-hub-astra-a100.uf2 | Hub a.conf | A100 | — | — |
| imu-tx-astra-a400.uf2 | TX1 a400.conf | A400 | 100 kHz | Load if valid |
| imu-hub-astra-a400.uf2 | Hub a400.conf | A400 | — | — |
| imu-tx-astra-b1.uf2 | TX1 b1.conf | B100 | 100 kHz | Load if valid |
| imu-tx-astra-b2.uf2 | TX2 b2.conf | B100 | 100 kHz | Load if valid |
| imu-hub-astra-b.uf2 | Hub b.conf | B100 | — | — |

Existing B profiles are 100 Hz; no B400 profile was invented. Acquisition remains
100 Hz; A400 retransmits cached samples as designed.

`firmware/astra-build-manifest.json` records SHA-256, memory usage, generated
configuration and devicetree checks. UF2 family must be 0xADA52840 and every block
must remain in application range [0x26000, 0xEC000), excluding NVS/bootloader.
Generated TX pinctrl must contain SDA=P0.17 and SCL=P0.20. Build logs are retained
as `build-astra-*.log`; a deprecated fixed-partition macro warning remains.

## First hardware check

1. Start with `firmware/imu-tx-astra-diag-a100.uf2` on the transmitter. This uses
   the normal IMU acquisition path, 100 kHz, address 0x29 and bypasses saved offsets.
   It does not erase NVS. Hub is unnecessary for local calibration diagnostics;
   use `imu-hub-astra-a100.uf2` when checking ESB after calibration.
2. Open the transmitter application COM port:
   `python imu_calibration_monitor.py --port COM6`
   Replace COM6 if Windows assigned another port. The monitor sends no commands.
3. Expect addr=0x29, i2c=100kHz, nvs=4. Only interpret ACC/status from VALID,
   nonstale diagnostic records. Keep the user's already-correct six-face method.
   Observe signed ACC change with orientation, CALIB_STAT, SYS_ERR and whether
   runtime errors/recovery count increase.
4. Compare the i2c400 diagnostic artifact only after recording the 100 kHz run,
   with the same physical pair and setup. Both bypass offsets. A bus-speed
   comparison is not a radio-rate comparison.

## Limits / remaining hardware evidence

- Passing host tests/build/UF2 validation does **not** establish that ACC reaches 3,
  ESB runs losslessly, or hardware I2C is healthy. No hardware result claimed.
- Type 7/8 are local USB records. Use the updated host tools with these artifacts.
- `nvs_state` describes boot-offset policy/result (0 unknown, 1 missing,
  2 applied, 3 invalid/error, 4 bypass); it is not a live NVS inventory after S/C.
  Command ACK result is the command outcome. Clear does not remove live offsets.
- Error counters count failed operations/attempts, not electrical bus events.
  A diagnostic poll where both reads fail counts once; consecutive_errors clears
  after a successful quaternion. Register/phase describe the latest recorded
  failure; cleanup may replace context for a calibration-transaction failure.
- Build identity is supplied by artifact hashes/configuration in the manifest,
  not by CHIP_ID. Full BNO software revision/build ID and first-error timestamp
  are not transmitted in the current 64-byte diagnostic record.
- ACK has no host request nonce; avoid concurrent command writers. A timeout
  cannot prove whether an in-flight persistence operation ultimately completed.
