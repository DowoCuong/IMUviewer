"""Offline calibration display tests; no serial devices opened."""
import contextlib
import io
import struct
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import imu_calibration_monitor as monitor
from test_imu_capture import frame, payload
from imu_capture import decode_payload


def diag_packet(calibration=255, flags=1, node=1, session=10):
    packet = bytearray(64)
    struct.pack_into('<BBBBIII', packet, 0, 1, 7, node, flags, session, 1234, 0)
    packet[46:49] = bytes((0x29, 100, calibration))
    packet[62] = 0xa0
    return packet


class MonitorTests(unittest.TestCase):
    def test_bit_order_all_possible_levels(self):
        for value in range(256):
            row = dict(calibration=value, state=1, node=1)
            text = monitor.format_progress(row, 0)
            self.assertIn(f'sys = {(value >> 6) & 3}', text)
            self.assertIn(f'gy = {(value >> 4) & 3}', text)
            self.assertIn(f'mag = {value & 3}', text)
            self.assertIn(f'acc = {(value >> 2) & 3}', text)

    def test_fault_and_stale_are_not_presented_as_live_calibration(self):
        text = monitor.format_progress(dict(calibration=0, state=3, node=1), 4,
                                       dict(i2c_errors=47))
        self.assertIn('SENSOR_FAULT', text)
        self.assertIn('calibration = UNKNOWN', text)
        self.assertIn('last_known_state = SENSOR_FAULT', text)
        self.assertIn('i2c_errors = 47', text)
        self.assertIn('NO_RECENT_STATUS', text)
        self.assertIn('WAITING_FOR_TX_STATUS', monitor.format_progress(None, 0))

    def run_mock(self, hub=False):
        clock = [0.0]
        class Port:
            dtr = False
            closed = False
            def __enter__(self):
                return self
            def __exit__(self, *args):
                self.closed = True
            def read(self, size):
                clock[0] += .125
                if hub:
                    return frame(payload(kind=6, node=0))
                ready = clock[0] >= 2
                return frame(payload(kind=2, calibration=255 if ready else 0x6c,
                                     state=2 if ready else 1))
            def write(self, data):
                raise AssertionError('Monitor must not send commands')
        port = Port()
        output = io.StringIO()
        with patch.object(monitor.time, 'monotonic', side_effect=lambda: clock[0]), contextlib.redirect_stdout(output):
            monitor.monitor(SimpleNamespace(port='TEST', nodes=1, seconds=3),
                            factory=lambda *a, **kw: port)
        self.assertTrue(port.closed)
        self.assertTrue(port.dtr)
        return output.getvalue()

    def test_prints_once_per_second_and_tracks_state(self):
        text = self.run_mock()
        lines = [line for line in text.splitlines() if line.startswith('sys =')]
        self.assertEqual(len(lines), 3)
        self.assertIn('CALIBRATING', lines[0])
        self.assertIn('sys = 1', lines[0])
        self.assertIn('gy = 2', lines[0])
        self.assertIn('mag = 0', lines[0])
        self.assertIn('acc = 3', lines[0])
        self.assertIn('READY', lines[1])
        self.assertIn('sys = 3', lines[1])

    def test_warns_if_hub_port_selected(self):
        self.assertIn('Use the transmitter USB port', self.run_mock(hub=True))

    def test_diagnostic_replaces_old_acc1_without_inventing_ready(self):
        text = monitor.format_progress(dict(calibration=0xf7, state=1, node=1), 20,
                                       diagnostic=decode_payload(diag_packet()), diagnostic_age=.2)
        self.assertIn('acc = 3', text)
        self.assertIn('calibration = FULL source = DIAG', text)
        self.assertIn('firmware_state = UNKNOWN', text)
        self.assertNotIn('firmware_state = READY', text)

    def test_all_diagnostic_bit_combinations_and_real_drops(self):
        for value in (255, 191, 254, 247, *range(256)):
            text = monitor.format_progress(None, 0, diagnostic=decode_payload(diag_packet(value)),
                                           diagnostic_age=0)
            for field, level in (('sys', value >> 6), ('gy', (value >> 4) & 3),
                                 ('acc', (value >> 2) & 3), ('mag', value & 3)):
                self.assertIn(f'{field} = {level}', text)

    def test_invalid_diagnostic_never_falls_back_to_ready_sample(self):
        row = dict(type=1, valid=1, state=2, calibration=255, node=1)
        for flags, age, label in ((0, 0, 'INVALID'), (5, 0, 'STALE'),
                                  (9, 0, 'PAUSED'), (1, 3.51, 'STALE')):
            with self.subTest(label=label):
                text = monitor.format_progress(row, 0, diagnostic=decode_payload(diag_packet(flags=flags)),
                                               diagnostic_age=age)
                self.assertIn('calibration = UNKNOWN source = DIAG', text)
                self.assertIn(f'freshness = {label}', text)
                self.assertNotIn('acc = 3', text)

    def test_status_fallback_rejects_pause_stale_fault_and_invalid_data(self):
        for extra in (dict(paused=1), dict(stale=1), dict(state=3), dict(state=0),
                      dict(type=1, valid=0)):
            row = dict(type=2, state=2, calibration=255, node=1)
            row.update(extra)
            text = monitor.format_progress(row, 0)
            self.assertIn('calibration = UNKNOWN', text)
            self.assertNotIn('acc = 3', text)

    def test_newer_warning_supersedes_older_full_diagnostic(self):
        for extra, label in ((dict(state=3), 'SENSOR_FAULT'), (dict(state=0), 'INITIALIZING'),
                             (dict(paused=1), 'PAUSED')):
            row = dict(type=2, state=2, calibration=255, node=1)
            row.update(extra)
            text = monitor.format_progress(row, .1, diagnostic=decode_payload(diag_packet()),
                                           diagnostic_age=1)
            self.assertIn(f'sample_warning = {label}', text)
            self.assertIn('calibration = UNKNOWN', text)

    def test_stats_expiry_does_not_hide_fresh_calibration(self):
        text = monitor.format_progress(None, 0, dict(i2c_errors=47),
                                       decode_payload(diag_packet()), 0, 4)
        self.assertIn('calibration = FULL', text)
        self.assertIn('i2c_errors = STALE', text)
        self.assertNotIn('47', text)

    def test_diag_detail_labels_pause_and_error_history(self):
        text = monitor.format_sensor_diag(decode_payload(diag_packet(flags=9)))
        self.assertIn('diag = PAUSED', text)
        self.assertIn('values = CACHED/UNCONFIRMED', text)
        self.assertIn('last_error_history', text)
        self.assertIn('sys_status', text)

    def run_stream(self, events, seconds=6, interrupt=False):
        clock = [0.0]
        pending = list(events)
        class Port:
            dtr = False
            closed = False
            def __enter__(self): return self
            def __exit__(self, *args): self.closed = True
            def read(self, size):
                clock[0] += .25
                if interrupt and clock[0] >= 2:
                    raise KeyboardInterrupt
                data = b''
                while pending and pending[0][0] <= clock[0]:
                    _, packet = pending.pop(0)
                    data += frame(packet)
                return data
            def write(self, data): raise AssertionError('Unexpected serial write')
        port = Port()
        output = io.StringIO()
        with patch.object(monitor.time, 'monotonic', side_effect=lambda: clock[0]), contextlib.redirect_stdout(output):
            monitor.monitor(SimpleNamespace(port='TEST', nodes=2, seconds=seconds),
                            factory=lambda *a, **kw: port)
        self.assertTrue(port.closed and port.dtr)
        return output.getvalue()

    def test_diag_only_expiry_and_duration_without_ready(self):
        text = self.run_stream([(0, diag_packet(0xf7))])
        lines = [x for x in text.splitlines() if x.startswith('sys =')]
        self.assertEqual(len(lines), 6)
        self.assertIn('acc = 1', lines[0])
        self.assertIn('firmware_state = UNKNOWN', lines[0])
        self.assertIn('freshness = STALE', lines[-1])
        self.assertNotIn('WAITING_FOR_TX_STATUS', text)

    def test_boot_change_discards_query_snapshot_and_old_stats(self):
        old_sample = bytearray(payload(kind=2, calibration=255, state=2))
        struct.pack_into('<I', old_sample, 4, 999)  # query session != boot session
        old_stats = bytearray(payload(kind=6, node=1))
        struct.pack_into('<I', old_stats, 4, 10)
        struct.pack_into('<I', old_stats, 20, 47)
        text = self.run_stream([(0, diag_packet(session=10)), (.25, old_sample),
                                (.5, old_stats), (1.5, diag_packet(0, session=20))], seconds=3)
        lines = [x for x in text.splitlines() if x.startswith('sys =')]
        self.assertIn('firmware_state = READY', lines[0])  # query did not clear DIAG
        self.assertIn('source = DIAG', lines[0])
        self.assertIn('firmware_state = UNKNOWN', lines[1])
        self.assertNotIn('47', lines[1])
        self.assertIn('acc = 0', lines[1])

    def test_nodes_and_invalid_update_are_independent(self):
        text = self.run_stream([(0, diag_packet(node=1)), (0, diag_packet(0xf7, node=2)),
                                (1.5, diag_packet(flags=0, node=1))], seconds=2)
        lines = [x for x in text.splitlines() if x.startswith('sys =')]
        self.assertEqual(len(lines), 4)
        self.assertIn('acc = 3', lines[0])
        self.assertIn('acc = 1', lines[1])
        self.assertIn('freshness = INVALID', lines[2])
        self.assertIn('acc = 1', lines[3])

    def test_ctrl_c_closes_port(self):
        self.assertIn('Calibration monitor stopped', self.run_stream([], interrupt=True))


if __name__ == '__main__':
    unittest.main()
