"""Hardware-free tests of actual imu_radio.c/imu_sync.h, with mocked ESB/Zephyr.

Uses cc (or CC) on Unix, or installed MSVC on Windows. All generated headers,
executables and object files live in a temporary directory; no board is opened.
"""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

import imu_capture

ROOT = Path(__file__).resolve().parent
KERNEL = r'''
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#define BUILD_ASSERT(x) _Static_assert(x, #x)
#define ARG_UNUSED(x) (void)(x)
#define MIN(a,b) ((a)<(b)?(a):(b))
#define K_FOREVER -1
#define K_NO_WAIT 0
#define K_USEC(x) (x)
#define K_SEM_DEFINE(n,a,b) static int n = a
#define K_MSGQ_DEFINE(n,a,b,c) static int n
#define K_THREAD_DEFINE(...)
static void k_sem_give(int *s) { *s = 1; }
static void k_sem_reset(int *s) { *s = 0; }
static int k_sem_take(int *s, int timeout) { (void)timeout; if (*s) { *s=0; return 0; } return -1; }
static int k_msgq_put(int *q, const void *r, int t) { (void)q; (void)r; (void)t; return 0; }
static int k_msgq_get(int *q, void *r, int t) { (void)q; (void)r; (void)t; return -1; }
static void k_msgq_purge(int *q) { (void)q; }
void k_busy_wait(uint32_t us);
void k_usleep(uint32_t us);
void k_msleep(uint32_t ms);
'''
ATOMIC = r'''
typedef int atomic_t;
static int atomic_get(atomic_t *a) { return *a; }
static void atomic_set(atomic_t *a, int v) { *a=v; }
static void atomic_clear(atomic_t *a) { *a=0; }
static void atomic_inc(atomic_t *a) { ++*a; }
static int atomic_cas(atomic_t *a,int old,int v) { if (*a!=old) return 0; *a=v; return 1; }
'''
ESB = r'''
#define ESB_EVENT_TX_SUCCESS 1
#define ESB_EVENT_TX_FAILED 2
#define ESB_EVENT_RX_RECEIVED 3
#define ESB_PROTOCOL_ESB_DPL 1
#define ESB_BITRATE_2MBPS 1
#define ESB_MODE_PRX 1
#define ESB_MODE_PTX 2
#define ESB_TXMODE_AUTO 1
#define ESB_DEFAULT_CONFIG {0}
struct esb_evt { int evt_id; uint32_t tx_attempts; };
struct esb_payload { uint16_t length; uint8_t pipe; bool noack; uint32_t rx_end_us; uint8_t data[64]; };
struct esb_config {
    int protocol, bitrate, mode, tx_mode; void (*event_handler)(const struct esb_evt *);
    bool selective_auto_ack; int retransmit_count, retransmit_delay, payload_length, tx_output_power;
};
int esb_init(const struct esb_config *c);
int esb_disable(void);
int esb_set_base_address_0(const uint8_t *p);
int esb_set_base_address_1(const uint8_t *p);
int esb_set_prefixes(const uint8_t *p, int n);
int esb_set_rf_channel(int c);
int esb_enable_pipes(int p);
int esb_start_rx(void);
int esb_write_payload(const struct esb_payload *p);
int esb_read_rx_payload(struct esb_payload *p);
int esb_flush_tx(void);
uint32_t esb_data_tx_end_us(void);
'''
RADIO_TEST = r'''
#define CONFIG_IMU_NODES 1
#define CONFIG_IMU_NODE_ID 1
#define CONFIG_IMU_RADIO_HZ 100
#define CONFIG_IMU_RF_CHANNEL 80
#define CONFIG_ESB_MAX_PAYLOAD_LENGTH 64
#include "imu_radio.c"
#include <assert.h>
#include <stdio.h>
static uint64_t now;
static unsigned snapshot_cost, calls, published, completion_delay;
static int write_error, completion_kind;
static bool pending_callback;
static uint8_t records[64][64];
uint64_t imu_clock_us(void) { return now; }
void k_busy_wait(uint32_t us) {
    now += us;
    if (pending_callback && now - tx_start >= completion_delay) {
        pending_callback = false;
        struct esb_evt event = {.evt_id=completion_kind, .tx_attempts=1};
        radio_event(&event);
    }
}
void k_usleep(uint32_t us) { k_busy_wait(us); }
void k_msleep(uint32_t ms) { k_busy_wait(ms*1000); }
void imu_sensor_snapshot(struct imu_sample *s, struct imu_sensor_metrics *m) {
    memset(s,0,sizeof(*s)); memset(m,0,sizeof(*m));
    s->valid=true; s->seq=123; s->completed_us=now; s->state=IMU_READY;
    now += snapshot_cost;
}
void imu_publish(const uint8_t *p, uint16_t n, uint32_t event) {
    (void)event; assert(published < 64); assert(imu_validate(p,n,CONFIG_IMU_NODES));
    memcpy(records[published++],p,n);
}
int esb_init(const struct esb_config *c) {
    assert(c->retransmit_count==0 && c->selective_auto_ack);
    assert(c->bitrate==ESB_BITRATE_2MBPS && c->tx_output_power==8); return 0;
}
int esb_disable(void) { pending_callback=false; return 0; }
int esb_set_base_address_0(const uint8_t *p) { (void)p; return 0; }
int esb_set_base_address_1(const uint8_t *p) { (void)p; return 0; }
int esb_set_prefixes(const uint8_t *p,int n) { (void)p; (void)n; return 0; }
int esb_set_rf_channel(int c) { assert(c==CONFIG_IMU_RF_CHANNEL); return 0; }
int esb_enable_pipes(int p) { (void)p; return 0; }
int esb_start_rx(void) { return 0; }
int esb_read_rx_payload(struct esb_payload *p) { (void)p; return -1; }
int esb_flush_tx(void) { return 0; }
uint32_t esb_data_tx_end_us(void) { return (uint32_t)now; }
int esb_write_payload(const struct esb_payload *p) {
    assert(p->pipe==1 && !p->noack); ++calls;
    if (write_error) return -1;
    pending_callback = completion_kind != 0; return 0;
}
static struct imu_sync reset_test(void) {
    now=10000; tx_seq=0; boot_session=42; sent=missed=errors=losses=invalid=0;
    pause_requested=pause_acknowledged=tx_outstanding=0;
    configured=true; prx=true; fatal_error=false; tx_attempted=false;
    tx_done=0; snapshot_cost=calls=published=write_error=0;
    completion_kind=ESB_EVENT_TX_SUCCESS; completion_delay=400; pending_callback=false;
    return (struct imu_sync){.locked=true, .frame=10000, .hub_anchor=10000,
        .local_anchor=10000, .last_pair=11200, .beacon_rx=10240};
}
int main(void) {
    struct imu_sync s=reset_test();
    tx_seq=UINT32_MAX;
    node_frame(&s);
    assert(calls==4 && published==8 && tx_seq==3 && sent==4 && missed==0);
    for (unsigned i=0;i<4;++i) {
        assert(records[2*i][1]==IMU_TIMED_DATA && records[2*i+1][1]==IMU_DIAG);
        assert(imu_validate(records[2*i],IMU_TIMED_DATA_LEN,1));
        assert(imu_get32(records[2*i]+40)==s.local_anchor);
        assert(imu_get32(records[2*i]+44)==s.hub_anchor);
        assert(imu_get32(records[2*i]+8)==UINT32_MAX+i);
        assert(imu_get32(records[2*i+1]+8)==UINT32_MAX+i);
        assert(records[2*i+1][36]==1 && records[2*i+1][37]==1);
    }
    s=reset_test(); snapshot_cost=101; /* Serialization closes every slot gate. */
    tx_elapsed=999; tx_attempts=9; tx_success=true;
    node_frame(&s);
    assert(calls==0 && published==0 && tx_seq==0 && missed==4);
    s=reset_test(); now=15101; /* Already late before snapshot. */
    node_frame(&s);
    assert(calls==3 && published==6 && tx_seq==3 && missed==1);
    s=reset_test(); pause_requested=1;
    node_frame(&s);
    assert(calls==0 && published==0 && tx_seq==0);
    s=reset_test(); s.locked=false;
    node_frame(&s);
    assert(calls==0 && published==0 && tx_seq==0);
    s=reset_test(); write_error=1;
    node_frame(&s);
    assert(calls==4 && published==8 && tx_seq==4 && sent==0 && errors==4 && s.locked && !losses);
    assert(imu_get32(records[1]+16)==UINT32_MAX && records[1][36]==0 && records[1][37]==0);
    s=reset_test(); completion_kind=0; /* No callback: bounded timeout; clock fit survives. */
    node_frame(&s);
    assert(calls==4 && published==8 && tx_seq==4 && sent==4 && errors==4 && s.locked && !losses);
    assert(imu_get32(records[1]+16)==UINT32_MAX && records[1][36]==0 && records[1][37]==0);
    s=reset_test(); completion_delay=700; /* Late success aborts this frame, but ACK really occurred. */
    node_frame(&s);
    assert(calls==4 && published==8 && tx_seq==4 && errors==4 && s.locked && !losses);
    assert(imu_get32(records[1]+16)==700 && records[1][37]==1);
    s=reset_test(); prx=false;
    uint8_t skip[IMU_MAX_LEN]={0};
    assert(!transmit(skip,IMU_DATA_LEN,1,false,9899,true));
    assert(!tx_attempted && missed==0 && calls==0); /* Caller owns missed count. */
    s=reset_test(); completion_kind=ESB_EVENT_TX_FAILED;
    node_frame(&s);
    assert(calls==4 && published==8 && tx_seq==4 && sent==4 && errors==0);
    assert(imu_get32(records[1]+16)==400 && records[1][36]==1 && records[1][37]==0);
    /* Actual producer bytes, consumed by the Python decoder regression. */
    uint8_t p[IMU_MAX_LEN]; control(p,IMU_BEACON,9,10000,10000);
    assert(p[29]==0 && imu_get32(p+24)==40000);
    FILE *f=fopen("control.bin","wb"); assert(f);
    assert(fwrite(p,1,IMU_CONTROL_LEN,f)==IMU_CONTROL_LEN); fclose(f);
    return 0;
}
'''


def compile_run(source, directory):
    directory = Path(directory)
    unit, exe = directory / 'unit.c', directory / 'unit.exe'
    unit.write_text(source, encoding='utf-8')
    cc = os.environ.get('CC') or shutil.which('cc') or shutil.which('gcc')
    if cc:
        cmd = [cc, '-std=c11', '-I', str(directory), '-I', str(ROOT / 'src'), str(unit), '-o', str(exe)]
    elif os.name == 'nt':
        candidates = list(Path('C:/Program Files/Microsoft Visual Studio').glob('*/Community/VC/Auxiliary/Build/vcvars64.bat'))
        if not candidates:
            raise unittest.SkipTest('No native C compiler available')
        batch = directory / 'compile.cmd'
        batch.write_text(f'@call "{sorted(candidates)[-1]}" >nul\n'
                         f'@cl /nologo /std:c11 /TC /I"{directory}" /I"{ROOT / "src"}" '
                         f'"{unit}" /Fe"{exe}" /Fo"{directory / "unit.obj"}"\n', encoding='utf-8')
        cmd = ['cmd.exe', '/c', str(batch)]
    else:
        raise unittest.SkipTest('No native C compiler available')
    env = os.environ.copy()
    if not cc and os.name == 'nt':
        # vcvars batch parsing breaks on quoted parentheses in inherited PATH.
        windows = env.get('SystemRoot', 'C:/Windows')
        env['PATH'] = windows + '/System32;' + windows
    result = subprocess.run(cmd, cwd=directory, env=env, capture_output=True, text=True)
    if result.returncode:
        raise AssertionError(result.stdout + result.stderr)
    subprocess.run([str(exe)], cwd=directory, check=True, timeout=15)


class RadioTests(unittest.TestCase):
    def test_actual_radio_submission_skip_and_diagnostic_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp / 'zephyr/sys').mkdir(parents=True)
            (tmp / 'zephyr/kernel.h').write_text(KERNEL)
            (tmp / 'zephyr/sys/atomic.h').write_text(ATOMIC)
            (tmp / 'esb.h').write_text(ESB)
            compile_run(RADIO_TEST, tmp)
            control = imu_capture.decode_payload((tmp / 'control.bin').read_bytes())
            self.assertEqual((control['rate_hz'], control['period_us']), (100, 40000))

    def test_actual_sync_header(self):
        with tempfile.TemporaryDirectory() as tmp:
            compile_run('#define IMU_SYNC_TEST\n#include "imu_sync.h"\n', tmp)

    def test_rate_and_node_count_must_match_before_lock(self):
        source = r'''
#define IMU_SYNC_TEST
#define main existing_sync_tests
#include "imu_sync.h"
#undef main
int main(void) {
    existing_sync_tests();
    for (unsigned hz=100; hz<=400; hz+=300) {
        for (unsigned nodes=1; nodes<=2; ++nodes) {
            struct imu_sync s={0}; uint8_t p[IMU_MAX_LEN];
            for (unsigned i=0;i<3;++i) {
                uint32_t f=10000+i*IMU_FRAME_US;
                imu_test_control(p,IMU_BEACON,1,i,f); p[28]=nodes; p[29]=(hz==400);
                assert(imu_sync_receive(&s,p,32,f+240,nodes,hz)==0);
                imu_test_control(p,IMU_FOLLOWUP,1,i,f); p[28]=nodes; p[29]=(hz==400);
                assert(imu_sync_receive(&s,p,32,f+1440,nodes,hz)==1);
            }
            assert(s.locked);
            imu_sync_reset(&s);
            imu_test_control(p,IMU_BEACON,1,3,130000); p[28]=nodes; p[29]=(hz!=400);
            assert(imu_sync_receive(&s,p,32,130240,nodes,hz)==-1);
            assert(!s.pending && !s.locked);
            p[29]=(hz==400); p[28]=3-nodes;
            assert(imu_sync_receive(&s,p,32,130240,nodes,hz)==-1);
            assert(!s.pending && !s.locked);
        }
    }
    return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            compile_run(source, tmp)

    def test_artifact_pairings(self):
        def conf(role, name):
            return dict(line.split('=', 1) for line in (ROOT / role / name).read_text().splitlines()
                        if line.startswith('CONFIG_'))
        for hub, node in [('a.conf', 'a100.conf'), ('a400.conf', 'a400.conf'),
                          ('b.conf', 'b1.conf'), ('b.conf', 'b2.conf')]:
            h, n = conf('prx', hub), conf('ptx', node)
            for key in ('CONFIG_IMU_NODES', 'CONFIG_IMU_RADIO_HZ', 'CONFIG_ESB_MAX_PAYLOAD_LENGTH'):
                self.assertEqual(h[key], n[key], (hub, node, key))
            self.assertEqual(h['CONFIG_IMU_APP'], 'y')
            self.assertEqual(h['CONFIG_COUNTER'], 'y')
        self.assertEqual(conf('prx', 'a.conf')['CONFIG_IMU_RADIO_HZ'], '100')
        self.assertEqual(conf('prx', 'a400.conf')['CONFIG_IMU_RADIO_HZ'], '400')


if __name__ == '__main__':
    unittest.main(verbosity=2)
