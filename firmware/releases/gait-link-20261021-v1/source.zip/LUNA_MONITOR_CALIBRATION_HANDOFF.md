# Luna handoff — calibration monitor display

> Historical implementation handoff. Astra validation and follow-up fixes are
> documented in `ASTRA_MONITOR_VALIDATION.md`. The final code also rejects unsafe
> fallback, restores the hub-port warning, and clears query-session snapshots on
> a diagnostic-confirmed boot change. The pre-validation claims below are not the
> final validation result.

## Changed file

`imu_calibration_monitor.py` only. Firmware C, packet layout, sensor driver,
radio, NVS and CLI arguments were left unchanged. No build, flash, COM access or
hardware action was performed.

## Behavior before

The monitor stored type 1/2 DATA/STATUS in `samples`. Type 7 sensor diagnostics
were printed immediately, but did not update the once-per-second progress line.
After the transmitter started measurement, periodic STATUS could stop while
diagnostic packets continued. The progress line then repeated an old calibration
byte, making a previously completed ACC level appear stuck.

## Behavior after

- One bounded latest-record cache is kept per node for DATA/STATUS, type 7
  diagnostic, and type 6 STATS. Each cache entry stores host
  `time.monotonic()` receive time.
- Type 7 diagnostic is the calibration source whenever it is current:
  `valid=1`, `stale=0`, `paused=0`, and host age <= 3.5 seconds.
- Type 7 calibration decodes `SYS[7:6]`, `GYRO[5:4]`, `ACC[3:2]`, and
  `MAG[1:0]` directly from `calib_raw`. It always displays the newest value;
  it never latches the highest level.
- A current `0xff` is labeled `calibration = FULL`; every other current byte is
  labeled `PARTIAL`. A current `0xbf`, `0xfe`, or `0xf7` therefore shows its
  actual reduced field immediately.
- Invalid, stale or paused diagnostic blocks do not fall back to an older
  diagnostic or STATUS calibration. The line says `calibration = UNKNOWN` with
  `DIAG/INVALID`, `DIAG/STALE`, or `DIAG/PAUSED`.
- DATA/STATUS is a fallback only when no diagnostic exists. Its own host age is
  checked against 3.5 seconds and its source is printed as DATA or STATUS.
- Calibration and firmware state are separate. Type 7 can show current FULL
  calibration while `firmware_state = UNKNOWN` if DATA/STATUS is old or absent.
  A fresh DATA/STATUS fault remains visible and is not overwritten by diagnostic
  calibration.
- Type 7 `session` is treated as the transmitter boot-session identity. When it
  changes, caches explicitly carrying the old boot session are discarded. The
  monitor does not treat the type 1/2 query session as a reboot by itself.
- Type 7 `tx_seq` is not interpreted as a packet sequence or quaternion time.
  Freshness uses only host receive monotonic time. Diagnostic output shows the
  host age explicitly.
- STATS are shown only while fresh; old counters are labeled `STALE`.

## Astra test cases

Update and run tests for:

1. Old STATUS ACC=1 plus current diagnostic `0xff` displays ACC=3 and FULL
   from DIAG, with no current STATUS calibration shown.
2. Diagnostic-only input creates a progress line; firmware state remains UNKNOWN.
3. Current transitions `0xff -> 0xbf`, `0xfe`, and `0xf7` display the reduced
   SYS/MAG/ACC field; no maximum-so-far behavior occurs.
4. Invalid, stale and paused diagnostic records display UNKNOWN and do not fall
   back to old STATUS or old valid diagnostic data.
5. A fresh SENSOR_FAULT DATA/STATUS remains visible beside current diagnostic
   calibration.
6. Diagnostic session change clears matching old boot-session caches without
   treating a different query STATUS session as a reboot.
7. Stale STATS are labeled stale, node caches remain independent, and storage is
   bounded to one latest item per node/type.
8. The monitor sends no serial writes, preserves the existing CLI, hub-port
   warning, one-second cadence and Ctrl+C cleanup.

No tests were run in Luna's implementation turn. Astra owns test updates,
execution, review, build and hardware validation. This change fixes stale host
display selection; it does not claim to fix the BNO055 calibration algorithm or
hardware root cause.
