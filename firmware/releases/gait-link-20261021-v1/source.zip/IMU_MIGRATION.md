# BNO055 → ESB migration: protocol, wiring, calibration, and hardware procedures

Status summary at the end separates what is verified (builds, tests) from what
requires your hardware. Nothing here was measured on hardware by the migration.

## 1. What replaced what

| CircuitPython | C firmware |
|---|---|
| `code.py` reads quaternion over I2C, prints CSV to UART 115200 | Node firmware reads the same sensor registers, transmits binary packets over ESB |
| Hub = PC serial listener | Hub nRF52840 receives ESB, forwards binary frames over USB CDC |
| `capture_latency.py` (text) | `imu_capture.py` (binary framing, CRC32) |

Preserved behavior (verified against `BNO055/code.py` and bundled
`adafruit_bno055.py` 5.4.22): I2C address 0x28, NDOF (0x3D=0x0C), internal
oscillator (no external crystal write), no unit/axis-map writes, quaternion
read at 0x20 as signed little-endian w,x,y,z scaled 1/16384 on the PC,
completion timestamp taken immediately after the read, full calibration =
SYS/GYRO/ACCEL/MAG all 3 (status byte 0x35 == 0xFF), calibration fields
accel/mag/gyro offsets + rad_accel/rad_mag (22 bytes at page-0 0x55..0x6A,
written in CONFIG mode).
Original Python files and captures were not modified.

## 2. Pin mapping — resolved from the supplied SuperMini pinout

The baseline `busio.I2C(board.D3, board.D2)` means **SCL=D3=P0.20** and
**SDA=D2=P0.17**, as labeled in your board image. All transmitter variant
configs set `CONFIG_IMU_SDA_PIN=17` and `CONFIG_IMU_SCL_PIN=20`;
`ptx/i2c_pins.overlay` configures the actual TWIM pinctrl with these same pins.
No scan or further mapping decision is required.

Wire the BNO055 breakout SDA to D2/P0.17, SCL to D3/P0.20, GND to GND,
and its suitable power input to 3.3 V. Use 3.3 V I2C pull-ups, not 5 V;
keep address selection at 0x28. The hub's sensor is unused and may be disconnected.

The intermediate `imu-tx-pinscan.uf2` is not part of the recommended test or
release matrix. Do not flash it: a whole-port GPIO sweep is unnecessary on
this known board and can disturb reserved pins.

## 3. Packet format (little-endian, explicit serialization)

All packets start: u8 version(=1), u8 type, u8 node, u8 flags.
Then u32 session (random boot ID), u32 tx_seq, u32 read_seq.

- **DATA/STATUS (type 1/2, 40 B)**: u64 completed_us @16, i16 w,x,y,z @24
  (raw sensor units; PC divides by 16384), u8 calib_status @32,
  u8 state @33 (0 INITIALIZING, 1 CALIBRATING, 2 READY, 3 SENSOR_FAULT),
  2 reserved, u32 beacon_age_us @36 (0xFFFFFFFF = never synced).
  Flags: bit0 valid (type==1 ⇔ valid), bit1 synced, bit2 stale (>30 ms old
  or sensor fault), bit3 paused.
- **BEACON (3) / FOLLOWUP (4, 32 B)**: u32 event @16, u32 hub_frame @20,
  u32 frame_period_us @24, u8 nodes @28, u8 rate_code @29 (0=100 Hz, 1=400 Hz),
  2 reserved. Beacon event = scheduled frame start; followup event = actual
  captured beacon TX-END timestamp (hardware RADIO END → TIMER3 CC5 capture).
- **DIAG (5, 40 B, node-local USB only)**: u32 transaction_us @16
  (enqueue→ESB callback; failures keep their own completion time, never
  halved), u32 tx_start @20, u32 read_interval_us @24, u32 i2c_duration_us @28,
  u32 deadline_lateness_us @32, u8 attempts @36 (0 = skipped slot), u8 ack @37.
- **STATS (6, 64 B, 1 Hz)**: u32 reads, i2c_errors, acq_missed, radio_sent,
  radio_missed, write_errors, queue_drops, usb_drops, sync_losses,
  invalid_packets, command_drops @16..56, u32 uptime_ms @60.

**USB framing** (hub or node serial): `IMU1` + u16 payload length + u32
hub-capture timestamp (low 32 bits of the hub's 1 MHz clock for DATA/STATUS;
event timestamp for control/diag) + payload + u32 CRC32(length..payload).
The PC tool resynchronizes on the magic after any CRC failure.

**Clock domains**: node `completed_us` and hub `event`/`rx` timestamps are
independent free-running 1 MHz domains (TIMER3 + software high word), each
wrapping every ~71.6 min; all comparisons are modular. No PC-clock conversion
is performed; one-way latency claims are NOT supported. Reboots produce a new
random session id; the PC tool groups by (node, session) and never merges
across them. tx_seq/read_seq are u32 with modular gap detection.

**Cached reads are intentional**: at 100 Hz acquisition / 400 Hz radio the
same completed read is retransmitted; read_seq changes only on a successful
new read, tx_seq on every application transmission. Distinct reads are counted
by read_seq, never by quaternion equality.

## 4. Synchronization and TDMA (Variant B)

40 ms superframes. Hub transmits a no-ACK beacon at frame start and a followup
+1.2 ms carrying the beacon's hardware TX-END capture. A node pairs these to
its RX-END capture, estimates clock offset and drift (≥3 pairs to lock, drift
smoothed, ±200 ppm sanity bound, residual gate 50 µs), then transmits ACKed
data packets only inside its assigned 1 ms slots (16 slot-pairs per frame at
400 Hz/node, 4 at 100 Hz/node; first 5 ms + last 3 ms reserved for sync/guard).
Nodes stop transmitting if the beacon pair times out (≤120 ms) — no data is
sent unsynchronized. One outstanding packet, **zero automatic retries**
(retries of the old 3-retry policy do not fit a 1 ms slot); the bounded
defer/drop policy skips the slot instead. Radio role switching, beacons and
guard time are inside the frame budget. Synchronizing MCU reads does NOT
synchronize the BNO055 internal fusion engines (100 Hz NDOF output).

TX data-END timestamps come from a vendored ESB (RADIO END → TIMER3 CC5 via a
GPPI one-shot, armed only for data windows, frozen before the callback runs;
see `third_party/esb/SOURCE.txt`). An ACK's END cannot overwrite a data
capture. Compile-verified only — first hardware validation must confirm the
capture association (§8.7).

## 5. Calibration

States: INITIALIZING → CALIBRATING → READY (status byte 0xFF) / SENSOR_FAULT.
Valid quaternion reads are observable and marked uncalibrated while
calibrating. Loading saved calibration never requires status 3 one second
after load; the periodic status read decides the state.

Serial commands (single ASCII letter + newline, node USB port):
- `Q` — emit a status/data snapshot
- `S` — read sensor offset registers and store to flash (controlled radio pause)
- `L` — load stored calibration into the sensor
- `C` — erase stored calibration (controlled radio pause)
- `P` / `R` — pause/resume acquisition (sync stays alive)

Persistence: NVS in the fixed storage partition [0xEC000, 0xF4000), record
`BNO1` + version + node id + 22 payload bytes + CRC32, keyed by node id —
one sensor's calibration is never applied to another. Old `calib.json` is NOT
imported (the relocated folder contains none); recalibrate and `S`.

## 6. Capture tooling

```powershell
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\imu_capture.py --port COM9 --seconds 60 --out run1
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\imu_capture.py --port COM9 --command query   # or save/reload/clear/pause/resume
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\imu_capture.py --self-test
& C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe .\imu_plot.py --csv run1.csv --out run1.png
```

Exclusive file creation (never overwrites), finite timeouts, clean Ctrl+C,
CSV + metadata with exact per-node/session distributions (count/min/mean/
median/p95/p96/p99/max), attempt and cached-read accounting, loss indicators.
Hub USB cannot see ACK failures/retries/transaction latency (transmitter-local
DIAG covers those); nothing infers one-way latency. 28 unit tests pass
(1 skipped: matplotlib not installed in the NCS interpreter).

## 7. Builds

One shared source tree; variants differ only by conf files:

```powershell
cd "D:\IMU ESB\NRF52840\Firmware\supermini_esb"
.\build-imu.ps1 -Conf a100.conf -Variant a100            # A transmitter 100 Hz
.\build-imu.ps1 -Conf a400.conf -Variant a400            # A transmitter 400 Hz
.\build-imu.ps1 -Conf b1.conf   -Variant b1              # B transmitter node 1
.\build-imu.ps1 -Conf b2.conf   -Variant b2              # B transmitter node 2
.\build-imu.ps1 -Conf a.conf    -Variant a    -Role prx  # A hub, matches a100
.\build-imu.ps1 -Conf a400.conf -Variant a400 -Role prx  # A hub, matches a400
.\build-imu.ps1 -Conf b.conf    -Variant b    -Role prx  # B hub, matches b1/b2
```

Builds happen outside OneDrive via `C:\ncs\supermini-imu-source` (junction;
Zephyr rejects the space in the OneDrive-adjacent path). Every UF2 is checked
by `verify_uf2.py`: correct family 0xADA52840, address range [0x26000, 0xEC000),
complete block set. Memory: transmitters ~81 KB flash / 37.1 KB RAM, hubs
~72 KB / 34.4 KB — no benchmark buffer is allocated in this application; the
192 KB benchmark mode remains separate. The pins to use are fixed in every
transmitter conf (SDA=P0.17, SCL=P0.20) plus `ptx/i2c_pins.overlay`; the hub
has no sensor.

Artifacts in `firmware/` (all verified): `imu-tx-a100.uf2`, `imu-tx-a400.uf2`,
`imu-tx-b1.uf2`, `imu-tx-b2.uf2`, `imu-hub-a.uf2` (100 Hz), `imu-hub-a400.uf2`
(400 Hz), `imu-hub-b.uf2` (100 Hz, two nodes). A hub only accepts its own rate
and node count; mismatched pairs sync-fail by design. Earlier working
artifacts (`transmitter-*.uf2`, `receiver-*.uf2`) are preserved.

## 8. Hardware test procedures (all pending; nothing below is measured)

1. **Static quaternion** (first test): flash `imu-tx-a400.uf2` to one board
   with a BNO055 wired per §2, `imu-hub-a400.uf2` to the other (its sensor port
   unused), run `imu_capture.py` 60 s. Board level → w≈+1 (or −1, raw NDOF
   sign), x/y/z≈0. Expect CALIBRATING first; calibrate, then `S` to persist.
   (The 100 Hz pair `imu-tx-a100` + `imu-hub-a` is the alternative pairing.)
2. **Controlled rotation**: rotate ±90° about one axis; verify the matching
   component moves ~±0.707 and returns. No filtering/zeroing is applied.
3. **100 Hz acquisition**: STATS `reads` must advance 100/s while
   `acq_missed`=0 and `i2c_errors`=0; DIAG read intervals ~10,000 µs.
   The BNO055 NDOF engine is 100 Hz; distinct internal updates are bounded by
   that, and identical values are not proof of staleness (read_seq is).
4. **400 Hz radio**: flash `imu-tx-a400.uf2` + `imu-hub-a400.uf2` (hub rate
   must match); `radio_sent` 400/s, `radio_missed` small, DIAG ack=1 with
   attempts=1 at bench distance. Distinct reads/sec stays ~100; cached reads
   are expected and flagged by the capture tool.
5. **Sensor disconnect**: unplug SDA/SCL → state=SENSOR_FAULT, last valid
   quaternion flagged stale, transmitter keeps syncing and transmitting status;
   replug → recovery within ~1 s.
6. **Sync/timestamp validation**: hub reboot → nodes stop transmitting, then
   re-lock within a few frames. Missing beacons (screen the hub antenna) →
   sync_losses rise and slots go silent rather than transmitting unsynced.
   With a logic analyzer on TIMER3-CC5-adjacent GPIO or a spare pin driven at
   TX/RX, compare beacon event timestamps to on-air edges (uncertainty ≤ ~50 µs
   is the design goal; treat first measurements as calibration of that claim).
7. **USB backpressure**: close the terminal mid-capture → usb_drops increments
   (frames discarded while DTR is closed; mid-frame disconnects are not
   individually countable), radio rate and sync_losses unaffected; reopen to
   see cumulative counters.
8. **Interference/distance**: Wi-Fi router between boards; compare ack rates,
   RSSI (hub does not currently print RSSI; use packet loss as the metric).
9. **Variant B** (needs a third board): hub-b + b1 + b2; verify per-node slot
   separation (no ACK collisions), both nodes locking from cold at once
   (late-join while the other is transmitting), and one node's reboot not
   disturbing the other's data.

## 9. Known limitations

- Radio timing, ACK behavior and TDMA slots are compile-, unit- and
  mock-tested only (§8); air timing (role-switch latency, ACK turnaround,
  beacon placement) needs the §8.4/§8.6 benches before trusting 400 Hz TDMA
  at range.
- A `S`/`L` calibration request that times out leaves the radio paused until
  reboot (latched safety stop: a late I2C/NVS completion must not write flash
  during a timed benchmark). `C` never blocks. Calibration bus work can also
  finish after its caller timed out; the mailbox retains ownership meanwhile.
- Variant B firmware is built and software-tested (mocks) but three-board
  validation is pending by definition.
- `imu_plot.py` rendering is untested (matplotlib absent from the NCS Python);
  install matplotlib or use another interpreter to render.
- Sensor-fault cache: the last valid quaternion is retransmitted with the
  STALE flag rather than suppressed, so the PC can see both the fault and the
  data age; this is documented behavior, not an error.
- Local `Q`/`S`/`L`/`C` snapshots use a query session (`session ^ 0x80000000`)
  with its own counter, so they can never be confused with over-air packets;
  the hub answers `Q` with STATS, not node-0 data.
- DIAG `attempts=0` means a rejected submission or no completion callback
  (including a slot closed before submission); skipped slots emit no DIAG and
  consume no tx_seq. `transaction_us=0xFFFFFFFF` marks an unknown duration and
  is excluded from latency distributions.
