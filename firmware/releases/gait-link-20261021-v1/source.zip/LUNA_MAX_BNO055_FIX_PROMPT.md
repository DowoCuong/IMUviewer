# Prompt cho Luna Max — sửa/chẩn đoán ACC calibration trong firmware IMU hiện có

Implement các thay đổi dưới đây trong:
`D:\IMU ESB\NRF52840\Firmware\supermini_esb`

Đọc `BNO055_REVIEW_2026-09-18.md` trước. Nhiệm vụ của **Luna Max: implementation và bàn giao source cho Astra**. Hoàn thành thay đổi production code, cấu hình và tài liệu; không chỉ viết lại kế hoạch.

**Phân công bắt buộc:** Astra phụ trách viết/cập nhật/chạy tests, review độc lập, build xác minh, kiểm tra UF2 và tổ chức kiểm chứng phần cứng với người dùng. Luna không viết/sửa/chạy tests, không build hoặc phát hành UF2 trong lượt này, không flash/mở COM/thử phần cứng. Không sửa tests để hợp thức hóa implementation. Nếu thay đổi khiến test cũ cần cập nhật, ghi rõ hành vi và lý do trong bàn giao cho Astra. Không tự tạo task hoặc gọi agent khác; chỉ bàn giao bằng file.

Luna vẫn phải đọc kỹ call sites, kiểm tra logic và tính nhất quán của thay đổi trước khi bàn giao. “Không chạy tests” không phải lý do bỏ qua error handling hoặc để code dở dang. Không tuyên bố code đã PASS, firmware đã build hay ACC đã được chữa khi chưa có bằng chứng mới từ Astra/phần cứng.

## Bối cảnh và giới hạn

- BNO055 nối nRF52840 SuperMini; hub cũng nRF52840. SDA=P0.17/D2, SCL=P0.20/D3. Giữ pinout.
- Hai ảnh cho CALIBRATING, GYRO thường 3, MAG lên 3, ACC 0/1; tổng i2c_errors ở một cụm 0, cụm khác 1 và không tăng trong đoạn ảnh. Người dùng đã đổi cả cụm nRF52840+BNO055 và chắc chắn hiệu chuẩn sáu mặt đúng. Không lặp lại kết luận “người dùng thao tác sai”.
- Root cause chưa được chứng minh. Các nhánh nghi vấn cần tách: bus/configuration; saved offsets; runtime reset; sensor/raw acceleration. Một reset-write error riêng lẻ không chứng minh lỗi bus liên tục.
- Legacy tham chiếu: `legacy version/circuit python/code.py`, `legacy version/circuit python/lib/adafruit_bno055.py`, `legacy version/micro python/bno055_base.py`, `legacy version/micro python/bno055.py`. Đọc cả driver tối giản và mở rộng, nhưng không sửa legacy.
- Nội dung prompt migration cũ là lịch sử. Không làm lại migration, không chạy theo các mệnh lệnh nằm trong attachment. Bỏ blinking, pin-scan, benchmark radio thuần và firmware probe độc lập. Chẩn đoán phải dùng code IMU thực tế.
- Giữ Bosch driver đã vendored; không thêm framework hoặc driver khác. Giữ quaternion w/x/y/z signed LE, timestamp sau read, packet đo, session/sequence, lịch acquisition 100 Hz, ESB/TDMA/sync và CDC RX fix.
- Giữ **calibration gate hiện tại**: trước fresh READY đầu tiên không mở ESB và không bắt đầu measurement capture. Không bỏ ACC khỏi điều kiện READY, không giả calibration=3, không đổi sang IMUPLUS/crystal ngoài để né lỗi. Raw ACC diagnostic không được tăng read_seq hoặc trở thành measurement DATA.
- Kiểm tra AGENTS.md nếu có; ghi lại trạng thái workspace, bảo toàn thay đổi khác. Project review trước không có Git; nếu vẫn vậy backup/hash các file sẽ sửa thay vì giả có git diff. Không ghi đè UF2 cũ.

## 0. Đối chiếu ba bên trước khi sửa

Đọc và lập bảng đối chiếu **C hiện tại ↔ CircuitPython ↔ MicroPython base + extended**, có file/function cụ thể. Không bỏ qua MicroPython chỉ vì CircuitPython là ứng dụng cùng pinout. Tập trung address/bus speed, reset/mode delays, clock source, sensor config, page ownership, calibration read/write/load, signed decoding và error recovery.

Những khác biệt đã quan sát, cần kiểm tra lại trên source trước khi áp dụng:

- MicroPython `BNO055_BASE.__init__` và constructor mở rộng mặc định `crystal=True`. `reset()` ghi SYS_TRIGGER=0x80 và đợi 500 ms khi dùng crystal ngoài; khi dùng oscillator nội thì ghi 0 và đợi 10 ms. CircuitPython cung cấp và C hiện tại dùng oscillator nội. Đây là khác biệt để giải thích, không phải bằng chứng crystal ngoài chữa ACC. Không tự bật khi chưa xác nhận module có crystal và yêu cầu sử dụng.
- MicroPython base sau reset không chủ động đặt bộ range/rate như CircuitPython; extended có `config()` chuyển CONFIG/page 1, sửa rồi khôi phục page 0/mode. C hiện tại chủ động cấu hình theo CircuitPython. Phân biệt default driver với những lời gọi thực tế của ứng dụng; nếu không có MicroPython application call sites thì ghi “chưa biết có dùng config()/crystal override/load calibration hay không”.
- MicroPython extended `get_calibration()`/`set_calibration()` dùng CONFIG, chờ 25 ms, vùng 22 bytes 0x55..0x6A, quay NDOF và chờ 20 ms; setter ghi từng byte. Đối chiếu với worker transaction của C, không thay bằng delay tùy ý.
- Cả hai Python driver giải mã CALIB_STAT giống C; quaternion cùng signed LE w/x/y/z, /16384. Kiểm tra riêng các helper mở rộng nếu định tái sử dụng, không port nguyên driver và không coi mọi code legacy là chuẩn đúng tuyệt đối.

Chọn sửa tối thiểu từ bằng chứng và datasheet. Bảng phải phân biệt “đã giống”, “khác có chủ đích”, “nghi vấn cần Astra kiểm chứng”; không biến một khác biệt thành root cause đã xác nhận.

## 1. Baseline I2C và init: sửa nhỏ, quan sát được

1. Thay hardcoded BNO055_I2C_ADDR2 bằng cấu hình address 0x28/0x29; giữ default tương thích cụm hiện tại 0x29, báo rõ lựa chọn. Nếu thêm auto-discovery, chỉ probe đúng hai địa chỉ trên pin đã biết, kiểm CHIP_ID, xử lý 0/1/2 responder rõ ràng; không scan GPIO, không đổi address giữa RUN.
2. Baseline bus thực tế 100 kHz trong devicetree; cung cấp override 400 kHz để A/B bằng cùng source. Bus kHz độc lập `CONFIG_IMU_RADIO_HZ`. Ghi rõ để Astra xác minh generated DTS khi build, không chỉ Kconfig. CircuitPython legacy không truyền frequency; mặc định API hiện tại là 100 kHz, nhưng runtime cũ chưa xác nhận.
3. Giữ sequence reset/mode của driver CircuitPython: page/config an toàn, wait sau mode switch, soft reset, recovery check, normal power, internal oscillator, cấu hình tương đương, offset policy, NDOF. Chờ chip sẵn sàng hữu hạn khi boot/recovery, không busy loop vô hạn.
4. Đừng đổi mask ACC 0xFC/4g, gyro 0x38/2000dps, mag 0x78/20Hz tùy tiện: hiện đang khớp legacy. Read back setup trong CONFIG rồi đọc mode/power/page/units/status sau NDOF; phân biệt giá trị yêu cầu và thực tế, không giả mọi sensor-config bit giữ nguyên khi fusion quản lý chúng.
5. Tách kết quả soft-reset write và xác nhận recovery. Ghi lỗi reset riêng, không nuốt mất; chỉ thành công sau chip/mode check. Không tự gọi mọi errno là NACK vì Zephyr có thể trả EIO cho nhiều nguyên nhân.

## 2. Telemetry chẩn đoán ngay trong firmware IMU

Tái sử dụng sensor worker, cache snapshot, queue USB. Không gọi I2C từ ISR, radio callback hoặc Python command handler. Không thêm worker sensor thứ hai.

Thêm record USB diagnostic có framing/CRC hiện tại, type/version/length rõ ràng; không lén đổi nghĩa STATS/DATA cũ. Nếu cần nhiều record, dùng số lượng hữu hạn với schema đơn giản; không tạo giao thức tổng quát mới. Update decoder/monitor tương thích capture cũ. Không xen printk thường kỳ vào stream binary. Diagnostics không cần truyền qua ESB.

Thông tin bắt buộc:

- Build ID/profile, session, uptime, address, actual bus frequency; startup snapshot phải lấy được cả khi PC mở COM sau boot.
- `CALIB_STAT(0x35)` nguyên byte và bốn mức; `ST_RESULT(0x36)`, `SYS_STATUS(0x39)`, `SYS_ERR(0x3A)`, `UNIT_SEL(0x3B)`, `OPR_MODE(0x3D)`, `PWR_MODE(0x3E)`, page và revision/ID trong snapshot init.
- ACC XYZ từ **page 0 0x08..0x0D**, signed LE, đơn vị theo UNIT_SEL. Đây là acceleration gồm gravity, không lấy linear acceleration 0x28 làm bài kiểm tra sáu mặt. Timestamp và valid/error riêng; đọc lỗi không hiển thị cache như giá trị mới.
- Init/reset/recovery count, reset-write errors, runtime read errors/consecutive errors; first/last failure errno + phase + register/page + read/write + timestamp. Giữ lỗi lịch sử sau khi recovery thành công; current error riêng.
- NVS status absent/invalid/applied/bypassed, payload fingerprint và kết quả load/readback khi áp dụng.

Chạy telemetry sensor tối đa khoảng 2 Hz, đủ quan sát khi CALIBRATING và sau READY, tránh ảnh hưởng lịch đọc 100 Hz. Page-1 config/22-byte offsets chỉ snapshot ở CONFIG lúc init hoặc lệnh offset có chủ đích. Không định kỳ vào CONFIG, không ghi offset, không reset hay trigger self-test trong monitoring. Đọc self-test status được phép, tự kích hoạt self-test thì không.

Mở rộng `imu_calibration_monitor.py` để hiển thị raw CALIB hex, acc_cal và ACC XYZ phân biệt rõ, runtime/reset errors, uptime/reset count, loaded-profile state, build. Cho ghi CSV hữu hạn hoặc Ctrl+C, không overwrite, finite serial timeout. Mặc định observational: không tự gửi save/load/clear/reset. Khi nhận firmware cũ, hiện “diagnostics unavailable”, không bịa zero.

## 3. Calibration persistence an toàn, clean boot kiểm chứng được

1. Thêm option boot bỏ qua autoload NVS cho thử clean calibration, không xóa flash. Mặc định production giữ hành vi load; artifact baseline diagnostic ghi rõ bypass. Cùng code init, không tạo app riêng. Reboot/recovery trong profile bypass cũng không được lén load.
2. Sửa S: trên chính sensor worker, kiểm fresh calibration thành công và bằng 0xFF trước khi chuyển CONFIG để đọc 22 bytes và lưu. CALIBRATING/FAULT/stale-status/I2C failure phải từ chối, không làm hỏng record tốt cũ. Giữ controlled pause radio/acquisition trong flash write và bảo toàn pause của người dùng.
3. Sau load, readback 22 bytes khi vẫn CONFIG để kiểm transfer; failure không coi applied. Không đòi CALIB_STAT==0xFF ngay hay trong 1 giây sau load. Giữ CRC/version/length checks và xử lý không có NVS không gây sensor fault.
4. C hiện chỉ xóa NVS, không xóa offsets đang chạy trong sensor: giữ semantics này nếu đó là diff nhỏ nhất, nhưng command result/monitor/docs phải báo cần reset/power-cycle để clean calibration. Không tự reset khi query/monitor.
5. Record chỉ gắn node ID, không đủ định danh sensor vật lý. Không giả CHIP_ID/revision/address là unique serial. Sửa tài liệu; khi thay BNO055 phải clear/recalibrate hoặc dùng bypass. Không xây registry sensor mới nếu không có ID đáng tin.
6. Command result USB có cấu trúc cho S/L/C: command, result, NVS/action state; decoder biết thành công/từ chối/lỗi/timeout. Không suy ra command thành công chỉ vì stream vẫn chạy. Bảo toàn bounded mailbox/cancellation/timeout hiện tại.

## 4. Recovery không xóa tiến trình calibration chỉ vì một lỗi đọc

Giữ fault reporting ngay khi đọc lỗi, nhưng retry read transient hữu hạn trước soft reset. Ví dụ tối đa 3 lần lỗi liên tiếp, cách nhau bằng chu kỳ thích hợp; một read thành công xóa consecutive count. Chọn chính sách cụ thể, tài liệu hóa và bàn giao các nhánh cần Astra test; không retry spin trong ISR hoặc phá absolute acquisition deadlines.

- Không reset chỉ vì CALIB_STAT chưa 0xFF, SYS calibration giảm, hay calibration lâu.
- Read lỗi không tăng read_seq, không cập nhật completed_us/quaternion; cache cũ phải có stale/fault semantics đúng.
- Khi recovery/reset cần thiết, giữ full-calibration gate trước khi acquisition trở lại; radio start vẫn one-shot theo thiết kế hiện tại. Trước first READY không bật radio.
- Lỗi write hoặc cleanup CONFIG/NDOF không được xử lý giống transient read: có thể làm mode không rõ, phải kiểm tra/khôi phục có giới hạn trước khi tiếp tục.
- Không đổi timeout TWIM 500 ms thành con số tùy tiện; nếu đổi phải dựa trên driver/clock-stretch và ghi rõ giới hạn. Sensor thread được phép chờ I2C, radio không được bị khóa theo.

## 5. Hợp đồng kiểm chứng bàn giao Astra — Luna không thực thi

Ghi các mục dưới đây vào `ASTRA_BNO055_VALIDATION_HANDOFF.md`, cùng thay đổi thực tế và rủi ro. Đây là checklist cho Astra, không phải công việc Luna phải chạy. Astra nên tái sử dụng các harness có sẵn. Baseline review trước thay đổi: 57 tests qua với:
`python -m unittest test_imu_startup test_imu_sensor_calibration test_imu_calibration_monitor test_imu_capture test_imu_radio`

Kết quả cũ không chứng minh source sau sửa. Astra viết/cập nhật và chạy test hành vi thật trong production C khi có harness; không chỉ grep source hoặc tạo Python model tự chứng minh chính nó:

- CALIB bytes F3/F7/FF; raw ACC signed XYZ; error/invalid diagnostic không biến thành số mới; decode frame mới/old/truncated/CRC bad.
- Reset-write error + chip hồi phục: startup thành công và counter reset riêng; chip không hồi phục: fault, bounded retry.
- Clean bypass không write saved offsets dù NVS có record; valid load có readback; partial load failure/invalid record không được báo applied.
- S trước calibration đủ bị từ chối; fresh full calibration lưu được; read error không thay record tốt; C không giả sensor offsets đã clear.
- Transient read không reset; persistent read failure recovery đúng ngưỡng; không sequence/timestamp giả; init/CONFIG restore failure xử lý đúng.
- Diagnostics trong CALIBRATING không mở ESB, không tăng measurement read_seq; sau READY acquisition vẫn 100 Hz và cached-read radio 400 Hz đúng semantics.
- Giữ tests mailbox/concurrency, startup gate, radio/sync và capture regression.

Thông tin cho Astra build: NCS `C:\ncs\v3.4.0`, toolchain `C:\ncs\toolchains\dcbdc366a1`, target `promicro_nrf52840/nrf52840/uf2`, cần xác nhận còn đúng. Build ngoài OneDrive qua workflow hiện có. Luna sửa `build-imu.ps1` để -Pristine thực sự hiệu lực nếu còn lỗi switch bị bỏ qua; Astra xác minh bằng build. Không xóa build khác bừa bãi.

Luna chuẩn bị cấu hình và lệnh tương ứng; Astra build với tên mới:

- A100 TX/hub; A400 TX/hub.
- B100 TX1/TX2/hub.
- Một A100 TX diagnostic baseline 100 kHz, saved-offset bypass, dùng cùng firmware IMU; production TX cũng có telemetry, không cần firmware probe.

B400 chưa có conf/artifact riêng trong baseline. Báo rõ, không tự mở rộng sửa scheduler để hoàn thiện B400 trong task ACC này. Shared source hỗ trợ rate không đồng nghĩa đã có artifact/hardware test B400.

Astra kiểm mỗi UF2: family 0xADA52840, toàn bộ block, vùng [0x26000,0xEC000); ghi SHA-256, build ID, role/node/radio rate/I2C address/bus/NVS policy và RAM/flash. Không đụng bootloader hoặc storage [0xEC000,0xF4000). Không overwrite artifact cũ. Luna không tạo manifest giả chứa artifact/hash/memory chưa build. Tests/build không chứng minh calibration trên thiết bị.

## 6. Deliverables của Luna

Giao:

1. Production source/config/docs đã sửa đầy đủ; danh sách file và lý do từng thay đổi. Giữ nguyên test files để Astra phụ trách; có thể đọc tests để hiểu contract hiện tại.
2. Bảng đối chiếu C/CircuitPython/MicroPython có dẫn file/function và kết luận có giới hạn.
3. `ASTRA_BNO055_VALIDATION_HANDOFF.md`: hành vi trước/sau, schema telemetry/command, cấu hình mặc định và override, lệnh build/monitor/capture theo implementation thực tế, test cases ở mục 5, điểm chưa chắc chắn. Nếu test cũ đang encode hành vi chủ đích thay đổi, chỉ rõ test nào và vì sao.
4. Hướng dẫn phần cứng **chưa thực thi**, để Astra phối hợp người dùng sau khi source qua review/tests/build: flash thủ công TX diagnostic baseline; xác nhận banner đúng; log raw ACC/CALIB/status trên từng cụm. Không yêu cầu người dùng flash source chưa được Astra xác minh.

Kết thúc ghi rõ: “Implementation hoàn tất; chưa chạy tests/build/kiểm chứng phần cứng. Bàn giao Astra.” Nếu còn mục implementation chưa làm được, liệt kê chính xác thay vì dùng câu hoàn tất này.

Viết decision tree ngắn:

- ACC XYZ không đổi/không đủ ba trục → kiểm page/units/config/self-test/nguồn; đối chứng CircuitPython cùng cụm, address, clock và no saved offsets.
- ACC XYZ bình thường nhưng cal 0/1 → xem reset count, NVS policy, mode/SYS_ERR/revision; không force READY.
- Clean bypass qua, autoload lỗi → kiểm profile/persistence.
- 100 kHz qua, 400 kHz lỗi → I2C timing/electrical; đo SCL/SDA nếu có thiết bị.
- Cả CircuitPython và C đều lỗi trên cùng cụm → điều tra phần cứng/nguồn chung; không kết luận “C driver đã sửa xong”.

Astra/người dùng chỉ chuyển sang save→reboot→reload, A100 rồi A400 và sensor-disconnect/recovery sau khi phần cứng đạt đủ bốn mức 3. B cần ba board; đánh dấu hardware validation pending nếu chưa đủ. Luna chỉ ghi quy trình, không thực thi.

Nguồn kỹ thuật để đối chiếu:
- Bosch datasheet: https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bno055-ds000.pdf
- Adafruit calibration: https://learn.adafruit.com/adafruit-bno055-absolute-orientation-sensor/device-calibration
- CircuitPython I2C API: https://docs.circuitpython.org/en/latest/shared-bindings/busio/
- Nordic ESB API: https://nrfconnectdocs.nordicsemi.com/ncs/latest/nrf/doxygen/html/group__esb.html

Ưu tiên diff nhỏ có bằng chứng. Không cam kết ACC sẽ lên 3 chỉ nhờ đổi bus clock, retry hay thêm telemetry. Phân biệt “đã sửa lỗi code xác nhận được”, “đã bổ sung phép thử phân biệt nguyên nhân” và “còn cần kết quả hardware”.
