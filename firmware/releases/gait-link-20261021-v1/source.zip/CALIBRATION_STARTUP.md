# Calibration-gated startup (A400)

## Startup order

1. The hub starts its normal synchronization beacons and USB STATS. It does not impose a TX connection deadline.
2. The TX initializes the BNO055, applies saved offsets when available, enters NDOF, and polls calibration every 500 ms. It does not acquire quaternion measurements or start ESB during this wait.
3. Full calibration requires register 0x35 to read 255 (SYS/GYRO/ACCEL/MAG all 3). There is no calibration deadline. Sensor errors remain faults and retry initialization after a one-second delay.
4. After full calibration, the sensor acquires a quaternion. The main loop releases the existing radio-thread start semaphore only for a fresh, valid, unpaused READY sample with no sensor error.
5. The TX starts ESB, acquires fresh hub synchronization, and begins its scheduled wireless measurements. The first READY DATA received by the capture tool starts the requested measurement duration.

The start signal is local to each TX's radio thread; there is no new over-air START command. The hub must keep beaconing while waiting to avoid a startup deadlock. This is per-node startup, not a multi-node all-ready barrier.

USB commands, STATS, and one local status snapshot per second remain available during calibration. Those are diagnostics, not radio measurement traffic. Calibration wait time is not counted as missed acquisition slots. The start barrier is one-shot: later calibration-level fluctuations remain visible in the existing packet state; they do not repeatedly restart ESB. Sensor reinitialization and explicit offset transactions require full calibration before acquisition resumes.

## Artifacts

- TX: `firmware/imu-tx-a400-addr29-gate.uf2` (addresses the sensor at 0x29, confirmed by the `imu-tx-bno-probe` diagnostic; supersedes the 0x28 builds)
- Hub: `firmware/imu-hub-a400-calibration-gate-final.uf2`

The BNO055 on this hardware answers at I2C address 0x29 (ADR high), not the 0x28 default. The earlier `state: 3` fault was the firmware probing only 0x28. `src/imu_bno_probe.c` + `ptx/bno-probe.conf` remain available as the standalone diagnostic.

Both artifacts are built for the A400 one-node profile. Original firmware artifacts are not overwritten. No boards were flashed as part of this change.

## Capture

Run the updated `imu_capture.py` with the hub application COM port, for example (replace COMx):

```powershell
python .\imu_capture.py --port COMx --source hub --nodes 1 --seconds 120 --out calibrated-run.csv
```

The tool waits for valid, nonstale, unpaused DATA with state 2 and calibration 255, then records for 120 seconds. Waiting records are retained with `capture_phase=waiting`; metadata includes calibration wait time and a recording-only summary. Ctrl+C ends an indefinite calibration/fault wait and retains diagnostics.

`--startup-timeout` still detects a completely absent binary USB stream. STATS/STATUS satisfy it; it is not a calibration deadline. `--command` remains a separate finite observation operation, not a measurement capture or calibration-completion acknowledgment.

## Interpreting the supplied screenshot

`state: 3` means SENSOR_FAULT, not CALIBRATING (state 1). `synced: 1` and DIAG `ack: 1` show that wireless was working in that capture. The final 'No command ACK exists' line is an observation warning, not an ESB timeout. This startup change prevents premature measurements but does not establish or fix the underlying sensor/I2C fault.
