"""Plot raw saved IMU CSV quaternion w,x,y,z versus node completed_us.

  python imu_plot.py run.csv
  python imu_plot.py run.csv --node 1 --out run.png

Requires matplotlib only for rendering. No fusion, remapping, normalization,
interpolation, sign correction, or inferred sensor-to-host latency. Distinct
read_seq identities are selected, not distinct quaternion values. Paused/stale
valid records remain visible. Separate node/session panels avoid crossing reboots.
"""
import argparse
import csv
from pathlib import Path

from imu_capture import SequenceTracker


def load_series(path, node=None):
    series = {}
    trackers = {}
    with Path(path).open(newline='', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        required = {'record', 'valid', 'node', 'session', 'read_seq', 'completed_us', 'qw', 'qx', 'qy', 'qz'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('Not an imu_capture CSV: missing required columns')
        for row in reader:
            if row['record'] not in ('data', 'timed_data') or row['valid'] != '1':
                continue
            key = (int(row['node']), int(row['session']))
            if node is not None and key[0] != node:
                continue
            tracker = trackers.setdefault(key, SequenceTracker())
            new, seq = tracker.add(int(row['read_seq']))
            if new:
                series.setdefault(key, []).append((seq, int(row['completed_us']),
                                                   tuple(int(row[k]) for k in ('qw', 'qx', 'qy', 'qz'))))
    return {key: sorted(points) for key, points in sorted(series.items())}


def plot(path, node=None, out=None):
    series = load_series(path, node)
    if not series:
        raise ValueError('No valid quaternion reads match the selection')
    if out is not None:
        import matplotlib
        matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(len(series), 1, squeeze=False, figsize=(11, 3.5 * len(series)))
    for ax, ((device, session), points) in zip(axes[:, 0], series.items()):
        # Markers only: do not draw fictitious continuous data across lost records.
        x = [p[1] / 1e6 for p in points]
        for index, name in enumerate(('w', 'x', 'y', 'z')):
            ax.plot(x, [p[2][index] for p in points], '.', markersize=2, label=name)
        ax.set_title(f'Node {device}, session {session:08x}; {len(points)} distinct captured reads')
        ax.set_xlabel('Node device completed_us / 1e6 (seconds)')
        ax.set_ylabel('Raw int16 quaternion')
        ax.legend(loc='best')
        ax.grid(True, alpha=.25)
    fig.tight_layout()
    try:
        if out is None:
            plt.show()
        else:
            out = Path(out)
            image_format = out.suffix.lstrip('.') or 'png'
            with out.open('xb') as file:
                fig.savefig(file, format=image_format, dpi=150)
            print(f'Saved {out.resolve()}')
    finally:
        plt.close(fig)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('csv', type=Path)
    parser.add_argument('--node', type=int, choices=range(1, 5))
    parser.add_argument('--out', type=Path, help='Save image exclusively instead of opening a window')
    args = parser.parse_args(argv)
    try:
        plot(args.csv, args.node, args.out)
    except (OSError, ValueError, ImportError) as exc:
        parser.exit(1, f'Error: {exc}\n')


if __name__ == '__main__':
    main()
