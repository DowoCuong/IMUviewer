"""Focused mailbox model and source-wiring regressions; no firmware build.

Run: python -m unittest test_imu_sensor_calibration -v
These tests do NOT execute C or emulate Zephyr/I2C. The mailbox model explores
lock-serialized timeout/claim/completion orderings. Source checks keep critical
integration points visible, but SDK compilation and hardware tests are separate.
"""
import itertools
from pathlib import Path
import unittest

SOURCE = Path(__file__).parent / "src" / "imu_sensor.c"


class Mailbox:
    def __init__(self):
        self.state = "IDLE"
        self.done = False
        self.response = None
        self.output = b"unchanged"
        self.worker = None

    def post(self, operation, payload=None):
        if self.state != "IDLE":
            return "EBUSY"
        self.done = False
        self.operation = operation
        self.payload = bytes(payload) if operation == "WRITE" else None
        self.state = "PENDING"
        return "OK"

    def claim(self):
        if self.state != "PENDING":
            return False
        self.worker = (self.operation, self.payload)
        self.state = "RUNNING"
        return True

    def finish(self, result=0, payload=b"read result"):
        if self.state == "ABANDONED":
            self.state = "IDLE"
        elif self.state == "RUNNING":
            self.response = result
            if result == 0 and self.operation == "READ":
                self.payload = payload
            self.state = "DONE"
            self.done = True  # Same critical section as publication.
        self.worker = None

    def collect_or_timeout(self):
        if self.state == "DONE":
            result = self.response
            if result == 0 and self.operation == "READ":
                self.output = self.payload
            self.state = "IDLE"
            return result
        if self.state == "PENDING":
            self.state = "IDLE"
        else:
            self.state = "ABANDONED"
        return "ETIMEDOUT"


class MailboxTests(unittest.TestCase):
    def test_read_does_not_need_input_and_write_owns_copy(self):
        m = Mailbox()
        self.assertEqual(m.post("READ"), "OK")
        m.claim()
        m.finish(payload=bytes(range(22)))
        self.assertEqual(m.collect_or_timeout(), 0)
        self.assertEqual(m.output, bytes(range(22)))
        original = bytearray(range(22))
        self.assertEqual(m.post("WRITE", original), "OK")
        original[:] = bytes(22)
        m.claim()
        self.assertEqual(m.worker, ("WRITE", bytes(range(22))))
        m.finish()
        self.assertEqual(m.collect_or_timeout(), 0)

    def test_pending_timeout_cancels_without_side_effect(self):
        m = Mailbox()
        m.post("WRITE", bytes(22))
        self.assertEqual(m.collect_or_timeout(), "ETIMEDOUT")
        self.assertFalse(m.claim())
        self.assertEqual(m.post("READ"), "OK")

    def test_running_timeout_holds_slot_until_discard(self):
        for operation in ("READ", "WRITE", "SAVE"):
            with self.subTest(operation=operation):
                m = Mailbox()
                m.post(operation, bytes(22))
                m.claim()
                self.assertEqual(m.collect_or_timeout(), "ETIMEDOUT")
                self.assertEqual(m.post("READ"), "EBUSY")
                m.finish(payload=b"late response")
                self.assertEqual(m.output, b"unchanged")
                self.assertFalse(m.done)
                self.assertEqual(m.post("READ"), "OK")
                m.claim()
                m.finish(payload=b"new response")
                self.assertEqual(m.collect_or_timeout(), 0)
                self.assertEqual(m.output, b"new response")

    def test_completion_timeout_interleavings(self):
        # Claim must precede finish; timeout can win before claim, during work,
        # or lose to finish. Each event represents a whole locked transition.
        for order in itertools.permutations(("claim", "finish", "timeout")):
            if order.index("claim") > order.index("finish"):
                continue
            with self.subTest(order=order):
                m = Mailbox()
                m.post("READ")
                for event in order:
                    if event == "claim":
                        m.claim()
                    elif event == "finish":
                        m.finish()
                    else:
                        result = m.collect_or_timeout()
                self.assertEqual(m.state, "IDLE")
                if order.index("timeout") > order.index("finish"):
                    self.assertEqual(result, 0)
                    self.assertEqual(m.output, b"read result")
                else:
                    self.assertEqual(result, "ETIMEDOUT")
                    self.assertEqual(m.output, b"unchanged")

    def test_busy_and_failure_never_overwrite_read_output(self):
        m = Mailbox()
        m.post("READ")
        self.assertEqual(m.post("WRITE", bytes(22)), "EBUSY")
        m.claim()
        self.assertEqual(m.post("SAVE"), "EBUSY")
        m.finish(result=-5)
        self.assertEqual(m.post("READ"), "EBUSY")
        self.assertEqual(m.collect_or_timeout(), -5)
        self.assertEqual(m.output, b"unchanged")
        self.assertTrue(m.done)  # Unconsumed signal at deadline is harmless.
        self.assertEqual(m.post("READ"), "OK")
        self.assertFalse(m.done)  # Cleared before publishing the next request.


class SourceWiringTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = SOURCE.read_text()

    def section(self, start, end):
        return self.source.split(start, 1)[1].split(end, 1)[0]

    def test_runtime_page_config_offsets_and_cleanup(self):
        body = self.section("static int calib_transaction(", "static bool calib_serve(")
        self.assertNotIn("write_reg(0x07, 0x01)", body)
        self.assertLess(body.index("write_reg(0x3d, 0x00)"), body.index("calib_registers("))
        self.assertLess(body.index("k_msleep(20)"), body.index("calib_registers("))
        self.assertGreater(body.index("int restore = write_reg(0x07, 0x00)"), body.index("calib_registers("))
        self.assertIn("restore = write_reg(0x3d, 0x0c)", body)
        self.assertIn("return result ? result : restore", body)
        registers = self.section("static int calib_registers(", "static int calib_transaction(")
        self.assertIn("i < 22", registers)
        self.assertIn("read_reg(0x55 + i", registers)
        self.assertIn("write_reg(0x55 + i", registers)

    def test_boot_load_before_ndof_and_service_before_pause(self):
        init = self.section("static int initialize_sensor(", "static void diagnostic_poll(")
        self.assertLess(init.index("imu_calibration_fetch(saved)"), init.index("write_reg(0x3d, 0x0c)"))
        self.assertIn("calib_registers(CALIB_WRITE, saved)", init)
        self.assertNotIn("0x35", init)  # Saved data is not gated on status 3.
        loop = self.section("static void sensor_run(", "void imu_sensor_start(")
        self.assertLess(loop.index("calib_serve(initialized"), loop.index("if (paused)"))
        self.assertIn("calibration == 0xff ? IMU_READY : IMU_CALIBRATING", loop)
        self.assertIn("read_quaternion_retry(&quaternion)", loop)

    def test_save_persists_before_completion_on_worker(self):
        save = self.section("int imu_sensor_save(", "int imu_sensor_load(")
        self.assertIn("calib_transfer(CALIB_SAVE, NULL, NULL)", save)
        worker = self.section("static bool calib_serve(", "static int initialize_sensor(")
        self.assertLess(worker.index("imu_calibration_store(payload)"), worker.index("k_sem_give(&calib_done)"))
        self.assertIn("calib.result = result", worker)
        self.assertNotIn("k_sem_count_get", self.source)
        self.assertNotIn("calib_request", self.source)


if __name__ == "__main__":
    unittest.main()
