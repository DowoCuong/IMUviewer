param([string]$Sdk = 'C:\ncs\v3.4.0', [string]$Toolchain = 'C:\ncs\toolchains\dcbdc366a1', [switch]$HighRate, [switch]$Benchmark)
$ErrorActionPreference = 'Stop'
$manifest = Get-Content "$Toolchain\environment.json" -Raw | ConvertFrom-Json
foreach ($entry in $manifest.env_vars) {
    $value = if ($entry.type -eq 'relative_paths') { ($entry.values | ForEach-Object { Join-Path $Toolchain $_ }) -join ';' } else { $entry.value }
    if ($entry.existing_value_treatment -eq 'prepend_to') { $value += ';' + [Environment]::GetEnvironmentVariable($entry.key, 'Process') }
    [Environment]::SetEnvironmentVariable($entry.key, $value, 'Process')
}
$env:ZEPHYR_BASE = "$Sdk\zephyr"
Push-Location $Sdk
try {
    $roles = if ($Benchmark) { @('ptx') } else { @('ptx','prx') }
    foreach ($role in $roles) {
        $variant = if ($Benchmark) { 'benchmark400' } elseif ($HighRate) { '400hz' } else { 'usb' }
        $build = "C:\ncs\build-supermini-esb-$variant-$role"
        $log = "$PSScriptRoot\build-$variant-$role.log"
        $extra = if ($Benchmark) { @('--', '-DEXTRA_CONF_FILE=benchmark.conf', '-DEXTRA_DTC_OVERLAY_FILE=benchmark.overlay') } elseif ($HighRate) { @('--', '-DEXTRA_CONF_FILE=400hz.conf') } else { @() }
        $ErrorActionPreference = 'Continue'
        & west build -p auto -b promicro_nrf52840/nrf52840/uf2 "$PSScriptRoot\$role" -d $build @extra *> $log
        $buildExit = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
        if ($buildExit -ne 0) { Get-Content $log -Tail 70; throw "Build failed: $role" }
        & python "$PSScriptRoot\verify_uf2.py" "$build\$role\zephyr\zephyr.uf2"
        if ($LASTEXITCODE -ne 0) { throw "UF2 validation failed: $role" }
        $name = if ($role -eq 'ptx') { "transmitter-$variant.uf2" } else { "receiver-$variant.uf2" }
        Copy-Item "$build\$role\zephyr\zephyr.uf2" "$PSScriptRoot\firmware\$name"
        if ($role -eq 'ptx' -and !$HighRate -and !$Benchmark) { Copy-Item "$PSScriptRoot\firmware\$name" "$PSScriptRoot\firmware\transmitter-latency.uf2" }
        Write-Output "Built and validated $name"
    }
} finally { Pop-Location }


