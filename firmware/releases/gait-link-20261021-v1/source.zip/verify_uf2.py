"""Check generated UF2 block integrity and the S140 v6 application flash range."""
import struct
import sys
from pathlib import Path

def verify(path):
    data = Path(path).read_bytes()
    assert data and len(data) % 512 == 0, "Invalid file length"
    count = len(data) // 512
    seen = set()
    for offset in range(0, len(data), 512):
        block = data[offset:offset + 512]
        magic0, magic1, flags, address, size, number, total, family = struct.unpack_from('<8I', block)
        assert (magic0, magic1) == (0x0A324655, 0x9E5D5157), "Invalid header"
        assert struct.unpack_from('<I', block, 508)[0] == 0x0AB16F30, "Invalid trailer"
        assert flags & 0x2000 and family == 0xADA52840, "Incorrect device family"
        assert not flags & 1, "Unexpected non-flash block"
        assert 0 < size <= 476 and 0x26000 <= address and address + size <= 0xEC000, "Outside application partition"
        assert total == count and number < count and number not in seen, "Missing/duplicate block"
        seen.add(number)
    print(f'UF2 verified: {count} blocks within application partition')

if __name__ == '__main__':
    verify(sys.argv[1])
