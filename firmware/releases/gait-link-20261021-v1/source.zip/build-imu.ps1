param(
    [string]$Sdk = 'C:\ncs\v3.4.0',
    [string]$Toolchain = 'C:\ncs\toolchains\dcbdc366a1',
    [string]$Conf = 'imu.conf',
    [string]$Variant = 'imu-node',
    [string]$Role = 'ptx',
    [ValidateSet(100000, 400000)][int]$I2cHz = 100000,
    [switch]$Pristine
)
$ErrorActionPreference = 'Stop'
$manifest = Get-Content "$Toolchain\environment.json" -Raw | ConvertFrom-Json
foreach ($entry in $manifest.env_vars) {
    $value = if ($entry.type -eq 'relative_paths') { ($entry.values | ForEach-Object { Join-Path $Toolchain $_ }) -join ';' } else { $entry.value }
    if ($entry.existing_value_treatment -eq 'prepend_to') { $value += ';' + [Environment]::GetEnvironmentVariable($entry.key, 'Process') }
    [Environment]::SetEnvironmentVariable($entry.key, $value, 'Process')
}
$env:ZEPHYR_BASE = "$Sdk\zephyr"
# Keep a single source tree; a junction avoids west's cross-drive relpath failure.
$link = 'C:\ncs\supermini-imu-source'
if (!(Test-Path $link)) { New-Item -ItemType Junction -Path $link -Target $PSScriptRoot | Out-Null }
if ((Get-Item $link).Target -ne $PSScriptRoot) { throw 'Source junction points elsewhere' }
$build = "C:\ncs\build-supermini-$Variant-$Role"
$log = "$PSScriptRoot\build-$Variant-$Role.log"
Push-Location $Sdk
try {
    $ErrorActionPreference = 'Continue'
    $extra = @('--', "-DEXTRA_CONF_FILE=$Conf")
    if ($Role -eq 'ptx' -and (Test-Path "$link\$Role\i2c_pins.overlay")) {
        # Space-free junction path: a quoted Windows path with spaces splits
        # when passed through west to the devicetree preprocessor.
        $overlays = "$link\$Role\i2c_pins.overlay"
        if ($I2cHz -eq 400000) { $overlays += ";$link\$Role\i2c_400k.overlay" }
        $extra += "-DEXTRA_DTC_OVERLAY_FILE=$overlays"
    }
    
    $pristineMode = if ($Pristine) { 'always' } else { 'auto' }
    & west build -p $pristineMode -b promicro_nrf52840/nrf52840/uf2 "$link\$Role" -d $build @extra *> $log
    $result = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($result -ne 0) { Get-Content $log -Tail 80; throw "Build failed: $Variant $Role" }
    & python "$PSScriptRoot\verify_uf2.py" "$build\$Role\zephyr\zephyr.uf2"
    if ($LASTEXITCODE -ne 0) { throw "UF2 verification failed: $Variant $Role" }
    $prefix = if ($Role -eq 'ptx') { 'imu-tx' } else { 'imu-hub' }
    $name = "$prefix-$Variant.uf2"
    Copy-Item "$build\$Role\zephyr\zephyr.uf2" "$PSScriptRoot\firmware\$name" -Force
    Write-Output "Built and validated $name"
    Get-Content $log | Select-String 'FLASH:|RAM:' | ForEach-Object { Write-Output $_.Line.Trim() }
} finally { Pop-Location }
