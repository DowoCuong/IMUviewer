# Calibration monitor validation

Result: 73 IMU tests passed; Python compilation passed. No COM access, hardware
test, flashing or firmware rebuild was performed. The firmware source and UF2
artifacts are unchanged; the fix runs on the PC with the existing firmware.

## Findings and fixes

The first run found two formatter fixture errors (missing packet type in the
existing helper API) and a real regression: hub STATS entered the node loop,
making the wrong-port warning unreachable.

Review also found fallback could show FULL for paused/fault/initializing data,
diagnostic detail could call a paused read VALID, old query-session snapshots
survived a confirmed reboot, and historical error/status-register labels remained
ambiguous.

Updated `imu_calibration_monitor.py` to:

- Preserve helper compatibility and apply validity/state/pause/stale checks to
  legacy DATA/STATUS fallback. STATUS.valid=0 is allowed because it does not mean
  calibration read failure; DATA.valid is checked separately.
- Prefer latest diagnostic even when it is invalid: no fallback to older FULL.
- Suppress an older FULL observation when a newer live sample reports pause,
  initialization or fault. Show the sample warning explicitly.
- Keep calibration separate from firmware state, with independent host receive
  ages. Unknown state never becomes READY merely because calibration is FULL.
- Clear both sample and STATS caches for that node on a diagnostic-confirmed
  boot-session change, including prior query-session snapshots. Changing query
  session alone does not trigger reboot handling. Clearing is conservative if a
  new-boot snapshot arrived before the confirming diagnostic; a subsequent
  snapshot repopulates the cache.
- Restore the hub-port warning. Do not create sensor progress rows from STATS.
- Label paused/invalid diagnostic values CACHED/UNCONFIRMED, use sys_status for
  the register and last_error_history for retained errors.

Only the production monitor, its tests and handoff/validation documentation were
changed in this validation turn. No firmware or capture protocol changes.

## Verification

```
python -m unittest test_imu_sensor_diagnostics test_imu_startup test_imu_sensor_calibration test_imu_calibration_monitor test_imu_capture test_imu_radio
```

73 tests passed in 20.306 seconds, process exit code 0. Includes all 256
calibration bytes, DIAG-only streams and expiry, actual field reductions,
invalid updates, stale statistics, fresh fault/pause warnings, query session
versus reboot, multiple nodes, hub warning, finite duration, Ctrl+C and absence
of serial writes. The radio/startup/native sensor regression tests also passed.

```
python -m py_compile imu_calibration_monitor.py imu_capture.py test_imu_calibration_monitor.py
```

Compilation passed, process exit code 0. Python bytecode compilation is not a
firmware build or a hardware validation.

Run the updated tool using the existing flashed firmware:

```
python imu_calibration_monitor.py --port COM6 --seconds 180
```

Replace COM6 if needed. With fresh DIAG=0xff and expired DATA/STATUS, expected:
all four levels 3, calibration FULL, source DIAG, firmware_state UNKNOWN.
If diagnostic later falls to 0xbf, SYS becomes 2 immediately; nothing is latched.

Host receive age cannot measure USB backlog latency. Type 7 validity/stale bits
remain necessary, and no claim about repaired sensor hardware follows from these
tests.
